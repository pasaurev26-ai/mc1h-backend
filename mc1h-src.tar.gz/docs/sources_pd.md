# Sherlock PD sources — endpoint, auth, legal status

Every fact in a dossier points to one of these sources. If a source needs a
key or cannot be accessed lawfully, the pipeline records a **gap** instead of
inventing a result.

| selector | source | endpoint | auth | status |
|---|---|---|---|---|
| ФИО | Wikidata SPARQL | `https://query.wikidata.org/sparql` | none | implemented; exact `rdfs:label` (+ birth year) |
| ФИО | ЕГРЮЛ/ЕГРИП by director name | `MC1H_FNS_API_URL` | `MC1H_FNS_API_KEY` | optional; no public name-search API |
| ФИО | Арбитраж `kad.arbitr.ru` | — | captcha | **not automated** (gap) |
| ФИО | Суды `sudrf.ru` | — | captcha | **not automated** (gap) |
| Телефон | `phonenumbers` | local library | none | implemented: E.164, region, carrier, line type |
| Телефон | t.me public page | `https://t.me/+<phone>` | none | implemented: `tgme_page_title` + description; contact-only pages marked as gap |
| Телефон | Avito public search | `https://www.avito.ru/rossiya?q=<phone>` | none | best-effort; 401/403/407/429/439/451 -> gap `captcha/blocked` + `manual_export_missing` |
| Телефон | Youla public search | `https://youla.ru/search?q=<phone>` | none | best-effort; JSON-LD / product links; block -> gap `captcha/blocked` + `manual_export_missing` |
| Телефон | `local_html_export` | `$MC1H_LOCAL_DATA/avito_<digits>.html`, `youla_<digits>.html` | user-saved file | implemented: parse local HTML, no network request |
| Телефон | Playwright renderer | optional | none | `MC1H_PLAYWRIGHT=1`; renders JS, never solves captcha |
| Email | Cloudflare DNS-over-HTTPS | `https://cloudflare-dns.com/dns-query` | none | implemented: MX, A fallback, null MX |
| Email | Gravatar | `https://gravatar.com/avatar/<md5>` | none | implemented: avatar existence |
| Email | GitHub commit search | `https://api.github.com/search/commits` | optional `GITHUB_TOKEN` | implemented; token raises limits |
| Email | HIBP | `https://haveibeenpwned.com/api/v3/breachedaccount/...` | `MC1H_HIBP_API_KEY` | optional; metadata only, no passwords |
| Email | other leak corpora | — | — | **refused** (unlawful) |
| ИНН | checksum | local | none | implemented: 10/12 digits |
| ИНН | ЕГРЮЛ/ЕГРИП | `MC1H_FNS_API_URL` | `MC1H_FNS_API_KEY` | optional |
| СНИЛС | checksum | local | none | implemented: ПФР algorithm |
| СНИЛС | СФР / aggregators | — | no public API | **not automated** (gap) |
| Паспорт | format + region code | local | none | implemented |
| Паспорт | МВД / Госуслуги | — | authorized access | **not automated** (gap) |
| Паспорт | leak corpora | — | — | **refused** (unlawful) |

## Environment variables

| variable | default | purpose |
|---|---|---|
| `MC1H_PROXIES` | empty | comma-separated proxy rotation |
| `MC1H_TIMEOUT` | 12 | per-request timeout, seconds |
| `MC1H_ATTEMPTS` | 3 | retries with exponential backoff |
| `MC1H_HOST_INTERVAL` | 0.8 | min interval per host, seconds |
| `MC1H_CONCURRENCY` | 6 | global async semaphore |
| `MC1H_PER_SOURCE_CONCURRENCY` | 2 | per-resolver semaphore |
| `MC1H_RESOLVER_TIMEOUT` | 45 | per-resolver wall-clock limit |
| `MC1H_CACHE_TTL` | 3600 | SQLite response cache TTL; 0 disables |
| `MC1H_CACHE_DB` | `data/mc1h_cache.db` | cache path |
| `MC1H_FNS_API_URL` | empty | legal ЕГРЮЛ/ЕГРИП endpoint |
| `MC1H_FNS_API_KEY` | empty | key for that endpoint |
| `MC1H_HIBP_API_KEY` | empty | HIBP API key |
| `GITHUB_TOKEN` | empty | raises GitHub rate limit |
| `MC1H_PD_ENABLED` | 1 | kill-switch for the PD module |
| `MC1H_PHONE_SEARCH` | 1 | enable t.me/Avito/Youla phone fan-out |
| `MC1H_PLAYWRIGHT` | 0 | optional Playwright renderer for classifieds |
| `MC1H_LOCAL_DATA` | `data` | directory for user-saved Avito/Youla HTML exports |

## Legal boundary

The module is built for lawful due diligence with a documented legal basis.
It does **not** access breach dumps, bypass captchas, use SQL injection, buy
access, or query shadow aggregators. Passport and СНИЛС are stored only as a
mask plus an irreversible hash; the full value never enters the graph or the
Markdown report.