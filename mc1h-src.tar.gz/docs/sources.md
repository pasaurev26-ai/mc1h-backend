# Источники: эндпоинты, авторизация, формат, лимиты

Наблюдения сняты **2026-11-10** с хоста прогона (datacenter IP, без прокси).
Каждая строка — то, что реально ответил источник, а не только документация.
Где лимит не документирован, так и написано; клиент в любом случае держит
`MC1H_HOST_INTERVAL` (по умолчанию 0.8 с) между запросами к одному хосту.

| источник | эндпоинт | авторизация | формат | rate-limit | ключевые поля | наблюдение |
|---|---|---|---|---|---|---|
| github | `GET https://api.github.com/users/{login}` + `/users/{login}/repos?per_page=100&type=owner` | нет; опционально `GITHUB_TOKEN` (Bearer) | JSON object / array | 60 req/h на IP без токена (подтверждено заголовком `x-ratelimit-*`: 58/60 после запроса) | login, id, name, company, blog, location, bio, twitter_username, public_repos, followers, created_at; repo: full_name, language, stargazers_count, pushed_at | 200 OK |
| gitlab | `GET https://gitlab.com/api/v4/users?username={u}` | нет | JSON array | публичный API; жёсткий лимит для анонимов не зафиксирован | id, username, name, state, public_email, bio, location, web_url, created_at | 200 OK, 1 кандидат |
| hackernews | `GET https://hacker-news.firebaseio.com/v0/user/{id}.json` | нет | JSON object или `null` | не документирован | id, about, created, karma, submitted[] | 200 OK; `null` = пользователя нет |
| hackernews (activity) | `GET https://hn.algolia.com/api/v1/search?tags=author_{id}&hitsPerPage=5` | нет | JSON | не документирован; индекс может отставать | nbHits, hits[].title/url/created_at/points | 200 OK |
| reddit | `GET https://www.reddit.com/user/{u}/about.json` (fallback `old.reddit.com`) | анонимно; надёжно — OAuth | JSON | анонимный JSON с datacenter IP → **403** | name, id, link_karma, comment_karma, created_utc, is_mod, verified, subreddit | **403 blocked** (нужен residential proxy или OAuth) |
| npm | `GET https://registry.npmjs.org/-/v1/search?text=maintainer:{u}&size=25` | нет | JSON | не документирован | objects[].package.{name,version,description,maintainers[],links,date}, total | 200 OK; `total=1072`, точных maintainer-совпадений 25 |
| dockerhub | `GET https://hub.docker.com/v2/users/{u}/` | нет | JSON | эндпоинт недокументирован, лимит неизвестен | id, username, full_name, location, company, date_joined, type | 200 OK |
| devto | `GET https://dev.to/api/users/by_username?url={u}` | нет | JSON | не документирован | username, name, summary, github_username, twitter_username, website_url, joined_at | 200 OK; 404 для отсутствующего |
| codeforces | `GET https://codeforces.com/api/user.info?handles={u}` | нет | JSON `{status, result|comment}` | рекомендация 1 запрос / 2 с | handle, rating, maxRating, rank, country, organization, registrationTimeSeconds | 200 OK; отсутствующий → **400 + status=FAILED** |
| keybase | `GET https://keybase.io/_/api/1.0/user/lookup.json?username={u}` | нет | JSON | не документирован | basics.username/ctime, profile.full_name/location/bio, proofs_summary.all[].{proof_type,nametag,state,proof_url} | 200 OK; `them=[]` = нет аккаунта |
| telegram | `GET https://t.me/{u}` | нет | HTML (og:title, og:description, og:image) | не документирован | display name, bio, image | 200 OK; отсутствующий отдаёт `noindex` + «Telegram: Contact @…» |
| stackexchange | `GET https://api.stackexchange.com/2.3/users?inname={u}&site=stackoverflow` | нет | JSON (gzip) | 300 запросов/день на IP без ключа (подтверждено `quota_remaining=296`) | user_id, display_name, link, reputation, creation_date, badge_counts | 200 OK; `inname` — нечёткий поиск, нужен точный slug |

## Что не реализовано и почему

| источник | причина |
|---|---|
| PyPI | у профиля пользователя нет JSON API; HTML-страница отдаёт 200 даже для несуществующего пользователя — парсинг ненадёжен |
| Twitter/X | анонимный доступ закрыт, API требует ключей |
| Instagram / TikTok / Facebook | только авторизованный доступ или scraping, выходящий за рамки OPSEC-слоя |
| Telegram (полный профиль) | публичная страница даёт только превью; история сообщений недоступна |

## OPSEC-поведение клиента

- прокси-ротация: `MC1H_PROXIES` — список через запятую, round-robin на каждую попытку;
- per-host throttle: `MC1H_HOST_INTERVAL`, сериализация запросов к одному хосту;
- retry: 3 попытки по умолчанию, экспоненциальный backoff + jitter, учёт `Retry-After`;
- 401/403/451 не ретраятся — сразу `blocked`;
- таймаут на запрос `MC1H_TIMEOUT`, на резолвер `MC1H_RESOLVER_TIMEOUT`;
- глобальный семафор `MC1H_CONCURRENCY`.