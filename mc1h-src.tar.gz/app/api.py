"""FastAPI router: POST /resolve, GET /runs/{id}, GET /sources, GET /selectors."""

from __future__ import annotations

from fastapi import APIRouter, HTTPException

from .config import SETTINGS
from .db import Store
from .pipeline import PDPipeline, describe_sources
from .report import summarize, write_artifacts
from .resolvers import ALL
from .resolvers.pd import PD_ALL
from .schemas import ResolveRequest, ResolveResponse
from .service import UsernamePipeline

router = APIRouter()


@router.post("/resolve", response_model=ResolveResponse)
async def resolve(request: ResolveRequest) -> ResolveResponse:
    store = Store(SETTINGS.db_path)
    run = None
    try:
        pipeline = (
            UsernamePipeline(store=store)
            if request.username
            else PDPipeline(store=store)
        )
        try:
            if request.username:
                run = await pipeline.run(request.username, request.sources)
            else:
                run = await pipeline.run(
                    request.selector or "",
                    request.selector_type,
                    request.birth_date,
                    request.sources,
                )
        finally:
            await pipeline.aclose()
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    finally:
        store.close()

    if run is None:  # defensive; every path above either returns or raises
        raise HTTPException(status_code=500, detail="pipeline produced no result")

    artifacts = write_artifacts(run, SETTINGS.out_dir)
    return ResolveResponse(
        run_id=run.run_id,
        selector=run.selector,
        status=run.status,
        summary=summarize(run),
        artifacts=artifacts,
    )


@router.get("/runs/{run_id}")
async def get_run(run_id: str) -> dict:
    store = Store(SETTINGS.db_path)
    try:
        data = await store.get_run(run_id)
    finally:
        store.close()
    if data is None:
        raise HTTPException(status_code=404, detail="run not found")
    return data


@router.get("/sources")
async def list_sources() -> dict:
    return {
        "sources": sorted(ALL),
        "pd_sources": sorted(PD_ALL),
        "description": "username resolvers plus Sherlock PD selector families",
    }


@router.get("/selectors")
async def list_selectors() -> dict:
    return describe_sources()