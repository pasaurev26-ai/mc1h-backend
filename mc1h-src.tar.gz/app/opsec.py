"""OPSEC transport layer: per-host rate limit, proxy rotation, retry/backoff, timeouts.

Nothing in this module knows about platforms; resolvers only see FetchResult.
"""

from __future__ import annotations

import asyncio
import hashlib
import json as jsonlib
import random
import time
from dataclasses import dataclass
from typing import Any
from urllib.parse import urlsplit

import httpx

from .cache import ResponseCache
from .config import Settings
from .schemas import Outcome


RETRY_STATUS = {429, 500, 502, 503, 504}


@dataclass
class FetchResult:
    url: str
    status: int | None
    outcome: Outcome
    payload: Any = None
    text: str | None = None
    error: str | None = None
    elapsed_ms: int = 0
    attempts: int = 0
    headers: dict[str, str] | None = None
    from_cache: bool = False

    @property
    def ok(self) -> bool:
        return self.outcome == "ok"


class HostLimiter:
    """Serializes requests per host and keeps a minimum interval between them."""

    def __init__(self, interval_s: float) -> None:
        self._interval = max(0.0, interval_s)
        self._locks: dict[str, asyncio.Lock] = {}
        self._next_at: dict[str, float] = {}

    async def acquire(self, url: str) -> None:
        host = urlsplit(url).netloc
        lock = self._locks.setdefault(host, asyncio.Lock())
        async with lock:
            now = time.monotonic()
            nxt = self._next_at.get(host, 0.0)
            if nxt > now:
                await asyncio.sleep(nxt - now)
                now = time.monotonic()
            self._next_at[host] = now + self._interval


class ProxyPool:
    """Round-robin over a static proxy list; empty list means direct connection."""

    def __init__(self, proxies: tuple[str, ...]) -> None:
        self._proxies = list(proxies)
        self._idx = 0
        self._lock = asyncio.Lock()

    @property
    def enabled(self) -> bool:
        return bool(self._proxies)

    async def next(self) -> str | None:
        if not self._proxies:
            return None
        async with self._lock:
            proxy = self._proxies[self._idx % len(self._proxies)]
            self._idx += 1
            return proxy


class HttpFetcher:
    """Async HTTP client with bounded concurrency, retries and optional proxy rotation."""

    def __init__(
        self, settings: Settings, cache: ResponseCache | None = None
    ) -> None:
        self._s = settings
        self._limiter = HostLimiter(settings.per_host_interval_s)
        self._pool = ProxyPool(settings.proxies)
        self._sem = asyncio.Semaphore(max(1, settings.global_concurrency))
        self._cache = cache or (
            ResponseCache(settings.cache_path, settings.cache_ttl_s)
            if settings.cache_ttl_s > 0
            else None
        )
        self._owns_cache = cache is None
        self._direct = httpx.AsyncClient(
            follow_redirects=True,
            timeout=httpx.Timeout(settings.timeout_s),
            headers={"User-Agent": settings.user_agent, "Accept": "*/*"},
        )

    async def aclose(self) -> None:
        await self._direct.aclose()
        if self._owns_cache and self._cache is not None:
            await self._cache.aclose()

    @staticmethod
    def _cache_key(url: str, headers: dict[str, str] | None, parse_json: bool) -> str:
        material = jsonlib.dumps(
            [url, sorted((headers or {}).items()), parse_json],
            ensure_ascii=False,
            separators=(",", ":"),
        )
        return hashlib.sha256(material.encode("utf-8")).hexdigest()

    async def get_json(self, url: str, *, headers: dict[str, str] | None = None) -> FetchResult:
        return await self._get(url, headers=headers, parse_json=True)

    async def get_text(self, url: str, *, headers: dict[str, str] | None = None) -> FetchResult:
        return await self._get(url, headers=headers, parse_json=False)

    async def post_json(
        self,
        url: str,
        payload: Any,
        *,
        headers: dict[str, str] | None = None,
    ) -> FetchResult:
        """POST a JSON body with retries.  POST responses are never cached."""
        started = time.monotonic()
        last: FetchResult | None = None
        for attempt in range(1, self._s.attempts + 1):
            await self._limiter.acquire(url)
            proxy = await self._pool.next()
            try:
                async with self._sem:
                    resp = await self._request(
                        url, headers, proxy, method="POST", json_body=payload
                    )
                elapsed = int((time.monotonic() - started) * 1000)
                status = resp.status_code
                hdrs = {k.lower(): v for k, v in resp.headers.items()}
                if 200 <= status < 300:
                    try:
                        body = resp.json()
                    except (jsonlib.JSONDecodeError, ValueError):
                        return FetchResult(
                            url, status, "error", text=resp.text,
                            error="invalid JSON in response",
                            elapsed_ms=elapsed, attempts=attempt, headers=hdrs,
                        )
                    return FetchResult(
                        url=str(resp.url), status=status, outcome="ok",
                        payload=body, elapsed_ms=elapsed, attempts=attempt,
                        headers=hdrs,
                    )
                if status in (404, 410):
                    return FetchResult(
                        url, status, "not_found", elapsed_ms=elapsed,
                        attempts=attempt, headers=hdrs,
                    )
                if status in (401, 403, 451):
                    return FetchResult(
                        url, status, "blocked",
                        error=f"HTTP {status} (access denied / requires auth)",
                        elapsed_ms=elapsed, attempts=attempt, headers=hdrs,
                    )
                last = FetchResult(
                    url, status, "error", error=f"HTTP {status}",
                    elapsed_ms=elapsed, attempts=attempt, headers=hdrs,
                )
                if status in RETRY_STATUS and attempt < self._s.attempts:
                    await self._sleep_backoff(attempt, hdrs.get("retry-after"))
                    continue
                return last
            except httpx.TimeoutException as exc:
                last = FetchResult(
                    url, None, "timeout",
                    error=f"timeout after {self._s.timeout_s:.0f}s: {exc.__class__.__name__}",
                    elapsed_ms=int((time.monotonic() - started) * 1000),
                    attempts=attempt,
                )
                if attempt < self._s.attempts:
                    await self._sleep_backoff(attempt, None)
                    continue
                return last
            except (httpx.TransportError, OSError) as exc:
                last = FetchResult(
                    url, None, "error",
                    error=f"{exc.__class__.__name__}: {exc}",
                    elapsed_ms=int((time.monotonic() - started) * 1000),
                    attempts=attempt,
                )
                if attempt < self._s.attempts:
                    await self._sleep_backoff(attempt, None)
                    continue
                return last
            except Exception as exc:
                return FetchResult(
                    url, None, "error",
                    error=f"{exc.__class__.__name__}: {exc}",
                    elapsed_ms=int((time.monotonic() - started) * 1000),
                    attempts=attempt,
                )
        assert last is not None
        return last

    async def _get(
        self, url: str, *, headers: dict[str, str] | None, parse_json: bool
    ) -> FetchResult:
        started = time.monotonic()
        last: FetchResult | None = None
        cache_key = self._cache_key(url, headers, parse_json)

        if self._cache is not None and parse_json:
            hit = await self._cache.get(cache_key)
            if hit is not None:
                try:
                    cached_payload = jsonlib.loads(hit["body"])
                except (jsonlib.JSONDecodeError, ValueError):
                    cached_payload = None
                if cached_payload is not None:
                    return FetchResult(
                        url=url,
                        status=hit["status"],
                        outcome="ok",
                        payload=cached_payload,
                        elapsed_ms=0,
                        attempts=0,
                        from_cache=True,
                    )

        for attempt in range(1, self._s.attempts + 1):
            await self._limiter.acquire(url)
            proxy = await self._pool.next()
            try:
                async with self._sem:
                    resp = await self._request(url, headers, proxy)
                elapsed = int((time.monotonic() - started) * 1000)
                status = resp.status_code
                hdrs = {k.lower(): v for k, v in resp.headers.items()}

                if 200 <= status < 300:
                    payload: Any = None
                    text: str | None = resp.text
                    outcome: Outcome = "ok"
                    error = None
                    if parse_json:
                        try:
                            payload = resp.json()
                            text = None
                        except (jsonlib.JSONDecodeError, ValueError):
                            outcome = "error"
                            error = "invalid JSON in response"
                    if (
                        self._cache is not None
                        and parse_json
                        and outcome == "ok"
                        and payload is not None
                    ):
                        try:
                            body = jsonlib.dumps(payload, ensure_ascii=False)
                        except (TypeError, ValueError):
                            body = ""
                        if body:
                            await self._cache.put(cache_key, status, body)
                    return FetchResult(
                        url=str(resp.url),
                        status=status,
                        outcome=outcome,
                        payload=payload,
                        text=text,
                        error=error,
                        elapsed_ms=elapsed,
                        attempts=attempt,
                        headers=hdrs,
                    )

                # Some APIs (e.g. Codeforces) return structured JSON with a 4xx body.
                error_payload: Any = None
                if "json" in hdrs.get("content-type", ""):
                    try:
                        error_payload = resp.json()
                    except (jsonlib.JSONDecodeError, ValueError):
                        error_payload = None

                if status in (404, 410):
                    return FetchResult(url, status, "not_found", payload=error_payload,
                                       elapsed_ms=elapsed, attempts=attempt, headers=hdrs)
                if status in (401, 403, 451):
                    return FetchResult(
                        url, status, "blocked", payload=error_payload,
                        error=f"HTTP {status} (access denied / requires auth)",
                        elapsed_ms=elapsed, attempts=attempt, headers=hdrs,
                    )

                last = FetchResult(
                    url, status, "error", payload=error_payload,
                    error=f"HTTP {status}",
                    elapsed_ms=elapsed, attempts=attempt, headers=hdrs,
                )
                if status in RETRY_STATUS and attempt < self._s.attempts:
                    await self._sleep_backoff(attempt, hdrs.get("retry-after"))
                    continue
                return last

            except httpx.TimeoutException as exc:
                last = FetchResult(
                    url, None, "timeout",
                    error=f"timeout after {self._s.timeout_s:.0f}s: {exc.__class__.__name__}",
                    elapsed_ms=int((time.monotonic() - started) * 1000),
                    attempts=attempt,
                )
                if attempt < self._s.attempts:
                    await self._sleep_backoff(attempt, None)
                    continue
                return last
            except (httpx.TransportError, OSError) as exc:
                last = FetchResult(
                    url, None, "error",
                    error=f"{exc.__class__.__name__}: {exc}",
                    elapsed_ms=int((time.monotonic() - started) * 1000),
                    attempts=attempt,
                )
                if attempt < self._s.attempts:
                    await self._sleep_backoff(attempt, None)
                    continue
                return last
            except Exception as exc:  # defensive: a resolver must never kill the run
                return FetchResult(
                    url, None, "error",
                    error=f"{exc.__class__.__name__}: {exc}",
                    elapsed_ms=int((time.monotonic() - started) * 1000),
                    attempts=attempt,
                )

        assert last is not None
        return last

    async def _request(
        self,
        url: str,
        headers: dict[str, str] | None,
        proxy: str | None,
        *,
        method: str = "GET",
        json_body: Any = None,
    ) -> httpx.Response:
        merged = {"User-Agent": self._s.user_agent}
        if headers:
            merged.update(headers)
        if proxy:
            async with httpx.AsyncClient(
                follow_redirects=True,
                timeout=httpx.Timeout(self._s.timeout_s),
                proxy=proxy,
            ) as client:
                return await client.request(
                    method, url, headers=merged, json=json_body
                )
        return await self._direct.request(
            method, url, headers=merged, json=json_body
        )

    async def _sleep_backoff(self, attempt: int, retry_after: str | None) -> None:
        delay = self._s.backoff_base_s * (2 ** (attempt - 1))
        delay += random.uniform(0, self._s.backoff_base_s)
        if retry_after:
            try:
                delay = max(delay, min(30.0, float(retry_after)))
            except ValueError:
                pass
        await asyncio.sleep(delay)