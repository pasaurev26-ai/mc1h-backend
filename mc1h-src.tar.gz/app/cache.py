"""SQLite response cache with TTL.

Only successful JSON responses are cached.  The cache is deliberately local
(SQLite file) and never shared between installations.  Set MC1H_CACHE_TTL=0
to disable it entirely.
"""

from __future__ import annotations

import asyncio
import os
import time
from typing import Any

import aiosqlite

SCHEMA = """
CREATE TABLE IF NOT EXISTS http_cache (
    key TEXT PRIMARY KEY,
    status INTEGER NOT NULL,
    body TEXT NOT NULL,
    fetched_at REAL NOT NULL,
    expires_at REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_cache_exp ON http_cache(expires_at);
"""


class ResponseCache:
    """Async SQLite cache. Connection is opened lazily, on first use."""

    def __init__(self, path: str, ttl_s: float) -> None:
        self.path = path
        self.ttl_s = max(0.0, ttl_s)
        self._db: aiosqlite.Connection | None = None
        self._lock = asyncio.Lock()

    @property
    def enabled(self) -> bool:
        return self.ttl_s > 0

    async def _conn(self) -> aiosqlite.Connection:
        if self._db is None:
            directory = os.path.dirname(os.path.abspath(self.path))
            os.makedirs(directory, exist_ok=True)
            self._db = await aiosqlite.connect(self.path)
            await self._db.execute("PRAGMA journal_mode=WAL")
            await self._db.executescript(SCHEMA)
            await self._db.commit()
        return self._db

    async def get(self, key: str) -> dict[str, Any] | None:
        if not self.enabled:
            return None
        async with self._lock:
            db = await self._conn()
            cursor = await db.execute(
                "SELECT status, body, fetched_at, expires_at FROM http_cache WHERE key=?",
                (key,),
            )
            row = await cursor.fetchone()
            await cursor.close()
            if row is None:
                return None
            if row[3] < time.time():
                await db.execute("DELETE FROM http_cache WHERE key=?", (key,))
                await db.commit()
                return None
            return {
                "status": int(row[0]),
                "body": str(row[1]),
                "fetched_at": float(row[2]),
                "expires_at": float(row[3]),
            }

    async def put(self, key: str, status: int, body: str) -> None:
        if not self.enabled:
            return
        now = time.time()
        async with self._lock:
            db = await self._conn()
            await db.execute(
                "INSERT OR REPLACE INTO http_cache(key, status, body, fetched_at, expires_at)"
                " VALUES (?,?,?,?,?)",
                (key, status, body, now, now + self.ttl_s),
            )
            await db.commit()

    async def purge_expired(self) -> int:
        if not self.enabled:
            return 0
        async with self._lock:
            db = await self._conn()
            cursor = await db.execute(
                "DELETE FROM http_cache WHERE expires_at < ?", (time.time(),)
            )
            await db.commit()
            deleted = cursor.rowcount
            await cursor.close()
            return max(0, deleted)

    async def aclose(self) -> None:
        async with self._lock:
            if self._db is not None:
                await self._db.close()
                self._db = None