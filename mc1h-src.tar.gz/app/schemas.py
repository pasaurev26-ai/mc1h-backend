"""Canonical data model: Provenance -> Entity -> Edge -> ResolverResult -> RunResult.

Entity carries both the legacy attribute bag (username resolvers) and the
structured PD fields required by the Sherlock module (selector, platform,
profile_url, data, raw_hash).  ``attributes`` stays for backwards compatibility;
new resolvers put facts into ``data``.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Literal

from pydantic import BaseModel, Field, model_validator


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


Outcome = Literal[
    "ok",
    "not_found",
    "blocked",
    "error",
    "timeout",
    "invalid",
    "not_configured",
]
EntityKind = Literal[
    "root",
    "account",
    "artifact",
    "person",
    "identifier",
    "organization",
    "record",
    "breach",
]
Relation = Literal[
    "handle_match",
    "verified_link",
    "owns",
    "same_as",
    "registered_at",
    "observed_in",
    "registered_as",
    "director_of",
    "founder_of",
    "identified_as",
    "affiliated_with",
]
SelectorType = Literal[
    "username",
    "fio",
    "phone",
    "email",
    "contacts",
    "inn",
    "snils",
    "passport",
    "vu",
    "documents",
    "transport",
    "social",
    "telegram",
    "online_traces",
    "real_estate",
    "legal_entity",
    "face",
]


class Provenance(BaseModel):
    """Every fact must carry where it came from and how much we trust it."""

    source: str
    endpoint: str
    query: str = ""
    fetched_at: datetime = Field(default_factory=utcnow)
    http_status: int | None = None
    outcome: Outcome = "ok"
    confidence: float = 0.0
    latency_ms: int | None = None
    note: str | None = None

    def compact(self) -> str:
        parts = [self.source, self.outcome]
        if self.http_status is not None:
            parts.append(f"HTTP {self.http_status}")
        if self.latency_ms is not None:
            parts.append(f"{self.latency_ms} ms")
        return " · ".join(parts)


class Entity(BaseModel):
    id: str
    kind: EntityKind
    key: str
    label: str

    # Sherlock / PD fields.  For username entities these stay None.
    selector: str | None = None
    platform: str | None = None
    profile_url: str | None = None
    data: dict[str, Any] = Field(default_factory=dict)
    raw_hash: str | None = None

    attributes: dict[str, Any] = Field(default_factory=dict)
    provenance: list[Provenance] = Field(default_factory=list)
    confidence: float = 0.0

    @staticmethod
    def make(kind: EntityKind, key: str, label: str, **kwargs: Any) -> "Entity":
        return Entity(id=f"{kind}:{key}", kind=kind, key=key, label=label, **kwargs)


class Edge(BaseModel):
    src: str
    dst: str
    relation: Relation
    confidence: float
    provenance: Provenance | None = None
    note: str | None = None


class ResolverResult(BaseModel):
    source: str
    status: Outcome
    entities: list[Entity] = Field(default_factory=list)
    edges: list[Edge] = Field(default_factory=list)
    provenance: list[Provenance] = Field(default_factory=list)
    error: str | None = None
    elapsed_ms: int = 0
    # Checks that were deliberately not performed (no key, captcha, legal ban,
    # source has no public API).  They are rendered in "Пробелы и сбои" even
    # when the resolver itself succeeded.
    gaps: list[str] = Field(default_factory=list)


@dataclass
class RunResult:
    run_id: str
    selector: str
    selector_kind: str
    created_at: datetime
    status: str
    entities: list[Entity]
    edges: list[Edge]
    results: list[ResolverResult]
    assumed: list[str] = field(default_factory=list)
    secondary: list[str] = field(default_factory=list)
    birth_date: str | None = None
    gaps: list[str] = field(default_factory=list)


class ResolveRequest(BaseModel):
    """One selector per run.

    Backwards compatible: ``{"username": "torvalds"}`` still works.  Sherlock
    clients send ``{"selector": "...", "selector_type": "inn"}``; when
    ``selector_type`` is omitted the type is auto-detected server-side.
    """

    username: str | None = Field(default=None, max_length=128)
    selector: str | None = Field(default=None, max_length=256)
    selector_type: SelectorType | None = None
    birth_date: str | None = Field(
        default=None,
        description="ФИО only: ISO (1990-01-01) or DD.MM.YYYY",
        max_length=10,
    )
    sources: list[str] | None = None

    @model_validator(mode="after")
    def _exactly_one(self) -> "ResolveRequest":
        if not (self.username or self.selector):
            raise ValueError("either 'username' or 'selector' is required")
        if self.username and self.selector:
            raise ValueError("send either 'username' or 'selector', not both")
        if self.selector and self.selector_type == "username":
            raise ValueError("use 'username' for username selectors")
        return self


class ResolveResponse(BaseModel):
    run_id: str
    selector: str
    status: str
    summary: dict[str, Any]
    artifacts: dict[str, str]