"""mc1h — username entity-resolution pipeline."""

__version__ = "1.0.0"