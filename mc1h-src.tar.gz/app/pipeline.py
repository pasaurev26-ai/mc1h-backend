"""Sherlock pipeline: one selector -> fan-out -> merged graph -> dossier.

The pipeline never invents facts.  Each resolver reports what it actually
fetched and lists checks it could not perform (no key, captcha, no lawful
public API) in ``ResolverResult.gaps``.
"""

from __future__ import annotations

import asyncio
import logging
import re
import time
import uuid
from datetime import datetime, timezone
from typing import Any

import phonenumbers

from .config import SETTINGS, Settings
from .db import Store
from .detect import (
    detect_selector as _detect_selector,
    normalize_selector as _normalize_selector,
    parse_command,
    split_fio_dob,
)
from .opsec import HttpFetcher
from .resolvers.pd import PD_ALL, select_pd
from .resolvers.pd.common import (
    EMAIL_RE,
    mask_digits,
    mask_passport,
    mask_phone,
    normalize_email,
    normalize_name,
    parse_date,
    sha256_hex,
)
from .schemas import Edge, Entity, ResolverResult, RunResult, SelectorType

log = logging.getLogger("mc1h.pd")


def detect_selector(raw_input: str) -> tuple[SelectorType, str]:
    """Public pipeline helper: ``(selector_type, normalized value)``."""
    return _detect_selector(raw_input)


def normalize_selector(
    selector_type: SelectorType, raw: str
) -> tuple[str, str]:
    """Return (canonical value used internally, safe label stored in graph)."""
    return _normalize_selector(selector_type, raw)


def _resolve_group(selector_type: SelectorType, raw: str) -> tuple[SelectorType, str]:
    """Resolve UI groups (contacts/documents) into a concrete resolver family."""
    value = raw.strip()
    if selector_type == "contacts":
        try:
            number = phonenumbers.parse(value, "RU")
            if phonenumbers.is_valid_number(number):
                return "phone", value
        except phonenumbers.NumberParseException:
            pass
        if EMAIL_RE.fullmatch(value):
            return "email", value
        raise ValueError("contacts: нужен телефон или email")
    if selector_type == "documents":
        from .resolvers.pd.documents import normalize_document

        parsed = normalize_document(value)
        if parsed is None:
            raise ValueError(
                "documents: не удалось определить документ; используйте "
                "/passport, /snils, /inn или /vu"
            )
        document_type, digits = parsed
        return document_type, digits  # type: ignore[return-value]
    return selector_type, value


def _root_entity(
    selector_type: SelectorType, safe_label: str, canonical: str, birth_date: str | None
) -> Entity:
    payload = {
        "selector_kind": selector_type,
        "masked": safe_label,
        "selector_sha256": sha256_hex(canonical),
        "birth_date": birth_date,
    }
    return Entity.make(
        "root",
        "selector",
        safe_label,
        attributes=payload,
        data=payload,
        confidence=1.0,
    )


class PDPipeline:
    def __init__(
        self,
        settings: Settings | None = None,
        store: Store | None = None,
        fetcher: HttpFetcher | None = None,
    ) -> None:
        self.s = settings or SETTINGS
        self.store = store
        self.fetcher = fetcher or HttpFetcher(self.s)
        self._owns_fetcher = fetcher is None
        self._source_sems: dict[str, asyncio.Semaphore] = {}

    async def aclose(self) -> None:
        if self._owns_fetcher:
            await self.fetcher.aclose()

    async def run(
        self,
        selector: str,
        selector_type: SelectorType | None = None,
        birth_date: str | None = None,
        sources: list[str] | None = None,
    ) -> RunResult:
        if not self.s.pd_enabled:
            raise ValueError("PD module is disabled (MC1H_PD_ENABLED=0)")

        original = selector.strip()
        if not original:
            raise ValueError("selector is empty")

        command = parse_command(original)
        if selector_type is None or command is not None:
            st, raw = _detect_selector(original)
            fio_source = command[1] if command is not None else original
        else:
            st, raw = _resolve_group(selector_type, original)
            fio_source = original

        if st == "username":
            raise ValueError("username selectors are handled by UsernamePipeline")
        st, raw = _resolve_group(st, raw)  # type: ignore[assignment]

        fio_name, fio_dob_raw = split_fio_dob(fio_source)
        if st == "fio":
            raw = fio_name
        dob = parse_date(birth_date) if birth_date else None
        if st == "fio" and dob is None and fio_dob_raw:
            dob = parse_date(fio_dob_raw)
        if st == "fio" and birth_date and dob is None:
            raise ValueError("birth_date must be ISO 2026-01-31 or DD.MM.YYYY")
        if st != "fio":
            dob = None

        canonical, safe_label = normalize_selector(st, raw)

        resolvers = select_pd(st, sources)
        if st == "phone":
            # Phone fan-out: offline E.164/carrier validation + public web search
            # (t.me, Avito, Youla). phone_search is enabled by default; set
            # MC1H_PHONE_SEARCH=0 to keep the run fully offline.
            if not self.s.phone_search_enabled:
                resolvers = [r for r in resolvers if r.name != "phone_search"]
                if not resolvers:
                    raise ValueError(
                        "phone_search is disabled and no other phone source is selected"
                    )
            log.info("phone fan-out: %s", ", ".join(r.name for r in resolvers))
        run_id = (
            datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
            + "-"
            + uuid.uuid4().hex[:8]
        )
        birth_iso = dob.isoformat() if dob else None
        root = _root_entity(st, safe_label, canonical, birth_iso)
        ctx = _context(st, raw, canonical, safe_label, dob, self.s)

        results: list[ResolverResult] = list(
            await asyncio.gather(*(self._one(r, ctx) for r in resolvers))
        )
        entities, edges = merge_results(results, root)

        gaps: list[str] = []
        for result in results:
            for gap in result.gaps:
                if gap not in gaps:
                    gaps.append(gap)

        status = (
            "complete"
            if all(r.status in ("ok", "not_found") for r in results) and not gaps
            else "partial"
        )

        assumed = [
            "только открытые/легальные источники; отсутствие ключа или API "
            "фиксируется как пробел, а не заполняется догадкой",
            "совпадение ФИО/номера/публичного профиля само по себе не доказывает "
            "тождество личности",
        ]
        if not self.s.proxies:
            assumed.append("MC1H_PROXIES не задан — запросы идут напрямую с IP хоста")
        if st == "fio" and not birth_iso:
            assumed.append("дата рождения не указана — часть проверок ограничена")
        if st in ("snils", "passport", "vu"):
            assumed.append(
                "полный номер документа не хранится в графе: только маска и "
                "необратимый хеш"
            )
        if st in ("social", "telegram", "online_traces"):
            assumed.append(
                "публичные страницы/поисковая выдача — наблюдения; "
                "они не доказывают тождество личности"
            )
        if st == "transport":
            assumed.append("госномер/VIN: проверен формат, не право собственности")
        if st == "documents":
            assumed.append(
                "без команды /vu 10 цифр трактуются как паспорт; "
                "для водительского удостоверения используйте /vu"
            )

        run = RunResult(
            run_id=run_id,
            selector=safe_label,
            selector_kind=st,
            created_at=datetime.now(timezone.utc),
            status=status,
            entities=entities,
            edges=edges,
            results=results,
            assumed=assumed,
            birth_date=birth_iso,
            gaps=gaps,
        )

        if self.store is not None:
            try:
                from .report import summarize

                await self.store.save_run(run, summarize(run))
            except Exception as exc:  # persistence must not destroy a finished run
                log.warning("failed to persist PD run %s: %s", run_id, exc)

        return run

    async def _one(
        self, resolver, ctx
    ) -> ResolverResult:
        started = time.monotonic()
        sem = self._source_sems.setdefault(
            resolver.name, asyncio.Semaphore(max(1, self.s.per_source_concurrency))
        )
        try:
            async with sem:
                result = await asyncio.wait_for(
                    resolver.resolve(ctx, self.fetcher),
                    timeout=self.s.resolver_timeout_s,
                )
        except asyncio.TimeoutError:
            result = ResolverResult(
                source=resolver.name,
                status="timeout",
                error=f"resolver exceeded {self.s.resolver_timeout_s:.0f}s",
            )
        except Exception as exc:  # resolver bugs must not kill the run
            result = ResolverResult(
                source=resolver.name,
                status="error",
                error=f"{exc.__class__.__name__}: {exc}",
            )
        result.source = resolver.name
        if not result.elapsed_ms:
            result.elapsed_ms = int((time.monotonic() - started) * 1000)
        return result


def _context(
    st: SelectorType,
    raw: str,
    canonical: str,
    safe_label: str,
    dob,
    settings: Settings,
):
    from .resolvers.pd.base import ResolveContext

    return ResolveContext(
        raw=raw,
        normalized=canonical,
        selector_type=st,
        birth_date=dob,
        settings=settings,
        safe_label=safe_label,
        selector_sha=sha256_hex(canonical),
    )


def merge_results(
    results: list[ResolverResult], root: Entity
) -> tuple[list[Entity], list[Edge]]:
    merged: dict[str, Entity] = {}
    for result in results:
        for entity in result.entities:
            current = merged.get(entity.id)
            if current is None:
                merged[entity.id] = entity.model_copy(deep=True)
                continue
            for key, value in entity.data.items():
                if current.data.get(key) in (None, "", [], {}):
                    current.data[key] = value
            for key, value in entity.attributes.items():
                if current.attributes.get(key) in (None, "", [], {}):
                    current.attributes[key] = value
            for field in ("selector", "platform", "profile_url", "raw_hash"):
                if getattr(current, field) in (None, "") and getattr(entity, field):
                    setattr(current, field, getattr(entity, field))
            known = {(p.source, p.endpoint) for p in current.provenance}
            for p in entity.provenance:
                if (p.source, p.endpoint) not in known:
                    current.provenance.append(p)
                    known.add((p.source, p.endpoint))
            current.confidence = max(current.confidence, entity.confidence)

    merged[root.id] = root

    edge_map: dict[tuple[str, str, str], Edge] = {}
    for result in results:
        for edge in result.edges:
            key = (edge.src, edge.dst, edge.relation)
            current = edge_map.get(key)
            if current is None or edge.confidence > current.confidence:
                edge_map[key] = edge

    verified_pairs = {
        (e.src, e.dst) for e in edge_map.values() if e.relation == "verified_link"
    }
    final_edges = [
        e
        for e in edge_map.values()
        if not (e.relation != "verified_link" and (e.src, e.dst) in verified_pairs)
    ]

    verified_targets = {dst for _, dst in verified_pairs}
    for entity in merged.values():
        if entity.id in verified_targets:
            entity.confidence = max(entity.confidence, 0.9)
            entity.data["resolution"] = "verified_link"

    return list(merged.values()), final_edges


def describe_sources() -> dict[str, Any]:
    """Machine-readable catalogue for GET /selectors."""
    return {
        "selectors": [
            {
                "type": "fio",
                "label": "🕵️ Личность (ФИО + дата рождения)",
                "normalization": "2–3 слова; DOB можно в конце: 01.01.1990",
                "sources": ["wikidata", "ЕГРЮЛ/ЕГРИП (ключ)", "kad.arbitr (не автоматизируется)"],
            },
            {
                "type": "contacts",
                "label": "📲 Контакты (телефон и email)",
                "normalization": "E.164 для телефона; lowercase+IDNA для email",
                "sources": ["phonenumbers", "t.me", "Avito/Youla", "DNS MX", "Gravatar", "GitHub", "HIBP (ключ)"],
            },
            {
                "type": "phone",
                "label": "Телефон",
                "normalization": "E.164, регион RU",
                "sources": ["phonenumbers (offline)", "t.me public page", "Avito/Youla (blocked -> gap)", "local_html_export"],
            },
            {
                "type": "email",
                "label": "Email",
                "normalization": "lowercase + IDNA",
                "sources": ["DNS MX (DoH)", "Gravatar", "GitHub commits", "HIBP (ключ)"],
            },
            {
                "type": "transport",
                "label": "🚘 Транспорт (госномер/VIN)",
                "normalization": "А123БВ777 или 17-символьный VIN",
                "sources": ["format validation", "ГИБДД/ЕАИСТО (ключ)"],
            },
            {
                "type": "social",
                "label": "💬 Социальные сети",
                "normalization": "vk.com/tiktok.com/instagram.com/ok.ru URL",
                "sources": ["public OpenGraph/meta"],
            },
            {
                "type": "telegram",
                "label": "📟 Telegram",
                "normalization": "@username, t.me/username или tg<id>",
                "sources": ["t.me public page", "ID lookup (ключ)"],
            },
            {
                "type": "documents",
                "label": "📄 Документы",
                "normalization": "/vu, /passport, /snils, /inn",
                "sources": ["format/checksum validation", "registry API (ключ)"],
            },
            {
                "type": "vu",
                "label": "Водительское удостоверение",
                "normalization": "/vu 1234567890",
                "sources": ["format validation", "ГИБДД (ключ)"],
            },
            {
                "type": "online_traces",
                "label": "🌐 Онлайн-следы",
                "normalization": "/tag профессия город, домен или IP",
                "sources": ["DNS DoH", "RDAP", "public search (hypothesis)"],
            },
            {
                "type": "real_estate",
                "label": "🏚 Недвижимость",
                "normalization": "/adr адрес или 77:01:0000000:1234",
                "sources": ["Nominatim", "Росреестр/ПКК (ключ/публичный контур)"],
            },
            {
                "type": "legal_entity",
                "label": "🏢 Юридическое лицо",
                "normalization": "ИНН 10/12, ОГРН 13, ОГРНИП 15",
                "sources": ["checksum", "ЕГРЮЛ/ЕГРИП (ключ)"],
            },
            {
                "type": "face",
                "label": "📸 Поиск по лицу",
                "normalization": "публичный http(s)-URL изображения",
                "sources": ["legal biometric API (ключ) или gap"],
            },
            {
                "type": "inn",
                "label": "ИНН",
                "normalization": "10/12 цифр + контрольное число",
                "sources": ["checksum", "ЕГРЮЛ/ЕГРИП (ключ)"],
            },
            {
                "type": "snils",
                "label": "СНИЛС",
                "normalization": "11 цифр + контрольное число ПФР",
                "sources": ["checksum only"],
            },
            {
                "type": "passport",
                "label": "Паспорт РФ",
                "normalization": "4 цифры серии + 6 цифр номера",
                "sources": ["format/region only"],
            },
        ],
        "pd_sources": sorted(PD_ALL),
    }