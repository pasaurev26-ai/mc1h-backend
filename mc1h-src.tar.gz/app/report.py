"""Markdown report renderer and artifact writer."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from .graph import adjacency_lines, build_graph, stats, to_dot, to_json
from .schemas import Edge, Entity, Provenance, RunResult

METHOD = """\
**Политика confidence**

| диапазон | что означает |
|---|---|
| 0.90–0.95 | платформенная запись владения (репозиторий/пакет у аккаунта) или криптографически подтверждённый кросс-ссылочный proof |
| 0.75–0.85 | точное совпадение handle в уникальном пространстве имён платформы |
| 0.55–0.70 | handle существует, но пространство имён общее/регистронезависимое, либо совпадение неполное |
| < 0.50 | поисковая гипотеза, не подтверждённая платформой |

**Ключевое ограничение:** совпадение username не доказывает тождество личности.
`handle_match` — гипотеза о том, что селектор и аккаунт стоит рассматривать вместе.
`verified_link` ставится только при внешнем подтверждении (Keybase proof, явная
кросс-ссылка в самом профиле). Любое утверждение об одном человеке требует
`verified_link`, а не набора `handle_match`.
"""


def _cell(value: Any, limit: int = 90) -> str:
    text = "—" if value is None or value == "" else str(value)
    text = text.replace("|", "\\|").replace("\n", " ").replace("\r", " ")
    return text if len(text) <= limit else text[: limit - 1] + "…"


def _brief_attrs(entity: Entity, limit: int = 6) -> str:
    skip = {"platform", "handle", "avatar_url", "image", "proofs"}
    parts: list[str] = []
    for key, value in entity.attributes.items():
        if key in skip or value in (None, "", [], {}):
            continue
        if isinstance(value, (dict, list)):
            continue
        parts.append(f"{key}={_cell(value, 40)}")
        if len(parts) >= limit:
            break
    return "; ".join(parts) if parts else "—"


def _all_gaps(run: RunResult) -> list[str]:
    gaps: list[str] = list(run.gaps)
    for result in run.results:
        for gap in result.gaps:
            if gap not in gaps:
                gaps.append(gap)
    return gaps


def summarize(run: RunResult) -> dict[str, Any]:
    statuses: dict[str, int] = {}
    for result in run.results:
        statuses[result.status] = statuses.get(result.status, 0) + 1

    def count(kind: str) -> int:
        return len([e for e in run.entities if e.kind == kind])

    links_by_relation: dict[str, int] = {}
    for edge in run.edges:
        links_by_relation[edge.relation] = links_by_relation.get(edge.relation, 0) + 1

    gaps = _all_gaps(run)
    return {
        "status": run.status,
        "selector_kind": run.selector_kind,
        "sources": {
            "checked": len(run.results),
            "ok": statuses.get("ok", 0),
            "not_found": statuses.get("not_found", 0),
            "blocked": statuses.get("blocked", 0),
            "error": statuses.get("error", 0),
            "timeout": statuses.get("timeout", 0),
            "not_configured": statuses.get("not_configured", 0),
            "invalid": statuses.get("invalid", 0),
        },
        "entities": {
            "accounts": count("account"),
            "artifacts": count("artifact"),
            "persons": count("person"),
            "identifiers": count("identifier"),
            "organizations": count("organization"),
            "records": count("record") + count("breach"),
            "total": len(run.entities),
        },
        "links": {
            "verified": links_by_relation.get("verified_link", 0),
            "handle_only": links_by_relation.get("handle_match", 0),
            "owns": links_by_relation.get("owns", 0),
            "same_as": links_by_relation.get("same_as", 0),
            "observed_in": links_by_relation.get("observed_in", 0),
            "other": sum(
                v
                for k, v in links_by_relation.items()
                if k
                not in (
                    "verified_link",
                    "handle_match",
                    "owns",
                    "same_as",
                    "observed_in",
                )
            ),
        },
        "gaps": len(gaps),
        "gaps_list": gaps[:100],
        "secondary_handles": run.secondary,
    }


def _source_rows(run: RunResult) -> list[str]:
    rows = ["| источник | статус | HTTP | latency | сущностей | примечание |", "|---|---|---|---|---|---|"]
    for result in sorted(run.results, key=lambda r: r.source):
        http = next((p.http_status for p in result.provenance if p.http_status is not None), None)
        note = result.error or next((p.note for p in result.provenance if p.note), None)
        rows.append(
            f"| {_cell(result.source)} | {result.status} | {_cell(http)} | "
            f"{result.elapsed_ms} ms | {len(result.entities)} | {_cell(note, 100)} |"
        )
    return rows


def _entity_rows(entities: list[Entity], empty: str = "_нет_") -> list[str]:
    if not entities:
        return [empty]
    rows = ["| id | label | conf | факты |", "|---|---|---|---|"]
    for entity in sorted(entities, key=lambda e: (-e.confidence, e.id)):
        rows.append(
            f"| `{_cell(entity.id, 60)}` | {_cell(entity.label, 60)} | "
            f"{entity.confidence:.2f} | {_brief_attrs(entity)} |"
        )
    return rows


def _link_rows(edges: list[Edge], by_id: dict[str, Entity], relations: set[str]) -> list[str]:
    selected = [e for e in edges if e.relation in relations]
    if not selected:
        return ["_нет_"]
    rows = ["| от | к | отношение | conf | примечание |", "|---|---|---|---|---|"]
    for edge in sorted(selected, key=lambda e: (-e.confidence, e.dst)):
        target = by_id.get(edge.dst)
        target_label = f"`{edge.dst}`" if target is None else f"`{edge.dst}` ({_cell(target.label, 40)})"
        note = edge.note or (edge.provenance.note if edge.provenance else None)
        rows.append(
            f"| `{_cell(edge.src, 50)}` | {target_label} | {edge.relation} | "
            f"{edge.confidence:.2f} | {_cell(note, 90)} |"
        )
    return rows


def _provenance_rows(provenance: list[Provenance]) -> list[str]:
    rows = ["| источник | endpoint | query | outcome | HTTP | время | conf | note |",
            "|---|---|---|---|---|---|---|---|"]
    for p in sorted(provenance, key=lambda x: (x.source, x.fetched_at)):
        rows.append(
            f"| {_cell(p.source)} | `{_cell(p.endpoint, 70)}` | {_cell(p.query, 45)} | {p.outcome} | "
            f"{_cell(p.http_status)} | {p.fetched_at.strftime('%Y-%m-%d %H:%M:%SZ')} | "
            f"{p.confidence:.2f} | {_cell(p.note, 80)} |"
        )
    return rows


def _brief_facts(entity: Entity, limit: int = 8) -> str:
    skip = {
        "selector",
        "masked",
        "selector_sha256",
        "raw_hash",
        "avatar_url",
        "image",
        "proofs",
        "email",
        "full_name",
    }
    merged = {**entity.attributes, **entity.data}
    parts: list[str] = []
    for key, value in merged.items():
        if key in skip or value in (None, "", [], {}):
            continue
        if isinstance(value, (dict, list)):
            if isinstance(value, list) and len(value) <= 4 and all(
                isinstance(v, (str, int, float, bool)) for v in value
            ):
                value = ", ".join(str(v) for v in value)
            else:
                continue
        parts.append(f"{key}={_cell(value, 55)}")
        if len(parts) >= limit:
            break
    return "; ".join(parts) if parts else "—"


def _pd_entity_rows(entities: list[Entity], empty: str = "_нет_") -> list[str]:
    if not entities:
        return [empty]
    rows = ["| id | label | conf | platform | факты |", "|---|---|---|---|---|"]
    for entity in sorted(entities, key=lambda e: (-e.confidence, e.id)):
        rows.append(
            f"| `{_cell(entity.id, 55)}` | {_cell(entity.label, 50)} | "
            f"{entity.confidence:.2f} | {_cell(entity.platform)} | {_brief_facts(entity)} |"
        )
    return rows


def _gap_rows(run: RunResult) -> list[str]:
    failed = [r for r in run.results if r.status not in ("ok", "not_found")]
    gaps = _all_gaps(run)
    lines: list[str] = []
    if failed:
        lines += ["| источник | статус | ошибка |", "|---|---|---|"]
        for result in failed:
            lines.append(
                f"| {_cell(result.source)} | {result.status} | {_cell(result.error, 160)} |"
            )
        lines.append("")
    if gaps:
        lines += ["| проверка | причина / что не выполнено |", "|---|---|"]
        for gap in gaps:
            source, _, note = gap.partition(": ")
            lines.append(f"| {_cell(source, 50)} | {_cell(note or gap, 180)} |")
    elif not failed:
        lines.append("_Все запланированные проверки выполнены; пробелов нет._")
    return lines


def render_pd_markdown(run: RunResult, summary: dict[str, Any]) -> str:
    graph = build_graph(run.entities, run.edges)
    gstats = stats(graph)
    by_id = {e.id: e for e in run.entities}
    all_prov = [p for r in run.results for p in r.provenance]
    gaps = _all_gaps(run)
    root = next((e for e in run.entities if e.kind == "root"), None)
    selector_sha = root.attributes.get("selector_sha256") if root else None

    def group(kind: str) -> list[Entity]:
        return [e for e in run.entities if e.kind == kind]

    selector_titles = {
        "fio": "ФИО",
        "phone": "телефон",
        "email": "email",
        "contacts": "контакты",
        "inn": "ИНН",
        "snils": "СНИЛС",
        "passport": "паспорт",
        "vu": "водительское удостоверение",
        "documents": "документы",
        "transport": "транспорт",
        "social": "социальная сеть",
        "telegram": "Telegram",
        "online_traces": "онлайн-следы",
        "real_estate": "недвижимость",
        "legal_entity": "юридическое лицо",
        "face": "поиск по лицу",
    }
    title = selector_titles.get(run.selector_kind, run.selector_kind)

    lines: list[str] = [
        f"# mc1h · досье: {title} `{run.selector}`",
        "",
        f"- **run_id:** `{run.run_id}`",
        f"- **создан:** {run.created_at.strftime('%Y-%m-%d %H:%M:%SZ')}",
        f"- **статус:** **{run.status}**",
        f"- **тип селектора:** `{run.selector_kind}`",
    ]
    if run.birth_date:
        lines.append(f"- **дата рождения:** {run.birth_date}")
    if run.assumed:
        lines.append("- **допущения:** " + "; ".join(run.assumed))
    lines += [
        "",
        "> Досье собрано из открытых/легальных источников. Совпадение ФИО, номера "
        "или email не доказывает тождество личности; связи разделены по типу.",
        "",
        "## 1. Резюме",
        "",
        f"- источников проверено: **{summary['sources']['checked']}** — "
        f"ok {summary['sources']['ok']}, not_found {summary['sources']['not_found']}, "
        f"blocked {summary['sources']['blocked']}, error {summary['sources']['error']}, "
        f"timeout {summary['sources']['timeout']}, "
        f"not_configured {summary['sources']['not_configured']}, "
        f"invalid {summary['sources']['invalid']}",
        f"- сущностей: персон **{summary['entities']['persons']}**, "
        f"идентификаторов **{summary['entities']['identifiers']}**, "
        f"организаций **{summary['entities']['organizations']}**, "
        f"записей/утечек **{summary['entities']['records']}**, "
        f"аккаунтов **{summary['entities']['accounts']}**",
        f"- связей: verified **{summary['links']['verified']}**, "
        f"same_as **{summary['links']['same_as']}**, "
        f"handle-only **{summary['links']['handle_only']}**, "
        f"observed_in **{summary['links']['observed_in']}**, "
        f"прочие **{summary['links']['other']}**",
        f"- пробелов/невыполненных проверок: **{len(gaps)}**",
        f"- узлов/рёбер графа: {gstats['nodes']}/{gstats['edges']}",
        "",
        "## 2. Селектор и нормализация",
        "",
        "| параметр | значение |",
        "|---|---|",
        f"| тип | `{run.selector_kind}` |",
        f"| безопасное представление | `{_cell(run.selector, 90)}` |",
        f"| дата рождения | {_cell(run.birth_date)} |",
        f"| SHA-256 селектора (16) | `{_cell(selector_sha[:16] if selector_sha else None, 20)}` |",
        "",
        *(
            [
                "Полные номера СНИЛС/паспорта в графе и отчёте не сохраняются: "
                "только маска и необратимый хеш.",
                "",
            ]
            if run.selector_kind in ("snils", "passport", "vu")
            else []
        ),
        "## 3. Источники",
        "",
        *_source_rows(run),
        "",
        "## 4. Идентификаторы",
        "",
        *_pd_entity_rows(group("identifier")),
        "",
        "## 5. Персоны",
        "",
        *_pd_entity_rows(group("person")),
        "",
        "## 6. Организации",
        "",
        *_pd_entity_rows(group("organization")),
        "",
        "## 7. Профили, записи и утечки",
        "",
        "### 7.1 Аккаунты и профили",
        "",
        *_pd_entity_rows(group("account")),
        "",
        "### 7.2 Записи источников",
        "",
        *_pd_entity_rows(group("record")),
        "",
        "### 7.3 Утечки (HIBP, метаданные)",
        "",
        *_pd_entity_rows(group("breach")),
        "",
        "## 8. Связи",
        "",
        "### 8.1 Верифицированные",
        "",
        *_link_rows(run.edges, by_id, {"verified_link"}),
        "",
        "### 8.2 Прямое соответствие селектору (same_as)",
        "",
        *_link_rows(run.edges, by_id, {"same_as"}),
        "",
        "### 8.3 Гипотезы (handle_match)",
        "",
        *_link_rows(run.edges, by_id, {"handle_match"}),
        "",
        "### 8.4 Наблюдения и регистрация",
        "",
        *_link_rows(
            run.edges,
            by_id,
            {"observed_in", "registered_at", "registered_as", "director_of",
             "founder_of", "identified_as", "affiliated_with", "owns"},
        ),
        "",
        "## 9. Граф",
        "",
        f"Узлов: {gstats['nodes']}, рёбер: {gstats['edges']}, "
        f"персон: {gstats['persons']}, идентификаторов: {gstats['identifiers']}, "
        f"организаций: {gstats['organizations']}, записей: {gstats['records']}.",
        "",
        "```dot",
        to_dot(graph),
        "```",
        "",
        "Связи:",
        "",
        *adjacency_lines(graph),
        "",
        "## 10. Пробелы и сбои",
        "",
        *_gap_rows(run),
        "",
        "По определению не выполняется (правовые/технические ограничения):",
        "",
        "- доступ к теневым базам утечек, кроме официального HIBP API по ключу — "
        "обработка украденных ПД запрещена;",
        "- обход captcha/anti-bot и SQL-инъекции в чужие БД — не выполняются;",
        "- покупка доступа или использование нелегальных API — не выполняются;",
        "- паспорт/СНИЛС → ФИО через МВД/СФР — публичного API нет;",
        "- распознавание лиц/биометрия — не реализовано.",
        "",
        "## 11. Provenance",
        "",
        f"Всего записей: {len(all_prov)}. Время — UTC, момент ответа источника.",
        "",
        *_provenance_rows(all_prov),
        "",
        "## 12. Методика и правовые ограничения",
        "",
        "**Confidence**",
        "",
        "| диапазон | что означает |",
        "|---|---|",
        "| 0.90–0.95 | официальный реестр/HIBP или точное детерминированное соответствие |",
        "| 0.70–0.85 | публичная запись с самоописанием (commit, профиль, объявление) |",
        "| 0.35–0.60 | совпадение ФИО/ника без криптографического подтверждения |",
        "| < 0.35 | слабая гипотеза, требует ручной проверки |",
        "",
        "`same_as` означает «это тот же введённый селектор после нормализации», "
        "а не доказанное тождество человека. `verified_link` ставится только при "
        "криптографическом или явном кросс-подтверждении.",
        "",
        "Оператор обязан иметь законное основание для обработки ПД. Инструмент "
        "не заменяет юридическую проверку и не даёт права на доксинг.",
        "",
        "---",
        "",
        f"Сгенерировано mc1h · run `{run.run_id}` · {len(run.entities)} сущностей, "
        f"{len(run.edges)} связей.",
        "",
    ]
    return "\n".join(lines)


def render_markdown(run: RunResult, summary: dict[str, Any]) -> str:
    if run.selector_kind != "username":
        return render_pd_markdown(run, summary)
    graph = build_graph(run.entities, run.edges)
    gstats = stats(graph)
    by_id = {e.id: e for e in run.entities}
    accounts = [e for e in run.entities if e.kind == "account"]
    artifacts = [e for e in run.entities if e.kind == "artifact"]
    all_prov = [p for r in run.results for p in r.provenance]

    lines: list[str] = []
    lines += [
        f"# mc1h · username `{run.selector}`",
        "",
        f"- **run_id:** `{run.run_id}`",
        f"- **создан:** {run.created_at.strftime('%Y-%m-%d %H:%M:%SZ')}",
        f"- **статус:** **{run.status}**",
        f"- **селектор:** username (нормализовано: `{run.selector.lower()}`)",
    ]
    if run.assumed:
        lines.append("- **допущения:** " + "; ".join(run.assumed))
    if run.secondary:
        lines.append("- **вторичный проход (depth 1):** " + ", ".join(f"`{h}`" for h in run.secondary))
    lines += ["", "> Совпадение handle ≠ тождество личности. Верифицированные связи отделены от гипотез.", ""]

    lines += [
        "## 1. Резюме",
        "",
        f"- источников проверено: **{summary['sources']['checked']}** — "
        f"ok {summary['sources']['ok']}, not_found {summary['sources']['not_found']}, "
        f"blocked {summary['sources']['blocked']}, error {summary['sources']['error']}, "
        f"timeout {summary['sources']['timeout']}",
        f"- аккаунтов: **{summary['entities']['accounts']}**, артефактов: **{summary['entities']['artifacts']}**",
        f"- связей: verified **{summary['links']['verified']}**, "
        f"handle-only **{summary['links']['handle_only']}**, owns **{summary['links']['owns']}**",
        f"- узлов/рёбер графа: {gstats['nodes']}/{gstats['edges']}",
        "",
        "## 2. Источники",
        "",
        *_source_rows(run),
        "",
        "## 3. Сущности",
        "",
        "### 3.1 Аккаунты",
        "",
        *_entity_rows(accounts),
        "",
        "### 3.2 Артефакты (репозитории, пакеты)",
        "",
        *_entity_rows(artifacts),
        "",
        "## 4. Entity resolution",
        "",
        "### 4.1 Верифицированные связи",
        "",
        *_link_rows(run.edges, by_id, {"verified_link"}),
        "",
        "### 4.2 Гипотезы (совпадение handle)",
        "",
        *_link_rows(run.edges, by_id, {"handle_match"}),
        "",
        "## 5. Граф",
        "",
        f"Узлов: {gstats['nodes']}, рёбер: {gstats['edges']}, "
        f"аккаунтов: {gstats['accounts']} (из них placeholder: {gstats['placeholders']}), "
        f"артефактов: {gstats['artifacts']}.",
        "",
        "```dot",
        to_dot(graph),
        "```",
        "",
        "Связи:",
        "",
        *adjacency_lines(graph),
        "",
        "## 6. Пробелы и сбои",
        "",
    ]

    gaps = [r for r in run.results if r.status not in ("ok", "not_found")]
    if gaps:
        lines += ["| источник | статус | ошибка |", "|---|---|---|"]
        for r in gaps:
            lines.append(f"| {_cell(r.source)} | {r.status} | {_cell(r.error, 160)} |")
    else:
        lines.append("_Все выбранные источники ответили без блокировок и ошибок._")

    lines += [
        "",
        "Не реализовано в пайплайне (не зависит от текущего прогона):",
        "",
        "- PyPI user pages не имеют машиночитаемого API профиля — резолвер не реализован;",
        "- Twitter/X закрыт для анонимного доступа — резолвер не реализован;",
        "- Reddit при 403 требует OAuth или residential-прокси (см. раздел 6).",
        "",
        "## 7. Методика",
        "",
        METHOD,
        "",
        "## 8. Provenance",
        "",
        f"Всего записей: {len(all_prov)}. Время — UTC, момент ответа источника.",
        "",
        *_provenance_rows(all_prov),
        "",
        "---",
        "",
        f"Сгенерировано mc1h · run `{run.run_id}` · {len(run.entities)} сущностей, {len(run.edges)} связей.",
        "",
    ]
    return "\n".join(lines)


def write_artifacts(run: RunResult, out_dir: str) -> dict[str, str]:
    summary = summarize(run)
    directory = Path(out_dir) / run.run_id
    directory.mkdir(parents=True, exist_ok=True)
    graph = build_graph(run.entities, run.edges)

    report_path = directory / "report.md"
    report_path.write_text(render_markdown(run, summary), encoding="utf-8")

    entities_path = directory / "entities.json"
    entities_path.write_text(
        json.dumps(
            {
                "run_id": run.run_id,
                "selector": run.selector,
                "entities": [e.model_dump(mode="json") for e in run.entities],
                "edges": [e.model_dump(mode="json") for e in run.edges],
            },
            ensure_ascii=False,
            indent=2,
            default=str,
        ),
        encoding="utf-8",
    )

    dot_path = directory / "graph.dot"
    dot_path.write_text(to_dot(graph), encoding="utf-8")

    graph_path = directory / "graph.json"
    graph_path.write_text(
        json.dumps(to_json(graph), ensure_ascii=False, indent=2, default=str), encoding="utf-8"
    )

    run_path = directory / "run.json"
    run_path.write_text(
        json.dumps(
            {
                "run_id": run.run_id,
                "selector": run.selector,
                "selector_kind": run.selector_kind,
                "birth_date": run.birth_date,
                "created_at": run.created_at.isoformat(),
                "status": run.status,
                "assumed": run.assumed,
                "secondary": run.secondary,
                "summary": summary,
                "gaps": run.gaps,
                "results": [r.model_dump(mode="json") for r in run.results],
            },
            ensure_ascii=False,
            indent=2,
            default=str,
        ),
        encoding="utf-8",
    )

    dossier_path = directory / "dossier.json"
    dossier_path.write_text(
        json.dumps(
            {
                "run_id": run.run_id,
                "selector": run.selector,
                "selector_kind": run.selector_kind,
                "birth_date": run.birth_date,
                "created_at": run.created_at.isoformat(),
                "status": run.status,
                "summary": summary,
                "gaps": summary.get("gaps_list", []),
                "entities": [e.model_dump(mode="json") for e in run.entities],
                "edges": [e.model_dump(mode="json") for e in run.edges],
            },
            ensure_ascii=False,
            indent=2,
            default=str,
        ),
        encoding="utf-8",
    )

    return {
        "report": str(report_path),
        "entities": str(entities_path),
        "graph_dot": str(dot_path),
        "graph_json": str(graph_path),
        "run": str(run_path),
        "dossier": str(dossier_path),
    }