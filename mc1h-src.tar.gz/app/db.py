"""SQLite persistence: runs, entities, edges, provenance."""

from __future__ import annotations

import asyncio
import json
import os
import sqlite3
import threading
from datetime import datetime
from typing import Any

from .schemas import Edge, Entity, Provenance, ResolverResult, RunResult

SCHEMA = """
CREATE TABLE IF NOT EXISTS runs (
    run_id TEXT PRIMARY KEY,
    selector TEXT NOT NULL,
    selector_kind TEXT NOT NULL,
    created_at TEXT NOT NULL,
    status TEXT NOT NULL,
    summary_json TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS entities (
    run_id TEXT NOT NULL,
    entity_id TEXT NOT NULL,
    kind TEXT NOT NULL,
    key TEXT NOT NULL,
    label TEXT NOT NULL,
    confidence REAL NOT NULL,
    attributes_json TEXT NOT NULL,
    selector TEXT,
    platform TEXT,
    profile_url TEXT,
    data_json TEXT NOT NULL DEFAULT '{}',
    raw_hash TEXT,
    PRIMARY KEY (run_id, entity_id)
);
CREATE TABLE IF NOT EXISTS edges (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    run_id TEXT NOT NULL,
    src TEXT NOT NULL,
    dst TEXT NOT NULL,
    relation TEXT NOT NULL,
    confidence REAL NOT NULL,
    note TEXT
);
CREATE TABLE IF NOT EXISTS provenance (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    run_id TEXT NOT NULL,
    entity_id TEXT,
    source TEXT NOT NULL,
    endpoint TEXT NOT NULL,
    query TEXT,
    fetched_at TEXT NOT NULL,
    http_status INTEGER,
    outcome TEXT NOT NULL,
    confidence REAL NOT NULL,
    latency_ms INTEGER,
    note TEXT
);
CREATE INDEX IF NOT EXISTS idx_runs_selector ON runs(selector, created_at);
CREATE INDEX IF NOT EXISTS idx_entities_run ON entities(run_id);
CREATE INDEX IF NOT EXISTS idx_edges_run ON edges(run_id);
CREATE INDEX IF NOT EXISTS idx_prov_run ON provenance(run_id);
"""


class Store:
    """Small synchronous SQLite store; async callers use asyncio.to_thread."""

    def __init__(self, path: str) -> None:
        directory = os.path.dirname(os.path.abspath(path))
        os.makedirs(directory, exist_ok=True)
        self._conn = sqlite3.connect(path, check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._lock = threading.Lock()
        with self._lock:
            self._conn.executescript(SCHEMA)
            self._migrate()
            self._conn.commit()
        self.path = path

    def _migrate(self) -> None:
        """Add Sherlock columns to databases created before v2."""
        columns = {
            row[1] for row in self._conn.execute("PRAGMA table_info(entities)")
        }
        additions = {
            "selector": "TEXT",
            "platform": "TEXT",
            "profile_url": "TEXT",
            "data_json": "TEXT NOT NULL DEFAULT '{}'",
            "raw_hash": "TEXT",
        }
        for name, ddl in additions.items():
            if name not in columns:
                self._conn.execute(f"ALTER TABLE entities ADD COLUMN {name} {ddl}")

    def close(self) -> None:
        with self._lock:
            self._conn.close()

    def _save(self, run: RunResult, summary: dict[str, Any]) -> None:
        with self._lock:
            cur = self._conn
            cur.execute(
                "INSERT OR REPLACE INTO runs(run_id, selector, selector_kind, created_at, status, summary_json)"
                " VALUES (?,?,?,?,?,?)",
                (
                    run.run_id,
                    run.selector,
                    run.selector_kind,
                    run.created_at.isoformat(),
                    run.status,
                    json.dumps(summary, ensure_ascii=False),
                ),
            )
            for e in run.entities:
                cur.execute(
                    "INSERT OR REPLACE INTO entities"
                    " (run_id, entity_id, kind, key, label, confidence, attributes_json,"
                    "  selector, platform, profile_url, data_json, raw_hash)"
                    " VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
                    (
                        run.run_id,
                        e.id,
                        e.kind,
                        e.key,
                        e.label,
                        e.confidence,
                        json.dumps(e.attributes, ensure_ascii=False, default=str),
                        e.selector,
                        e.platform,
                        e.profile_url,
                        json.dumps(e.data, ensure_ascii=False, default=str),
                        e.raw_hash,
                    ),
                )
                for p in e.provenance:
                    self._insert_prov(run.run_id, e.id, p)
            for p in (p for r in run.results for p in r.provenance):
                self._insert_prov(run.run_id, None, p)
            for edge in run.edges:
                cur.execute(
                    "INSERT INTO edges(run_id, src, dst, relation, confidence, note) VALUES (?,?,?,?,?,?)",
                    (run.run_id, edge.src, edge.dst, edge.relation, edge.confidence, edge.note),
                )
            cur.commit()

    def _insert_prov(self, run_id: str, entity_id: str | None, p: Provenance) -> None:
        self._conn.execute(
            "INSERT INTO provenance"
            " (run_id, entity_id, source, endpoint, query, fetched_at, http_status, outcome, confidence, latency_ms, note)"
            " VALUES (?,?,?,?,?,?,?,?,?,?,?)",
            (
                run_id,
                entity_id,
                p.source,
                p.endpoint,
                p.query,
                p.fetched_at.isoformat(),
                p.http_status,
                p.outcome,
                p.confidence,
                p.latency_ms,
                p.note,
            ),
        )

    async def save_run(self, run: RunResult, summary: dict[str, Any]) -> None:
        await asyncio.to_thread(self._save, run, summary)

    def _get_run(self, run_id: str) -> dict[str, Any] | None:
        with self._lock:
            row = self._conn.execute("SELECT * FROM runs WHERE run_id=?", (run_id,)).fetchone()
            if row is None:
                return None
            ents = self._conn.execute(
                "SELECT * FROM entities WHERE run_id=? ORDER BY kind, entity_id", (run_id,)
            ).fetchall()
            edges = self._conn.execute(
                "SELECT * FROM edges WHERE run_id=? ORDER BY id", (run_id,)
            ).fetchall()
            prov = self._conn.execute(
                "SELECT * FROM provenance WHERE run_id=? ORDER BY id", (run_id,)
            ).fetchall()
        return {
            "run": dict(row),
            "summary": json.loads(row["summary_json"]),
            "entities": [dict(x) for x in ents],
            "edges": [dict(x) for x in edges],
            "provenance": [dict(x) for x in prov],
        }

    async def get_run(self, run_id: str) -> dict[str, Any] | None:
        return await asyncio.to_thread(self._get_run, run_id)