"""Selector detection and normalization for the Sherlock-style combine.

The public API accepts either an explicit ``selector_type`` or a raw value.
This module is the single source of truth for both paths, so the CLI, FastAPI
and the Android client classify values in exactly the same way.
"""

from __future__ import annotations

import re

import phonenumbers

from .schemas import SelectorType
from .resolvers.pd.common import (
    EMAIL_RE,
    NAME_RE,
    mask_digits,
    mask_passport,
    mask_phone,
    normalize_email,
    normalize_name,
    parse_date,
)
from .resolvers.pd.inn import inn_checksum_valid
from .resolvers.pd.legal_entity import (
    ogrn_checksum_valid,
    ogrnip_checksum_valid,
)
from .resolvers.pd.online_traces import normalize_online
from .resolvers.pd.real_estate import CADASTRAL_RE, normalize_real_estate
from .resolvers.pd.snils import snils_checksum_valid
from .resolvers.pd.social import normalize_social
from .resolvers.pd.telegram import normalize_telegram
from .resolvers.pd.transport import mask_vin, normalize_transport

PASSPORT_SPACED_RE = re.compile(r"^\d{4}[\s-]\d{6}$")
USERNAME_RE = re.compile(r"^[A-Za-z0-9._-]{1,64}$")
DATE_AT_END_RE = re.compile(r"(?:^|\s)(\d{2}\.\d{2}\.\d{4}|\d{4}-\d{2}-\d{2})$")

COMMANDS: dict[str, SelectorType] = {
    "fio": "fio",
    "phone": "phone",
    "email": "email",
    "contacts": "contacts",
    "inn": "inn",
    "snils": "snils",
    "passport": "passport",
    "vu": "vu",
    "documents": "documents",
    "transport": "transport",
    "vin": "transport",
    "plate": "transport",
    "social": "social",
    "telegram": "telegram",
    "tg": "telegram",
    "tag": "online_traces",
    "online": "online_traces",
    "adr": "real_estate",
    "address": "real_estate",
    "real_estate": "real_estate",
    "legal": "legal_entity",
    "ogrn": "legal_entity",
    "face": "face",
    "username": "username",
}


def parse_command(raw_input: str) -> tuple[SelectorType, str] | None:
    """Parse ``/passport 1234`` into ``("passport", "1234")``."""
    value = raw_input.strip()
    if not value.startswith("/"):
        return None
    head, _, rest = value.partition(" ")
    command = head[1:].lower()
    selector_type = COMMANDS.get(command)
    if selector_type is None:
        raise ValueError(
            f"unknown command /{command}; available: "
            + ", ".join("/" + key for key in sorted(COMMANDS))
        )
    return selector_type, rest.strip()


def split_fio_dob(raw_input: str) -> tuple[str, str | None]:
    """Split ``Иванов Иван Иванович 01.01.1990`` into name and DD.MM.YYYY."""
    value = raw_input.strip()
    match = DATE_AT_END_RE.search(value)
    if not match:
        return value, None
    candidate = match.group(1)
    if parse_date(candidate) is None:
        return value, None
    name = value[: match.start()].strip()
    parts = [p for p in name.split() if p]
    if 2 <= len(parts) <= 3 and all(NAME_RE.fullmatch(p) for p in parts):
        return " ".join(parts), candidate
    return value, None


def _phone_normalized(value: str) -> str | None:
    try:
        number = phonenumbers.parse(value, "RU")
    except phonenumbers.NumberParseException:
        return None
    if not phonenumbers.is_valid_number(number):
        return None
    return phonenumbers.format_number(number, phonenumbers.PhoneNumberFormat.E164)


def normalize_selector(
    selector_type: SelectorType, raw: str
) -> tuple[str, str]:
    """Return ``(canonical, safe_label)`` for storage and reporting."""
    value = raw.strip()
    if selector_type == "fio":
        full, _ = normalize_name(value)
        return full, full
    if selector_type == "email":
        email = normalize_email(value)
        return email, email
    if selector_type == "phone":
        e164 = _phone_normalized(value)
        if e164:
            return e164, mask_phone(e164)
        return value, mask_digits(value, keep=2)
    if selector_type in ("inn", "legal_entity"):
        digits = re.sub(r"\D", "", value)
        return digits, digits
    if selector_type == "snils":
        digits = re.sub(r"\D", "", value)
        safe = f"СНИЛС ***-**-*** {digits[-2:]}" if len(digits) >= 2 else "СНИЛС"
        return digits, safe
    if selector_type == "passport":
        digits = re.sub(r"\D", "", value)
        if len(digits) == 10:
            return digits, mask_passport(digits[:4], digits[4:])
        return digits, mask_digits(value, keep=2)
    if selector_type in ("vu", "documents"):
        digits = re.sub(r"\D", "", value)
        safe = f"ВУ **{digits[-2:]}" if len(digits) >= 2 else "документ"
        return digits, safe
    if selector_type == "transport":
        parsed = normalize_transport(value)
        if parsed:
            kind, normalized = parsed
            return normalized, normalized if kind == "plate" else mask_vin(normalized)
        return value.upper(), value.upper()
    if selector_type == "social":
        parsed = normalize_social(value)
        if parsed:
            platform, handle, url = parsed
            return url, f"{platform}:{handle}"
        return value, value
    if selector_type == "telegram":
        parsed = normalize_telegram(value)
        if parsed:
            kind, normalized = parsed
            return normalized, ("@" + normalized if kind == "handle" else "tg" + normalized)
        return value, value
    if selector_type == "online_traces":
        parsed = normalize_online(value)
        if parsed:
            return parsed[1], parsed[1]
        return value, value
    if selector_type == "real_estate":
        parsed = normalize_real_estate(value)
        if parsed:
            kind, normalized = parsed
            return normalized, normalized
        return value, value
    if selector_type == "face":
        return value, value
    return value, value


def _detected(selector_type: SelectorType, value: str) -> tuple[SelectorType, str]:
    canonical, _ = normalize_selector(selector_type, value)
    return selector_type, canonical


def detect_selector(raw_input: str) -> tuple[SelectorType, str]:
    """Detect a selector type and return ``(type, normalized value)``.

    Explicit commands win.  Detection is conservative: ambiguous bare 10-digit
    values are not silently turned into a passport; use ``/passport`` or
    ``/vu`` when the document type is known.
    """
    value = raw_input.strip()
    if not value:
        raise ValueError("empty selector")

    command = parse_command(value)
    if command is not None:
        selector_type, command_value = command
        if not command_value:
            raise ValueError(f"command /{selector_type} needs a value")
        if selector_type == "fio":
            name, _ = split_fio_dob(command_value)
            return _detected("fio", name)
        return _detected(selector_type, command_value)

    if EMAIL_RE.fullmatch(value):
        return _detected("email", value)

    social = normalize_social(value)
    if social:
        return _detected("social", value)

    telegram = normalize_telegram(value)
    if telegram and (
        value.startswith("@")
        or value.lower().startswith("t.me/")
        or value.lower().startswith("https://t.me/")
        or re.fullmatch(r"tg\d{5,15}", value, flags=re.I)
    ):
        return _detected("telegram", value)

    online = normalize_online(value)
    if online and online[0] in ("domain", "ip"):
        return _detected("online_traces", value)

    passport_spaced = PASSPORT_SPACED_RE.fullmatch(value)
    if passport_spaced:
        return _detected("passport", value)

    transport = normalize_transport(value)
    if transport:
        return _detected("transport", value)

    compact = re.sub(r"\s+", "", value)
    if CADASTRAL_RE.fullmatch(compact):
        return _detected("real_estate", value)

    digits = re.sub(r"\D", "", value)
    if len(digits) == 11 and snils_checksum_valid(digits):
        return _detected("snils", digits)

    if len(digits) in (10, 12) and inn_checksum_valid(digits):
        return _detected("inn", digits)

    if len(digits) == 13 and ogrn_checksum_valid(digits):
        return _detected("legal_entity", digits)

    if len(digits) == 15 and ogrnip_checksum_valid(digits):
        return _detected("legal_entity", digits)

    if value.startswith("+") or (
        len(digits) == 11 and digits[:1] in ("7", "8")
    ):
        phone = _phone_normalized(value)
        if phone:
            return _detected("phone", value)

    name, dob = split_fio_dob(value)
    parts = [p for p in name.split() if p]
    if 2 <= len(parts) <= 3 and all(NAME_RE.fullmatch(p) for p in parts):
        return _detected("fio", name)

    if USERNAME_RE.fullmatch(value) and not value.isdigit():
        return "username", value

    raise ValueError(
        "cannot detect selector type; pass selector_type explicitly. "
        "Available: fio, contacts, transport, social, telegram, documents, "
        "online_traces, real_estate, legal_entity, face, username, phone, "
        "email, inn, snils, passport, vu"
    )