"""Pipeline orchestration: selector -> resolvers -> merge -> graph -> persist."""

from __future__ import annotations

import asyncio
import logging
import re
import time
import uuid
from datetime import datetime, timezone

from .config import SETTINGS, Settings
from .db import Store
from .opsec import HttpFetcher
from .resolvers import ALL, PLATFORM_TO_SOURCE, select
from .schemas import Edge, Entity, ResolverResult, RunResult

log = logging.getLogger("mc1h.pipeline")

HANDLE_RE = re.compile(r"^[A-Za-z0-9._-]{1,64}$")


def normalize_username(raw: str) -> str:
    handle = raw.strip()
    if handle.startswith("@"):
        handle = handle[1:]
    if not HANDLE_RE.fullmatch(handle) or handle in (".", ".."):
        raise ValueError(
            "username must match ^[A-Za-z0-9._-]{1,64}$ after stripping a leading '@'"
        )
    return handle


class UsernamePipeline:
    def __init__(
        self,
        settings: Settings | None = None,
        store: Store | None = None,
        fetcher: HttpFetcher | None = None,
    ) -> None:
        self.s = settings or SETTINGS
        self.store = store
        self.fetcher = fetcher or HttpFetcher(self.s)
        self._owns_fetcher = fetcher is None
        self._source_sems: dict[str, asyncio.Semaphore] = {}

    async def aclose(self) -> None:
        if self._owns_fetcher:
            await self.fetcher.aclose()

    async def run(self, username: str, sources: list[str] | None = None) -> RunResult:
        handle = normalize_username(username)
        resolvers = select(sources)
        run_id = (
            datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
            + "-"
            + uuid.uuid4().hex[:8]
        )

        first_pass = list(await asyncio.gather(*(self._one(r, handle) for r in resolvers)))
        results: list[ResolverResult] = list(first_pass)

        secondary_targets = self._secondary_targets(first_pass, handle)
        if secondary_targets:
            second = await asyncio.gather(
                *(
                    self._one(ALL[PLATFORM_TO_SOURCE[platform]], tag, suffix=f"2nd:{tag}")
                    for platform, tag in secondary_targets
                )
            )
            results.extend(second)

        entities, edges = self._merge(results, handle)
        status = "complete" if all(
            r.status in ("ok", "not_found") for r in results
        ) else "partial"

        assumed = []
        if not self.s.proxies:
            assumed.append("MC1H_PROXIES не задан — запросы идут напрямую с IP хоста")
        assumed.append("handle сравнивается регистронезависимо; регистр платформы сохраняется в атрибутах")
        if secondary_targets:
            assumed.append(
                "depth-1 добор по верифицированным кросс-ссылкам: "
                + ", ".join(tag for _, tag in secondary_targets)
            )

        run = RunResult(
            run_id=run_id,
            selector=handle,
            selector_kind="username",
            created_at=datetime.now(timezone.utc),
            status=status,
            entities=entities,
            edges=edges,
            results=results,
            assumed=assumed,
            secondary=[tag for _, tag in secondary_targets],
        )

        if self.store is not None:
            try:
                from .report import summarize

                await self.store.save_run(run, summarize(run))
            except Exception as exc:  # persistence must not destroy a finished run
                log.warning("failed to persist run %s: %s", run_id, exc)

        return run

    async def _one(
        self, resolver, handle: str, suffix: str | None = None
    ) -> ResolverResult:
        label = resolver.name if not suffix else f"{resolver.name}·{suffix}"
        started = time.monotonic()
        sem = self._source_sems.setdefault(
            resolver.name, asyncio.Semaphore(max(1, self.s.per_source_concurrency))
        )
        try:
            async with sem:
                result = await asyncio.wait_for(
                    resolver.resolve(handle, self.fetcher),
                    timeout=self.s.resolver_timeout_s,
                )
        except asyncio.TimeoutError:
            result = ResolverResult(
                source=label,
                status="timeout",
                error=f"resolver exceeded {self.s.resolver_timeout_s:.0f}s",
            )
        except Exception as exc:  # resolver bugs must not kill the run
            result = ResolverResult(
                source=label, status="error", error=f"{exc.__class__.__name__}: {exc}"
            )
        result.source = label
        if not result.elapsed_ms:
            result.elapsed_ms = int((time.monotonic() - started) * 1000)
        return result

    def _secondary_targets(
        self, results: list[ResolverResult], primary: str
    ) -> list[tuple[str, str]]:
        targets: list[tuple[str, str]] = []
        seen: set[tuple[str, str]] = set()
        for result in results:
            for edge in result.edges:
                if edge.relation != "verified_link":
                    continue
                parts = edge.dst.split(":", 2)
                if len(parts) != 3:
                    continue
                _, platform, tag = parts
                key = (platform.lower(), tag.lower())
                if key in seen or tag.lower() == primary.lower():
                    continue
                if platform.lower() not in PLATFORM_TO_SOURCE:
                    continue
                seen.add(key)
                targets.append((platform.lower(), tag))
                if len(targets) >= self.s.max_secondary_handles:
                    return targets
        return targets

    def _merge(
        self, results: list[ResolverResult], handle: str
    ) -> tuple[list[Entity], list[Edge]]:
        merged: dict[str, Entity] = {}
        for result in results:
            for entity in result.entities:
                current = merged.get(entity.id)
                if current is None:
                    merged[entity.id] = entity.model_copy(deep=True)
                    continue
                for key, value in entity.attributes.items():
                    if current.attributes.get(key) in (None, "", [], {}):
                        current.attributes[key] = value
                known = {(p.source, p.endpoint) for p in current.provenance}
                for p in entity.provenance:
                    if (p.source, p.endpoint) not in known:
                        current.provenance.append(p)
                        known.add((p.source, p.endpoint))
                current.confidence = max(current.confidence, entity.confidence)

        root = Entity.make(
            "root",
            "selector",
            handle,
            attributes={"selector_kind": "username", "normalized": handle.lower()},
            provenance=[],
            confidence=1.0,
        )
        merged[root.id] = root

        edge_map: dict[tuple[str, str, str], Edge] = {}
        for result in results:
            for edge in result.edges:
                key = (edge.src, edge.dst, edge.relation)
                current = edge_map.get(key)
                if current is None or edge.confidence > current.confidence:
                    edge_map[key] = edge

        verified_pairs = {
            (e.src, e.dst) for e in edge_map.values() if e.relation == "verified_link"
        }
        final_edges = [
            e
            for key, e in edge_map.items()
            if not (e.relation == "handle_match" and (e.src, e.dst) in verified_pairs)
        ]

        verified_targets = {dst for _, dst in verified_pairs}
        for entity in merged.values():
            if entity.id in verified_targets and entity.kind == "account":
                entity.confidence = max(entity.confidence, 0.9)
                entity.attributes["resolution"] = "verified_link"

        return list(merged.values()), final_edges


def _summary_for_db(run: RunResult) -> dict:
    statuses: dict[str, int] = {}
    for r in run.results:
        statuses[r.status] = statuses.get(r.status, 0) + 1
    return {
        "sources": statuses,
        "accounts": len([e for e in run.entities if e.kind == "account"]),
        "artifacts": len([e for e in run.entities if e.kind == "artifact"]),
        "verified_links": len([e for e in run.edges if e.relation == "verified_link"]),
        "handle_links": len([e for e in run.edges if e.relation == "handle_match"]),
        "secondary": run.secondary,
    }