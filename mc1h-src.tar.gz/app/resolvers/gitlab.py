"""GitLab.com public users API.

API: https://docs.gitlab.com/ee/api/users.html#for-normal-users
Auth: none for public profiles (rate-limited per IP)
"""

from __future__ import annotations

from urllib.parse import quote

from ..opsec import HttpFetcher
from ..schemas import ResolverResult
from .base import Resolver, account, clean, edge, iso, prov

API = "https://gitlab.com/api/v4"


class GitLabResolver(Resolver):
    name = "gitlab"
    platform = "gitlab"

    async def resolve(self, handle: str, fetcher: HttpFetcher) -> ResolverResult:
        url = f"{API}/users?username={quote(handle)}"
        res = await fetcher.get_json(url)
        if not res.ok:
            return self.result(
                res.outcome,
                provenance=[prov("gitlab", url, query=f"username={handle}", outcome=res.outcome,
                                 http_status=res.status, latency_ms=res.elapsed_ms)],
                error=res.error,
            )
        rows = res.payload if isinstance(res.payload, list) else []
        match = next(
            (r for r in rows if isinstance(r, dict) and str(r.get("username", "")).lower() == handle.lower()),
            None,
        )
        p = prov("gitlab", url, query=f"username={handle}", http_status=res.status,
                 latency_ms=res.elapsed_ms, confidence=0.7 if match else 0.0,
                 note=f"{len(rows)} candidates returned")
        if match is None:
            p.outcome = "not_found"
            return self.result("not_found", provenance=[p], error=None)

        entity = account(
            "gitlab", str(match["username"]), match.get("name") or str(match["username"]), p, 0.7,
            **clean({
                "user_id": match.get("id"),
                "state": match.get("state"),
                "web_url": match.get("web_url"),
                "public_email": match.get("public_email"),
                "bio": match.get("bio"),
                "location": match.get("location"),
                "organization": match.get("organization"),
                "job_title": match.get("job_title"),
                "created_at": iso(match.get("created_at")),
                "avatar_url": match.get("avatar_url"),
            }),
        )
        e = edge("root:selector", entity.id, "handle_match", 0.7, p,
                 note="exact GitLab username match")
        return self.result("ok", entities=[entity], edges=[e], provenance=[p])