"""DEV Community (dev.to) profile.

API: https://developers.forem.com/api/v1#tag/users/operation/getUserByUsername
Auth: none for public users.
dev.to exposes github_username / twitter_username on the profile, which acts as a
platform-declared cross-reference (stronger than handle equality, weaker than proof).
"""

from __future__ import annotations

from urllib.parse import quote

from ..opsec import HttpFetcher
from ..schemas import ResolverResult
from .base import Resolver, account, clean, edge, iso, prov


class DevToResolver(Resolver):
    name = "devto"
    platform = "devto"

    async def resolve(self, handle: str, fetcher: HttpFetcher) -> ResolverResult:
        url = f"https://dev.to/api/users/by_username?url={quote(handle)}"
        res = await fetcher.get_json(url)
        if not res.ok:
            return self.result(
                res.outcome,
                provenance=[prov("devto", url, query=f"username={handle}", outcome=res.outcome,
                                 http_status=res.status, latency_ms=res.elapsed_ms)],
                error=res.error,
            )
        data = res.payload if isinstance(res.payload, dict) else {}
        username = data.get("username")
        if not username:
            return self.result("not_found",
                               provenance=[prov("devto", url, query=f"username={handle}",
                                                outcome="not_found", http_status=res.status,
                                                latency_ms=res.elapsed_ms)])

        confidence = 0.7 if str(username).lower() == handle.lower() else 0.5
        p = prov("devto", url, query=f"username={username}", http_status=res.status,
                 latency_ms=res.elapsed_ms, confidence=confidence,
                 note="profile self-declares github/twitter handles")
        entity = account(
            "devto", str(username), data.get("name") or str(username), p, confidence,
            **clean({
                "user_id": data.get("id"),
                "summary": data.get("summary"),
                "location": data.get("location"),
                "website_url": data.get("website_url"),
                "github_username": data.get("github_username"),
                "twitter_username": data.get("twitter_username"),
                "joined_at": iso(data.get("joined_at")),
                "profile_url": f"https://dev.to/{username}",
                "avatar_url": data.get("profile_image"),
            }),
        )
        entities = [entity]
        edges = [edge("root:selector", entity.id, "handle_match", confidence, p,
                      note="exact dev.to username match")]
        provenance = [p]

        for platform, declared in (("github", data.get("github_username")),
                                   ("twitter", data.get("twitter_username"))):
            if not declared:
                continue
            p_link = prov("devto", url, query=f"declared {platform}={declared}",
                          http_status=res.status, latency_ms=res.elapsed_ms, confidence=0.8,
                          note="self-declared on dev.to profile")
            target = f"account:{platform}:{str(declared).lower()}"
            edges.append(edge(entity.id, target, "verified_link", 0.8, p_link,
                              note=f"dev.to profile declares {platform} handle"))

        return self.result("ok", entities=entities, edges=edges, provenance=provenance)