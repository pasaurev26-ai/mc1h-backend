"""Недвижимость: кадастровый номер и адрес.

Cadastral numbers are format-validated.  Public cadastral-map data is requested
from the public PKK endpoint (or a user-supplied endpoint), while addresses are
geocoded with Nominatim.  Ownership/ЕГРН extracts are not public and stay gaps.
"""

from __future__ import annotations

import re
from urllib.parse import quote, urlencode

from ...opsec import HttpFetcher
from ...schemas import ResolverResult
from ..base import edge, prov
from .base import PDResolver, ResolveContext
from .common import (
    gap_note,
    hash_json,
    local_prov,
    pd_entity,
    short_hash,
)

CADASTRAL_RE = re.compile(r"^\d{2}:\d{2}:\d{7}:\d+$")
DEFAULT_PKK = "https://pkk.rosreestr.ru/api/features/1/"
DEFAULT_NOMINATIM = "https://nominatim.openstreetmap.org/search"


def normalize_real_estate(raw: str) -> tuple[str, str] | None:
    value = raw.strip()
    if not value:
        return None
    compact = re.sub(r"\s+", "", value)
    if CADASTRAL_RE.fullmatch(compact):
        return "cadastral", compact
    return "address", " ".join(value.split())


def _items(payload: object) -> list[dict]:
    if isinstance(payload, list):
        return [x for x in payload if isinstance(x, dict)]
    if isinstance(payload, dict):
        for key in ("items", "data", "results", "features"):
            value = payload.get(key)
            if isinstance(value, list):
                return [x for x in value if isinstance(x, dict)]
        if isinstance(payload.get("feature"), dict):
            return [payload["feature"]]
    return []


def _pick(item: dict, *keys: str) -> str | None:
    for key in keys:
        value = item.get(key)
        if value not in (None, "", [], {}):
            return str(value)
    return None


class RealEstateResolver(PDResolver):
    name = "real_estate"
    selector_type = "real_estate"

    async def resolve(
        self, ctx: ResolveContext, fetcher: HttpFetcher
    ) -> ResolverResult:
        parsed = normalize_real_estate(ctx.raw)
        if parsed is None:
            return self.result("invalid", error="Пустой адрес/кадастровый номер")
        kind, value = parsed
        if kind == "cadastral":
            return await self._cadastral(ctx, fetcher, value)
        return await self._address(ctx, fetcher, value)

    async def _cadastral(
        self, ctx: ResolveContext, fetcher: HttpFetcher, cadastral: str
    ) -> ResolverResult:
        p = local_prov(
            "cadastral-format",
            cadastral,
            0.95,
            "format validation only; it does not prove title/ownership",
        )
        identifier = pd_entity(
            "identifier",
            f"cadastral:{cadastral}",
            cadastral,
            p,
            0.95,
            selector=cadastral,
            platform="rosreestr",
            data={"cadastral_number": cadastral, "format_valid": True},
            raw_hash=hash_json({"cadastral": cadastral}),
        )
        entities = [identifier]
        provenance = [p]
        edges = [
            edge(
                ctx.root_id,
                identifier.id,
                "same_as",
                1.0,
                p,
                note="format-validated cadastral number",
            )
        ]
        gaps: list[str] = []

        base = (ctx.settings.rosreestr_api_url or DEFAULT_PKK).rstrip("/")
        url = f"{base}/{quote(cadastral, safe=':')}"
        if ctx.settings.rosreestr_api_key:
            url += ("&" if "?" in url else "?") + urlencode(
                {"key": ctx.settings.rosreestr_api_key}
            )
        res = await fetcher.get_json(
            url, headers={"Accept": "application/json", "Referer": "https://pkk.rosreestr.ru/"}
        )
        if not res.ok:
            provenance.append(
                prov(
                    "rosreestr-pkk",
                    base,
                    query=cadastral,
                    http_status=res.status,
                    outcome=res.outcome,
                    latency_ms=res.elapsed_ms,
                    note=res.error,
                )
            )
            gaps.append(
                gap_note(
                    "Росреестр/ПКК",
                    f"публичная кадастровая карта не ответила ({res.outcome}): "
                    f"{res.error or 'no data'}",
                )
            )
        else:
            items = _items(res.payload)
            if not items:
                provenance.append(
                    prov(
                        "rosreestr-pkk",
                        base,
                        query=cadastral,
                        http_status=res.status,
                        outcome="not_found",
                        latency_ms=res.elapsed_ms,
                        note="no feature",
                    )
                )
                gaps.append(
                    gap_note("Росреестр/ПКК", "запись по кадастровому номеру не найдена")
                )
            for item in items[:5]:
                attrs = item.get("attrs") if isinstance(item.get("attrs"), dict) else item
                p_reg = prov(
                    "rosreestr-pkk",
                    base,
                    query=cadastral,
                    http_status=res.status,
                    confidence=0.85,
                    latency_ms=res.elapsed_ms,
                    note="public cadastral map attributes; not an ЕГРН title extract",
                )
                provenance.append(p_reg)
                record = pd_entity(
                    "record",
                    f"cadastral:{short_hash(hash_json(item))}",
                    _pick(attrs, "address", "addr", "cn") or cadastral,
                    p_reg,
                    0.85,
                    selector=cadastral,
                    platform="rosreestr",
                    data={
                        "cadastral_number": cadastral,
                        "address": _pick(attrs, "address", "addr"),
                        "category": _pick(attrs, "category", "category_type"),
                        "area": _pick(attrs, "area", "area_value"),
                        "cad_cost": _pick(attrs, "cad_cost", "cad_cost_value"),
                        "cost": _pick(attrs, "cost", "cost_value"),
                        "land_record_type": _pick(attrs, "land_record_type"),
                        "readable_address": _pick(attrs, "readable_address"),
                    },
                    raw_hash=hash_json(item),
                )
                entities.append(record)
                edges.append(
                    edge(
                        identifier.id,
                        record.id,
                        "observed_in",
                        0.85,
                        p_reg,
                        note="public cadastral map record",
                    )
                )

        gaps.append(
            gap_note(
                "ЕГРН",
                "права собственности и полная выписка не выдаются публично; "
                "нужен официальный доступ/согласие правообладателя",
            )
        )
        return self.result(
            "ok",
            entities=entities,
            edges=edges,
            provenance=provenance,
            gaps=gaps,
        )

    async def _address(
        self, ctx: ResolveContext, fetcher: HttpFetcher, address: str
    ) -> ResolverResult:
        p = local_prov(
            "address-normalize",
            address,
            0.70,
            "address normalization only; geocoding follows",
        )
        identifier = pd_entity(
            "identifier",
            f"address:{short_hash(address)}",
            address,
            p,
            0.70,
            selector=address,
            platform="address",
            data={"address": address, "kind": "address"},
            raw_hash=hash_json({"address": address}),
        )
        entities = [identifier]
        provenance = [p]
        edges = [
            edge(
                ctx.root_id,
                identifier.id,
                "same_as",
                1.0,
                p,
                note="normalized address selector",
            )
        ]
        gaps: list[str] = []

        base = ctx.settings.nominatim_url or DEFAULT_NOMINATIM
        url = base + "?" + urlencode(
            {
                "q": address,
                "format": "jsonv2",
                "limit": 5,
                "addressdetails": 1,
            }
        )
        res = await fetcher.get_json(
            url,
            headers={
                "Accept": "application/json",
                "Accept-Language": "ru,en;q=0.8",
            },
        )
        if not res.ok:
            provenance.append(
                prov(
                    "nominatim",
                    base,
                    query=address,
                    http_status=res.status,
                    outcome=res.outcome,
                    latency_ms=res.elapsed_ms,
                    note=res.error,
                )
            )
            gaps.append(gap_note("Nominatim", f"геокодирование не выполнено: {res.error}"))
        else:
            items = _items(res.payload)
            if not items:
                provenance.append(
                    prov(
                        "nominatim",
                        base,
                        query=address,
                        http_status=res.status,
                        outcome="not_found",
                        latency_ms=res.elapsed_ms,
                        note="no geocoding result",
                    )
                )
                gaps.append(gap_note("Nominatim", "адрес не найден"))
            for item in items[:5]:
                p_geo = prov(
                    "nominatim",
                    base,
                    query=address,
                    http_status=res.status,
                    confidence=0.70,
                    latency_ms=res.elapsed_ms,
                    note="OpenStreetMap geocoding; not a Rosreestr registry record",
                )
                provenance.append(p_geo)
                record = pd_entity(
                    "record",
                    f"geocode:{short_hash(hash_json(item))}",
                    str(item.get("display_name") or address),
                    p_geo,
                    0.70,
                    selector=address,
                    platform="osm",
                    data={
                        "display_name": item.get("display_name"),
                        "lat": item.get("lat"),
                        "lon": item.get("lon"),
                        "type": item.get("type"),
                        "category": item.get("category") or item.get("class"),
                        "osm_id": item.get("osm_id"),
                        "address": item.get("address"),
                    },
                    raw_hash=hash_json(item),
                )
                entities.append(record)
                edges.append(
                    edge(
                        identifier.id,
                        record.id,
                        "observed_in",
                        0.70,
                        p_geo,
                        note="public OSM geocoding result",
                    )
                )

        gaps.append(
            gap_note(
                "Росреестр/ПКК",
                "поиск по адресу в Росреестре требует отдельного API/ключа; "
                "Nominatim даёт координаты, но не право собственности",
            )
        )
        return self.result(
            "ok",
            entities=entities,
            edges=edges,
            provenance=provenance,
            gaps=gaps,
        )