"""Транспорт: госномер РФ и VIN.

Only format validation and an optional, user-supplied legal registry endpoint
are used.  Public ГИБДД/ЕАИСТО services with captcha are never bypassed: when
no legal endpoint is configured the check is reported as a gap.
"""

from __future__ import annotations

import re
from urllib.parse import urlencode

from ...opsec import HttpFetcher
from ...schemas import ResolverResult
from ..base import edge, prov
from .base import PDResolver, ResolveContext
from .common import (
    gap_note,
    hash_json,
    local_prov,
    pd_entity,
    short_hash,
)

PLATE_LETTERS = "АВЕКМНОРСТУХ"
PLATE_RE = re.compile(r"^[А-ЯЁ]\d{3}[А-ЯЁ]{2}\d{2,3}$")
PLATE_STANDARD_RE = re.compile(rf"^[{PLATE_LETTERS}]\d{{3}}[{PLATE_LETTERS}]{{2}}\d{{2,3}}$")
VIN_RE = re.compile(r"^[A-HJ-NPR-Z0-9]{17}$")

# Lookalike Latin letters are frequently typed in Russian plates.
_LATIN_TO_CYR = str.maketrans("ABEKMHOPCTYX", "АВЕКМНОРСТУХ")


def normalize_transport(raw: str) -> tuple[str, str] | None:
    """Return (``plate``|``vin``, canonical) or None for an invalid value."""
    value = re.sub(r"[\s-]+", "", raw.strip()).upper()
    if not value:
        return None

    cyrillic = value.translate(_LATIN_TO_CYR)
    if PLATE_RE.fullmatch(cyrillic):
        return "plate", cyrillic
    if VIN_RE.fullmatch(value):
        return "vin", value
    return None


def mask_vin(vin: str) -> str:
    if len(vin) < 8:
        return "***"
    return vin[:3] + "*" * (len(vin) - 7) + vin[-4:]


def _items(payload: object) -> list[dict]:
    if isinstance(payload, list):
        return [x for x in payload if isinstance(x, dict)]
    if isinstance(payload, dict):
        for key in ("items", "data", "results", "records", "vehicles"):
            value = payload.get(key)
            if isinstance(value, list):
                return [x for x in value if isinstance(x, dict)]
    return []


def _pick(item: dict, *keys: str) -> str | None:
    for key in keys:
        value = item.get(key)
        if value not in (None, "", [], {}):
            return str(value)
    return None


class TransportResolver(PDResolver):
    name = "transport"
    selector_type = "transport"

    async def resolve(
        self, ctx: ResolveContext, fetcher: HttpFetcher
    ) -> ResolverResult:
        parsed = normalize_transport(ctx.raw)
        if parsed is None:
            return self.result(
                "invalid",
                error="Неверный формат: нужен госномер РФ (А123БВ777) или VIN (17 символов)",
            )

        kind, value = parsed
        safe = value if kind == "plate" else mask_vin(value)
        p = local_prov(
            "transport-format",
            safe,
            0.90,
            "format validation only; it does not prove registration or ownership",
        )
        identifier = pd_entity(
            "identifier",
            f"transport:{kind}:{value}",
            safe,
            p,
            0.90,
            selector=safe,
            platform=kind,
            data={
                "transport_kind": kind,
                "plate": value if kind == "plate" else None,
                "vin": value if kind == "vin" else None,
                "region": value[-2:] if kind == "plate" and len(value) >= 9 else None,
                "format_valid": True,
                "standard_letters": bool(
                    kind == "plate" and PLATE_STANDARD_RE.fullmatch(value)
                ),
            },
            raw_hash=hash_json({"kind": kind, "value": value}),
        )
        entities = [identifier]
        provenance = [p]
        edges = [
            edge(
                ctx.root_id,
                identifier.id,
                "same_as",
                1.0,
                p,
                note="normalized transport identifier from the input",
            )
        ]
        gaps: list[str] = []

        if not ctx.settings.gibdd_api_url or not ctx.settings.gibdd_api_key:
            gaps.append(
                gap_note(
                    "ГИБДД/ЕАИСТО",
                    "поиск по госномеру/VIN не выполнен: нужны MC1H_GIBDD_API_URL "
                    "и MC1H_GIBDD_API_KEY (легальный API/партнёр); публичные формы "
                    "с captcha не обходятся",
                )
            )
        else:
            base = ctx.settings.gibdd_api_url
            sep = "&" if "?" in base else "?"
            params = {"key": ctx.settings.gibdd_api_key, kind: value}
            res = await fetcher.get_json(base + sep + urlencode(params))
            if not res.ok:
                provenance.append(
                    prov(
                        "gibdd",
                        base,
                        query=safe,
                        http_status=res.status,
                        outcome=res.outcome,
                        latency_ms=res.elapsed_ms,
                        note=res.error,
                    )
                )
                gaps.append(gap_note("ГИБДД/ЕАИСТО", f"запрос не выполнен: {res.error}"))
            else:
                items = _items(res.payload)
                if not items:
                    provenance.append(
                        prov(
                            "gibdd",
                            base,
                            query=safe,
                            http_status=res.status,
                            outcome="not_found",
                            latency_ms=res.elapsed_ms,
                            note="no registry record",
                        )
                    )
                    gaps.append(
                        gap_note(
                            "ГИБДД/ЕАИСТО",
                            "API ответил без записей — регистрация может отсутствовать "
                            "или быть недоступна в выбранном контуре",
                        )
                    )
                for item in items[:10]:
                    p_reg = prov(
                        "gibdd",
                        base,
                        query=safe,
                        http_status=res.status,
                        confidence=0.90,
                        latency_ms=res.elapsed_ms,
                        note="user-supplied legal registry endpoint",
                    )
                    provenance.append(p_reg)
                    record = pd_entity(
                        "record",
                        f"gibdd:{short_hash(hash_json(item))}",
                        _pick(item, "title", "name", "model", "mark", "label")
                        or f"ТС {value}",
                        p_reg,
                        0.90,
                        selector=safe,
                        platform="gibdd",
                        data={
                            "plate": _pick(item, "plate", "gosnomer", "number"),
                            "vin": _pick(item, "vin", "VIN"),
                            "make": _pick(item, "make", "mark", "brand"),
                            "model": _pick(item, "model"),
                            "year": _pick(item, "year", "god_vypuska"),
                            "color": _pick(item, "color", "colour"),
                            "status": _pick(item, "status"),
                            "region": _pick(item, "region"),
                        },
                        raw_hash=hash_json(item),
                    )
                    entities.append(record)
                    edges.append(
                        edge(
                            identifier.id,
                            record.id,
                            "observed_in",
                            0.90,
                            p_reg,
                            note="record from the user-supplied registry endpoint",
                        )
                    )

        return self.result(
            "ok",
            entities=entities,
            edges=edges,
            provenance=provenance,
            gaps=gaps,
        )