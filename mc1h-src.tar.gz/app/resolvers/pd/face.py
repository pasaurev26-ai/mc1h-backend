"""Поиск по лицу: только через явно настроенный легальный API.

There is no public face-search API and biometric processing is regulated.  When
MC1H_FACE_API_URL + MC1H_FACE_API_KEY are absent the resolver returns an
explicit ``not_configured`` result and a gap.  If configured, the endpoint is
called with the image URL; the provider's answer is recorded as a hypothesis.
"""

from __future__ import annotations

from urllib.parse import urlsplit

from ...opsec import HttpFetcher
from ...schemas import ResolverResult
from ..base import edge, prov
from .base import PDResolver, ResolveContext
from .common import (
    gap_note,
    hash_json,
    pd_entity,
    short_hash,
)


def normalize_face(raw: str) -> str | None:
    value = raw.strip()
    if not value:
        return None
    parts = urlsplit(value)
    if parts.scheme not in ("http", "https") or not parts.netloc:
        return None
    return value


def _items(payload: object) -> list[dict]:
    if isinstance(payload, list):
        return [x for x in payload if isinstance(x, dict)]
    if isinstance(payload, dict):
        for key in ("items", "results", "data", "matches"):
            value = payload.get(key)
            if isinstance(value, list):
                return [x for x in value if isinstance(x, dict)]
    return []


class FaceResolver(PDResolver):
    name = "face"
    selector_type = "face"

    async def resolve(
        self, ctx: ResolveContext, fetcher: HttpFetcher
    ) -> ResolverResult:
        image_url = normalize_face(ctx.raw)
        if image_url is None:
            return self.result(
                "invalid",
                error="Нужен публичный http(s)-URL изображения для поиска по лицу",
            )
        gap = gap_note(
            "face",
            "биометрический поиск выполняется только через легальный API "
            "с согласием/законным основанием; без MC1H_FACE_API_URL и "
            "MC1H_FACE_API_KEY он не запускается",
        )
        if not ctx.settings.face_api_url or not ctx.settings.face_api_key:
            return self.result(
                "not_configured",
                error="face API не настроен",
                gaps=[gap],
            )

        p_req = prov(
            "face-api",
            ctx.settings.face_api_url,
            query=image_url,
            confidence=0.0,
            note="request to user-supplied legal biometric API",
        )
        res = await fetcher.post_json(
            ctx.settings.face_api_url,
            {"image_url": image_url},
            headers={
                "Authorization": f"Bearer {ctx.settings.face_api_key}",
                "Accept": "application/json",
            },
        )
        if not res.ok:
            p_req = prov(
                "face-api",
                ctx.settings.face_api_url,
                query=image_url,
                http_status=res.status,
                outcome=res.outcome,
                latency_ms=res.elapsed_ms,
                note=res.error,
            )
            return self.result(
                "error" if res.outcome not in ("blocked", "timeout") else res.outcome,
                provenance=[p_req],
                error=res.error,
                gaps=[gap_note("face", f"API не ответил: {res.error}")],
            )

        entities = []
        edges = []
        provenance = [p_req]
        items = _items(res.payload)
        if not items:
            provenance.append(
                prov(
                    "face-api",
                    ctx.settings.face_api_url,
                    query=image_url,
                    http_status=res.status,
                    outcome="not_found",
                    latency_ms=res.elapsed_ms,
                    note="no matches",
                )
            )
            return self.result(
                "ok",
                provenance=provenance,
                gaps=[gap_note("face", "легальный API не вернул совпадений")],
            )
        for item in items[:10]:
            p = prov(
                "face-api",
                ctx.settings.face_api_url,
                query=image_url,
                http_status=res.status,
                confidence=0.65,
                latency_ms=res.elapsed_ms,
                note="biometric provider match; legal basis required",
            )
            provenance.append(p)
            label = (
                item.get("name")
                or item.get("label")
                or item.get("identity")
                or "face match"
            )
            record = pd_entity(
                "record",
                f"face:{short_hash(hash_json(item))}",
                str(label),
                p,
                0.65,
                selector=image_url,
                platform="face",
                data={
                    "score": item.get("score") or item.get("confidence"),
                    "provider": item.get("provider"),
                    "match": item,
                },
                raw_hash=hash_json(item),
            )
            entities.append(record)
            edges.append(
                edge(
                    ctx.root_id,
                    record.id,
                    "identified_as",
                    0.65,
                    p,
                    note="provider hypothesis; requires human/legal verification",
                )
            )
        return self.result(
            "ok",
            entities=entities,
            edges=edges,
            provenance=provenance,
            gaps=[gap],
        )