"""Shared helpers for Sherlock resolvers: normalization, masking, hashing."""

from __future__ import annotations

import hashlib
import json
import re
from datetime import date, datetime
from typing import Any

from ...schemas import Entity, Provenance
from ..base import clean, prov

EMAIL_RE = re.compile(r"^[A-Za-z0-9.!#$%&'*+/=?^_`{|}~-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$")
NAME_RE = re.compile(r"^[А-Яа-яЁёA-Za-z][А-Яа-яЁёA-Za-z-]*$")


def sha256_hex(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def short_hash(value: str, length: int = 16) -> str:
    return sha256_hex(value)[:length]


def hash_json(payload: Any) -> str:
    material = json.dumps(payload, ensure_ascii=False, sort_keys=True, default=str)
    return hashlib.sha256(material.encode("utf-8")).hexdigest()


def normalize_email(raw: str) -> str:
    return raw.strip().lower()


def normalize_name(raw: str) -> tuple[str, list[str]]:
    parts = [p for p in re.split(r"\s+", raw.strip()) if p]
    normalized = " ".join(parts)
    return normalized, parts


def valid_name_parts(parts: list[str]) -> bool:
    return 2 <= len(parts) <= 3 and all(NAME_RE.fullmatch(p) for p in parts)


def parse_date(raw: str | None) -> date | None:
    if not raw:
        return None
    value = raw.strip()
    for fmt in ("%Y-%m-%d", "%d.%m.%Y", "%d.%m.%y"):
        try:
            return datetime.strptime(value, fmt).date()
        except ValueError:
            continue
    return None


def mask_phone(e164: str) -> str:
    digits = re.sub(r"\D", "", e164)
    if len(digits) < 6:
        return "***"
    return f"+{digits[0]} {digits[1:4]} ***-**-{digits[-2:]}"


def mask_email(email: str) -> str:
    local, _, domain = email.partition("@")
    if not domain:
        return "***"
    return f"{local[:1]}***@{domain}"


def mask_name(full: str) -> str:
    parts = full.split()
    if len(parts) == 1:
        return parts[0][:1] + "***"
    initials = " ".join(p[:1] + "." for p in parts[1:])
    return f"{parts[0]} {initials}"


def mask_digits(value: str, keep: int = 2) -> str:
    digits = re.sub(r"\D", "", value)
    if len(digits) <= keep:
        return "*" * len(digits)
    return "*" * (len(digits) - keep) + digits[-keep:]


def mask_passport(series: str, number: str) -> str:
    return f"{series[:2]}** ****{number[-2:]}"


def pd_entity(
    kind: str,
    key: str,
    label: str,
    p: Provenance,
    confidence: float,
    *,
    selector: str | None = None,
    platform: str | None = None,
    profile_url: str | None = None,
    data: dict[str, Any] | None = None,
    raw_hash: str | None = None,
) -> Entity:
    """Entity with the Sherlock fields filled consistently."""
    return Entity.make(
        kind,  # type: ignore[arg-type]
        key,
        label,
        selector=selector,
        platform=platform,
        profile_url=profile_url,
        data=clean(data or {}),
        raw_hash=raw_hash,
        provenance=[p],
        confidence=confidence,
    )


def local_prov(source: str, query: str, confidence: float, note: str) -> Provenance:
    return prov(
        source,
        "local://validation",
        query=query,
        outcome="ok",
        confidence=confidence,
        note=note,
    )


def gap_note(source: str, note: str) -> str:
    return f"{source}: {note}"