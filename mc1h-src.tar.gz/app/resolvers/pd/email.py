"""Email: syntax/IDNA, MX via DNS-over-HTTPS, Gravatar, public GitHub commits, HIBP.

Legal boundary
--------------
* Gravatar and GitHub public commits are open data.
* HIBP is used only through its official API and a user key; no passwords or
  breach dumps are downloaded.
* "Leak databases" outside HIBP are not queried: access to breached personal
  data is unlawful and is reported as a gap.
"""

from __future__ import annotations

import hashlib
from urllib.parse import quote, urlencode

from ...opsec import HttpFetcher
from ...schemas import ResolverResult
from ..base import edge, prov
from .base import PDResolver, ResolveContext
from .common import (
    EMAIL_RE,
    gap_note,
    hash_json,
    local_prov,
    mask_email,
    normalize_email,
    pd_entity,
)

DNS_URL = "https://cloudflare-dns.com/dns-query"
GRAVATAR = "https://gravatar.com/avatar"
GITHUB_SEARCH = "https://api.github.com/search/commits"
HIBP = "https://haveibeenpwned.com/api/v3/breachedaccount"


class EmailResolver(PDResolver):
    name = "email"
    selector_type = "email"

    async def resolve(
        self, ctx: ResolveContext, fetcher: HttpFetcher
    ) -> ResolverResult:
        email = normalize_email(ctx.raw)
        if (
            not EMAIL_RE.fullmatch(email)
            or len(email) > 254
            or len(email.split("@", 1)[0]) > 64
        ):
            return self.result("invalid", error="email не проходит синтаксическую проверку")

        local, _, domain = email.partition("@")
        try:
            ascii_domain = domain.encode("idna").decode("ascii")
        except UnicodeError:
            return self.result("invalid", error="домен не конвертируется в IDNA")

        md5 = hashlib.md5(email.encode("utf-8")).hexdigest()  # Gravatar protocol
        provenance = []
        entities = []
        edges = []
        gaps: list[str] = []

        p_norm = local_prov(
            "email-normalize",
            mask_email(email),
            1.0,
            "lowercase + IDNA; Gravatar md5 is computed over the normalized address",
        )
        entity = pd_entity(
            "identifier",
            f"email:{email}",
            email,
            p_norm,
            1.0,
            selector=mask_email(email),
            platform="email",
            data={
                "email": email,
                "local": local,
                "domain": domain,
                "ascii_domain": ascii_domain,
                "gravatar_md5": md5,
                "masked": mask_email(email),
            },
            raw_hash=hash_json({"email": email}),
        )
        entities.append(entity)
        provenance.append(p_norm)
        edges.append(
            edge(
                ctx.root_id,
                entity.id,
                "same_as",
                1.0,
                p_norm,
                note="normalized input address",
            )
        )

        # --- MX / A through Cloudflare DoH -------------------------------
        mx, a_records, dns_status, dns_error, null_mx = await _dns(
            fetcher, ascii_domain, "MX"
        )
        if not mx and not a_records and not null_mx:
            a_records, a_status, a_error, _ = await _dns_a(fetcher, ascii_domain)
            if a_status is not None:
                dns_status = a_status
            if a_error:
                dns_error = a_error
        if (mx or a_records) and not null_mx:
            p_dns = prov(
                "cloudflare-doh",
                DNS_URL,
                query=ascii_domain,
                http_status=dns_status,
                confidence=0.95 if mx else 0.75,
                note=(
                    f"MX={len(mx)}, A={len(a_records)}"
                    + ("; implicit MX via A" if not mx and a_records else "")
                ),
            )
            provenance.append(p_dns)
            entity.data["mx"] = mx
            entity.data["mx_count"] = len(mx)
            entity.data["implicit_mx"] = bool(not mx and a_records)
            entity.data["null_mx"] = False
            entity.data["accepts_mail"] = True
        else:
            if null_mx:
                dns_error = "null MX (RFC 7505): домен явно не принимает почту"
            p_dns = prov(
                "cloudflare-doh",
                DNS_URL,
                query=ascii_domain,
                http_status=dns_status,
                outcome="not_found" if dns_error is None else "error",
                note=dns_error or "no MX and no A records",
            )
            provenance.append(p_dns)
            entity.data["null_mx"] = null_mx
            entity.data["mx"] = mx
            entity.data["mx_count"] = len(mx)
            entity.data["implicit_mx"] = False
            entity.data["accepts_mail"] = False
            gaps.append(
                gap_note(
                    "DNS MX",
                    f"для {ascii_domain} нет рабочей MX-записи: "
                    f"{dns_error or 'записей нет'}",
                )
            )

        # --- Gravatar -----------------------------------------------------
        gravatar_url = f"{GRAVATAR}/{md5}?d=404&s=1"
        grav = await fetcher.get_text(gravatar_url)
        if grav.ok:
            p_grav = prov(
                "gravatar",
                GRAVATAR,
                query=md5,
                http_status=grav.status,
                confidence=0.80,
                latency_ms=grav.elapsed_ms,
                note="avatar exists for the email hash; account existence only",
            )
            profile = pd_entity(
                "account",
                f"gravatar:{md5}",
                f"Gravatar {md5[:10]}",
                p_grav,
                0.80,
                selector=mask_email(email),
                platform="gravatar",
                profile_url=f"https://gravatar.com/{md5}",
                data={"hash": md5, "avatar_url": gravatar_url},
                raw_hash=hash_json({"md5": md5, "status": grav.status}),
            )
            entities.append(profile)
            provenance.append(p_grav)
            edges.append(
                edge(
                    entity.id,
                    profile.id,
                    "registered_at",
                    0.80,
                    p_grav,
                    note="deterministic email hash; avatar existence does not prove ownership",
                )
            )
        elif grav.outcome == "not_found":
            provenance.append(
                prov(
                    "gravatar",
                    GRAVATAR,
                    query=md5,
                    http_status=grav.status,
                    outcome="not_found",
                    latency_ms=grav.elapsed_ms,
                    note="no avatar for this hash",
                )
            )
        else:
            provenance.append(
                prov(
                    "gravatar",
                    GRAVATAR,
                    query=md5,
                    http_status=grav.status,
                    outcome=grav.outcome,
                    latency_ms=grav.elapsed_ms,
                    note=grav.error,
                )
            )
            gaps.append(gap_note("gravatar", f"проверка не выполнена: {grav.error}"))

        # --- Public GitHub commits by author email ------------------------
        gh_headers = {"Accept": "application/vnd.github+json"}
        if ctx.settings.github_token:
            gh_headers["Authorization"] = f"Bearer {ctx.settings.github_token}"
        gh_url = (
            GITHUB_SEARCH
            + "?"
            + urlencode(
                {
                    "q": f"author-email:{email}",
                    "per_page": 10,
                    "sort": "author-date",
                    "order": "desc",
                }
            )
        )
        gh = await fetcher.get_json(gh_url, headers=gh_headers)
        if gh.ok and isinstance(gh.payload, dict):
            items = gh.payload.get("items")
            items = items if isinstance(items, list) else []
            if items:
                p_gh = prov(
                    "github",
                    GITHUB_SEARCH,
                    query=mask_email(email),
                    http_status=gh.status,
                    confidence=0.70,
                    latency_ms=gh.elapsed_ms,
                    note=f"public commits with author-email; total={gh.payload.get('total_count')}",
                )
                provenance.append(p_gh)
                seen_accounts: set[str] = set()
                for item in items[:10]:
                    if not isinstance(item, dict):
                        continue
                    sha = str(item.get("sha") or "")
                    repo = item.get("repository") or {}
                    repo_full = repo.get("full_name") if isinstance(repo, dict) else None
                    author = item.get("author") or {}
                    login = author.get("login") if isinstance(author, dict) else None
                    commit = item.get("commit") or {}
                    commit_author = commit.get("author") if isinstance(commit, dict) else {}
                    commit_author = commit_author if isinstance(commit_author, dict) else {}

                    rec = pd_entity(
                        "record",
                        f"github_commit:{sha}",
                        f"{repo_full or 'repo'}@{sha[:7]}" if sha else "commit",
                        p_gh,
                        0.85,
                        selector=mask_email(email),
                        platform="github",
                        profile_url=item.get("html_url"),
                        data={
                            "sha": sha,
                            "repo": repo_full,
                            "url": item.get("html_url"),
                            "author_name": commit_author.get("name"),
                            "author_date": commit_author.get("date"),
                            "message": (commit.get("message") or "").split("\n")[0]
                            if isinstance(commit, dict)
                            else None,
                        },
                        raw_hash=hash_json(item),
                    )
                    entities.append(rec)
                    edges.append(
                        edge(
                            entity.id,
                            rec.id,
                            "observed_in",
                            0.90,
                            p_gh,
                            note="email present in public commit author field",
                        )
                    )

                    if login and login not in seen_accounts:
                        seen_accounts.add(login)
                        acc = pd_entity(
                            "account",
                            f"github:{str(login).lower()}",
                            str(login),
                            p_gh,
                            0.70,
                            selector=mask_email(email),
                            platform="github",
                            profile_url=f"https://github.com/{login}",
                            data={
                                "login": login,
                                "commits_sampled": sum(
                                    1
                                    for x in items
                                    if isinstance(x, dict)
                                    and (x.get("author") or {}).get("login") == login
                                ),
                            },
                            raw_hash=hash_json({"login": login}),
                        )
                        entities.append(acc)
                        edges.append(
                            edge(
                                entity.id,
                                acc.id,
                                "handle_match",
                                0.70,
                                p_gh,
                                note="commit author email; self-declared, not cryptographic proof",
                            )
                        )
            else:
                provenance.append(
                    prov(
                        "github",
                        GITHUB_SEARCH,
                        query=mask_email(email),
                        http_status=gh.status,
                        outcome="not_found",
                        latency_ms=gh.elapsed_ms,
                        note="no public commits for this author email",
                    )
                )
        elif gh.outcome in ("blocked", "error", "timeout"):
            provenance.append(
                prov(
                    "github",
                    GITHUB_SEARCH,
                    query=mask_email(email),
                    http_status=gh.status,
                    outcome=gh.outcome,
                    latency_ms=gh.elapsed_ms,
                    note=gh.error,
                )
            )
            gaps.append(
                gap_note(
                    "github commits",
                    f"проверка не выполнена: {gh.error}"
                    + ("" if ctx.settings.github_token else " (нужен GITHUB_TOKEN)"),
                )
            )

        # --- HIBP ---------------------------------------------------------
        if not ctx.settings.hibp_api_key:
            gaps.append(
                gap_note(
                    "HIBP",
                    "MC1H_HIBP_API_KEY не задан — проверка утечек по email не выполнена",
                )
            )
        else:
            hibp_url = HIBP + "/" + quote(email, safe="") + "?truncateResponse=false"
            hibp = await fetcher.get_json(
                hibp_url, headers={"hibp-api-key": ctx.settings.hibp_api_key}
            )
            if hibp.ok and isinstance(hibp.payload, list):
                p_hibp = prov(
                    "hibp",
                    HIBP,
                    query=mask_email(email),
                    http_status=hibp.status,
                    confidence=0.95,
                    latency_ms=hibp.elapsed_ms,
                    note=f"{len(hibp.payload)} breaches; metadata only, no passwords",
                )
                provenance.append(p_hibp)
                for breach in hibp.payload:
                    if not isinstance(breach, dict) or not breach.get("Name"):
                        continue
                    name = str(breach["Name"])
                    rec = pd_entity(
                        "breach",
                        f"hibp:{name.lower()}",
                        name,
                        p_hibp,
                        0.95,
                        selector=mask_email(email),
                        platform="hibp",
                        profile_url=f"https://haveibeenpwned.com/PwnedWebsites#{name}",
                        data={
                            "name": name,
                            "title": breach.get("Title"),
                            "domain": breach.get("Domain"),
                            "breach_date": breach.get("BreachDate"),
                            "added_date": breach.get("AddedDate"),
                            "pwn_count": breach.get("PwnCount"),
                            "data_classes": breach.get("DataClasses"),
                            "is_verified": breach.get("IsVerified"),
                            "is_sensitive": breach.get("IsSensitive"),
                        },
                        raw_hash=hash_json(breach),
                    )
                    entities.append(rec)
                    edges.append(
                        edge(
                            entity.id,
                            rec.id,
                            "observed_in",
                            0.95,
                            p_hibp,
                            note="email appears in a public breach corpus (HIBP metadata)",
                        )
                    )
            elif hibp.outcome == "not_found":
                provenance.append(
                    prov(
                        "hibp",
                        HIBP,
                        query=mask_email(email),
                        http_status=hibp.status,
                        outcome="not_found",
                        latency_ms=hibp.elapsed_ms,
                        note="no breaches in HIBP",
                    )
                )
            else:
                provenance.append(
                    prov(
                        "hibp",
                        HIBP,
                        query=mask_email(email),
                        http_status=hibp.status,
                        outcome=hibp.outcome,
                        latency_ms=hibp.elapsed_ms,
                        note=hibp.error,
                    )
                )
                gaps.append(gap_note("HIBP", f"запрос не выполнен: {hibp.error}"))

        gaps.append(
            gap_note(
                "leak databases",
                "поиск по теневым базам утечек не реализован: доступ к украденным "
                "ПД не является открытым источником и запрещён",
            )
        )

        return self.result(
            "ok",
            entities=entities,
            edges=edges,
            provenance=provenance,
            gaps=gaps,
        )


async def _dns(
    fetcher: HttpFetcher, domain: str, rrtype: str
) -> tuple[list[str], list[str], int | None, str | None, bool]:
    url = DNS_URL + "?" + urlencode({"name": domain, "type": rrtype})
    res = await fetcher.get_json(url, headers={"Accept": "application/dns-json"})
    if not res.ok or not isinstance(res.payload, dict):
        return [], [], res.status, res.error or "DNS response is not JSON", False
    status = res.payload.get("Status")
    if status not in (0, None):
        return [], [], res.status, f"DNS rcode={status}", False
    answers = res.payload.get("Answer")
    answers = answers if isinstance(answers, list) else []
    mx: list[str] = []
    a: list[str] = []
    null_mx = False
    for ans in answers:
        if not isinstance(ans, dict):
            continue
        data = str(ans.get("data") or "")
        rtype = ans.get("type")
        if rtype == 15 and data:
            target = data.split()[-1].rstrip(".")
            if target:
                mx.append(target)
            else:
                null_mx = True  # RFC 7505: "0 ."
        elif rtype == 1 and data:
            a.append(data)
    return mx, a, res.status, None, null_mx


async def _dns_a(
    fetcher: HttpFetcher, domain: str
) -> tuple[list[str], int | None, str | None, bool]:
    _, a, status, error, null_mx = await _dns(fetcher, domain, "A")
    return a, status, error, null_mx