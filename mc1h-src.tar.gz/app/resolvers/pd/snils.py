"""СНИЛС: формат и контрольное число по алгоритму ПФР.

Only offline validation is implemented.  There is no lawful public API that
maps СНИЛС to a person, and searching breach corpora is refused, so the
external lookup is returned as an explicit zero-confidence entity with the
note "search unavailable".
"""

from __future__ import annotations

import re

from ...opsec import HttpFetcher
from ...schemas import ResolverResult
from ..base import edge, prov
from .base import PDResolver, ResolveContext
from .common import (
    gap_note,
    local_prov,
    mask_digits,
    pd_entity,
    sha256_hex,
)


def snils_checksum_valid(digits: str) -> bool:
    if not digits.isdigit() or len(digits) != 11:
        return False
    body = [int(c) for c in digits[:9]]
    total = sum(value * (9 - index) for index, value in enumerate(body))
    if total < 100:
        control = total
    elif total in (100, 101):
        control = 0
    else:
        control = total % 101
        if control == 100:
            control = 0
    return control == int(digits[9:])


class SnilsResolver(PDResolver):
    name = "snils"
    selector_type = "snils"

    async def resolve(
        self, ctx: ResolveContext, fetcher: HttpFetcher
    ) -> ResolverResult:
        digits = re.sub(r"\D", "", ctx.raw)
        if len(digits) != 11:
            return self.result("invalid", error="СНИЛС должен содержать 11 цифр")
        if not snils_checksum_valid(digits):
            return self.result("invalid", error="СНИЛС не проходит контрольное число ПФР")

        masked = mask_digits(digits, keep=2)
        p = local_prov(
            "snils-checksum",
            masked,
            1.0,
            "ПФР checksum over 9 digits; format does not prove the record exists",
        )
        entity = pd_entity(
            "identifier",
            f"snils:{sha256_hex(digits)[:16]}",
            f"СНИЛС ***-**-*** {digits[-2:]}",
            p,
            1.0,
            selector=masked,
            platform="snils",
            data={
                "masked": masked,
                "checksum_valid": True,
                "digits": 11,
                "last_two": digits[-2:],
            },
            raw_hash=sha256_hex(digits),
        )

        # The checksum fact is certain (confidence 1.0).  The *search* fact is
        # not: there is no lawful public API, so we return an explicit
        # zero-confidence entity with note "search unavailable" instead of
        # silently omitting the failed lookup.
        search_note = "search unavailable"
        p_search = prov(
            "snils-search",
            "local://not-implemented",
            query=masked,
            outcome="not_configured",
            confidence=0.0,
            note=search_note,
        )
        search_entity = pd_entity(
            "record",
            f"snils-search:{sha256_hex(digits)[:16]}",
            "СНИЛС: поиск недоступен",
            p_search,
            0.0,
            selector=masked,
            platform="snils",
            data={
                "search": "unavailable",
                "note": search_note,
                "reason": "no lawful public API for СНИЛС → person lookup",
            },
            raw_hash=sha256_hex(digits),
        )

        gaps = [
            gap_note(
                "СФР",
                "публичного API «СНИЛС → ФИО» нет; проверка выполняется только "
                "по контрольному числу",
            ),
            gap_note(
                "leak databases",
                "поиск СНИЛС в утечках/агрегаторах не реализован: это доступ к "
                "украденным ПД, а не открытый источник",
            ),
        ]

        return self.result(
            "ok",
            entities=[entity, search_entity],
            edges=[
                edge(
                    ctx.root_id,
                    entity.id,
                    "same_as",
                    1.0,
                    p,
                    note="checksum-validated input; full number is not stored in the graph",
                ),
                edge(
                    entity.id,
                    search_entity.id,
                    "observed_in",
                    0.0,
                    p_search,
                    note=search_note,
                ),
            ],
            provenance=[p, p_search],
            gaps=gaps,
        )
