"""Юридическое лицо: ОГРН/ОГРНИП и ИНН через легальный API ФНС.

Checksums are deterministic and offline.  Registry data is fetched only when
MC1H_FNS_API_URL + MC1H_FNS_API_KEY are configured; otherwise the gap is
explicit.  No public captcha form is bypassed.
"""

from __future__ import annotations

import re
from urllib.parse import urlencode

from ...opsec import HttpFetcher
from ...schemas import ResolverResult
from ..base import edge, prov
from .base import PDResolver, ResolveContext
from .common import (
    gap_note,
    hash_json,
    local_prov,
    pd_entity,
    short_hash,
)
from .inn import inn_checksum_valid


def ogrn_checksum_valid(value: str) -> bool:
    if not value.isdigit() or len(value) != 13:
        return False
    return int(value[:12]) % 11 % 10 == int(value[-1])


def ogrnip_checksum_valid(value: str) -> bool:
    if not value.isdigit() or len(value) != 15:
        return False
    return int(value[:14]) % 13 % 10 == int(value[-1])


def classify_legal(value: str) -> str | None:
    if len(value) == 10 and inn_checksum_valid(value):
        return "inn_legal"
    if len(value) == 12 and inn_checksum_valid(value):
        return "inn_individual"
    if ogrn_checksum_valid(value):
        return "ogrn"
    if ogrnip_checksum_valid(value):
        return "ogrnip"
    return None


def _items(payload: object) -> list[dict]:
    if isinstance(payload, list):
        return [x for x in payload if isinstance(x, dict)]
    if isinstance(payload, dict):
        for key in ("items", "data", "results", "organizations", "records"):
            value = payload.get(key)
            if isinstance(value, list):
                return [x for x in value if isinstance(x, dict)]
    return []


def _pick(item: dict, *keys: str) -> str | None:
    for key in keys:
        value = item.get(key)
        if value not in (None, "", [], {}):
            return str(value)
    return None


class LegalEntityResolver(PDResolver):
    name = "legal_entity"
    selector_type = "legal_entity"

    async def resolve(
        self, ctx: ResolveContext, fetcher: HttpFetcher
    ) -> ResolverResult:
        value = re.sub(r"\D", "", ctx.raw)
        kind = classify_legal(value)
        if kind is None:
            return self.result(
                "invalid",
                error="Нужен ИНН (10/12 цифр), ОГРН (13) или ОГРНИП (15) "
                "с корректным контрольным числом",
            )

        p = local_prov(
            "legal-checksum",
            value,
            1.0,
            "official checksum validation; does not prove current registration",
        )
        entity = pd_entity(
            "identifier",
            f"legal:{value}",
            value,
            p,
            1.0,
            selector=value,
            platform="legal_entity",
            data={
                "identifier": value,
                "legal_kind": kind,
                "checksum_valid": True,
                "region_code": value[:2],
            },
            raw_hash=hash_json({"legal": value, "kind": kind}),
        )
        entities = [entity]
        provenance = [p]
        edges = [
            edge(
                ctx.root_id,
                entity.id,
                "same_as",
                1.0,
                p,
                note="checksum-validated legal identifier",
            )
        ]
        gaps: list[str] = []

        if not ctx.settings.fns_api_url or not ctx.settings.fns_api_key:
            gaps.append(
                gap_note(
                    "ЕГРЮЛ/ЕГРИП",
                    "поиск не выполнен: нужны MC1H_FNS_API_URL и "
                    "MC1H_FNS_API_KEY (легальный API ФНС/партнёра); "
                    "публичные формы с captcha не обходятся",
                )
            )
        else:
            base = ctx.settings.fns_api_url
            sep = "&" if "?" in base else "?"
            url = base + sep + urlencode(
                {"req": value, "key": ctx.settings.fns_api_key}
            )
            res = await fetcher.get_json(url)
            if not res.ok:
                provenance.append(
                    prov(
                        "egrul",
                        base,
                        query=value,
                        http_status=res.status,
                        outcome=res.outcome,
                        latency_ms=res.elapsed_ms,
                        note=res.error,
                    )
                )
                gaps.append(gap_note("ЕГРЮЛ/ЕГРИП", f"запрос не выполнен: {res.error}"))
            else:
                items = _items(res.payload)
                if not items:
                    provenance.append(
                        prov(
                            "egrul",
                            base,
                            query=value,
                            http_status=res.status,
                            outcome="not_found",
                            latency_ms=res.elapsed_ms,
                            note="no registry record",
                        )
                    )
                    gaps.append(
                        gap_note(
                            "ЕГРЮЛ/ЕГРИП",
                            "API ответил без записей — субъект может быть недействующим "
                            "или отсутствовать в доступном контуре",
                        )
                    )
                for item in items[:20]:
                    p_reg = prov(
                        "egrul",
                        base,
                        query=value,
                        http_status=res.status,
                        confidence=0.95,
                        latency_ms=res.elapsed_ms,
                        note="official/partner registry response",
                    )
                    provenance.append(p_reg)
                    name = _pick(item, "НаимПолн", "name", "Наименование", "ФИО")
                    ogrn = _pick(item, "ОГРН", "ogrn", "ОГРНИП")
                    inn = _pick(item, "ИНН", "inn")
                    if not name:
                        continue
                    org = pd_entity(
                        "organization",
                        f"egrul:{ogrn or inn or short_hash(hash_json(item))}",
                        str(name),
                        p_reg,
                        0.95,
                        selector=value,
                        platform="egrul",
                        data={
                            "name": name,
                            "inn": inn,
                            "ogrn": ogrn,
                            "kpp": _pick(item, "КПП", "kpp"),
                            "status": _pick(item, "Статус", "status"),
                            "address": _pick(item, "АдресПолн", "address"),
                            "okved": _pick(item, "ОКВЭД", "okved"),
                            "registration_date": _pick(item, "ДатаРег", "registration_date"),
                            "director": _pick(item, "Руководитель", "director", "ФИО"),
                        },
                        raw_hash=hash_json(item),
                    )
                    entities.append(org)
                    edges.append(
                        edge(
                            entity.id,
                            org.id,
                            "registered_as",
                            0.95,
                            p_reg,
                            note="registry record matches the legal identifier",
                        )
                    )

        return self.result(
            "ok",
            entities=entities,
            edges=edges,
            provenance=provenance,
            gaps=gaps,
        )