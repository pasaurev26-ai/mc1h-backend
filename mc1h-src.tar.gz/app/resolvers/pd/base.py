"""Contract for Sherlock (PD) resolvers."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from datetime import date
from typing import Any

from ...config import Settings
from ...opsec import HttpFetcher
from ...schemas import Outcome, ResolverResult, SelectorType


@dataclass
class ResolveContext:
    raw: str
    normalized: str
    selector_type: SelectorType
    birth_date: date | None
    settings: Settings
    safe_label: str
    selector_sha: str
    root_id: str = "root:selector"


class PDResolver(ABC):
    """One selector family per module. Must never raise."""

    name: str
    selector_type: SelectorType

    @abstractmethod
    async def resolve(
        self, ctx: ResolveContext, fetcher: HttpFetcher
    ) -> ResolverResult:
        raise NotImplementedError

    def result(self, status: Outcome, **kwargs: Any) -> ResolverResult:
        return ResolverResult(source=self.name, status=status, **kwargs)