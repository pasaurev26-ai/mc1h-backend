"""Телефон: E.164, регион, оператор, тип линии.

This resolver is offline-only.  Public t.me/Avito/Youla search lives in
``phone_search.py`` and is fanned out by the pipeline for phone selectors.
"""

from __future__ import annotations

import phonenumbers
from phonenumbers import PhoneNumberFormat, PhoneNumberType, carrier, geocoder, region_code_for_number

from ...opsec import HttpFetcher
from ...schemas import ResolverResult
from ..base import edge
from .base import PDResolver, ResolveContext
from .common import (
    gap_note,
    hash_json,
    local_prov,
    mask_phone,
    pd_entity,
)

LINE_TYPES = {
    PhoneNumberType.FIXED_LINE: "fixed_line",
    PhoneNumberType.MOBILE: "mobile",
    PhoneNumberType.FIXED_LINE_OR_MOBILE: "fixed_or_mobile",
    PhoneNumberType.TOLL_FREE: "toll_free",
    PhoneNumberType.PREMIUM_RATE: "premium_rate",
    PhoneNumberType.SHARED_COST: "shared_cost",
    PhoneNumberType.VOIP: "voip",
    PhoneNumberType.PERSONAL_NUMBER: "personal_number",
    PhoneNumberType.PAGER: "pager",
    PhoneNumberType.UAN: "uan",
    PhoneNumberType.VOICEMAIL: "voicemail",
    PhoneNumberType.UNKNOWN: "unknown",
}


class PhoneResolver(PDResolver):
    name = "phone"
    selector_type = "phone"

    async def resolve(
        self, ctx: ResolveContext, fetcher: HttpFetcher
    ) -> ResolverResult:
        try:
            number = phonenumbers.parse(ctx.raw, "RU")
        except phonenumbers.NumberParseException as exc:
            return self.result("invalid", error=f"не разобрать номер: {exc}")

        if not phonenumbers.is_possible_number(number):
            return self.result("invalid", error="номер невозможен по длине/формату")

        valid = phonenumbers.is_valid_number(number)
        e164 = phonenumbers.format_number(number, PhoneNumberFormat.E164)
        masked = mask_phone(e164)
        operator = carrier.name_for_number(number, "ru") or None
        region = region_code_for_number(number)
        line = LINE_TYPES.get(phonenumbers.number_type(number), "unknown")

        p = local_prov(
            "phone-validation",
            masked,
            1.0 if valid else 0.4,
            "phonenumbers: parse + validity + carrier metadata (offline)",
        )
        entity = pd_entity(
            "identifier",
            f"phone:{e164}",
            masked,
            p,
            1.0 if valid else 0.4,
            selector=masked,
            platform="phone",
            data={
                "e164": e164,
                "national": phonenumbers.format_number(
                    number, PhoneNumberFormat.NATIONAL
                ),
                "international": phonenumbers.format_number(
                    number, PhoneNumberFormat.INTERNATIONAL
                ),
                "country_code": number.country_code,
                "region": region,
                "geocoded": geocoder.description_for_number(number, "ru") or None,
                "carrier": operator,
                "line_type": line,
                "valid": valid,
                "possible": True,
                "masked": masked,
            },
            raw_hash=hash_json(
                {
                    "e164": e164,
                    "region": region,
                    "carrier": operator,
                    "line": line,
                }
            ),
        )

        gaps: list[str] = []
        if valid and operator is None:
            gaps.append(
                gap_note(
                    "phone-carrier",
                    "оператор не определён (перенесённый номер или нет данных в библиотеке)",
                )
            )

        status = "ok" if valid else "invalid"
        return self.result(
            status,
            entities=[entity],
            edges=[
                edge(
                    ctx.root_id,
                    entity.id,
                    "same_as",
                    1.0 if valid else 0.4,
                    p,
                    note="E.164 normalization of the input selector",
                )
            ],
            provenance=[p],
            gaps=gaps,
            error=None if valid else "номер не прошёл проверку is_valid_number",
        )