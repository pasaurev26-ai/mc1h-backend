"""Registry for Sherlock (PD) resolvers and selector auto-detection."""

from __future__ import annotations

from ...schemas import SelectorType
from .base import PDResolver
from .documents import DocumentsResolver
from .email import EmailResolver
from .face import FaceResolver
from .fio import FioResolver
from .inn import InnResolver, inn_checksum_valid
from .legal_entity import LegalEntityResolver
from .online_traces import OnlineTracesResolver
from .passport import PassportResolver
from .phone import PhoneResolver
from .phone_search import PhoneSearchResolver
from .real_estate import RealEstateResolver
from .snils import SnilsResolver, snils_checksum_valid
from .social import SocialResolver
from .telegram import TelegramResolver
from .transport import TransportResolver

PD_ALL: dict[str, PDResolver] = {
    resolver.name: resolver
    for resolver in (
        FioResolver(),
        PhoneResolver(),
        PhoneSearchResolver(),
        EmailResolver(),
        InnResolver(),
        SnilsResolver(),
        PassportResolver(),
        DocumentsResolver(),
        TransportResolver(),
        SocialResolver(),
        TelegramResolver(),
        OnlineTracesResolver(),
        RealEstateResolver(),
        LegalEntityResolver(),
        FaceResolver(),
    )
}

# One selector family can fan out into several independent resolvers.
# Phone keeps the offline validator and adds the public web search.
PD_SELECTOR_RESOLVERS: dict[str, tuple[str, ...]] = {
    "fio": ("fio",),
    "phone": ("phone", "phone_search"),
    "email": ("email",),
    "contacts": ("phone", "phone_search", "email"),
    "inn": ("inn",),
    "snils": ("snils",),
    "passport": ("passport",),
    "vu": ("documents",),
    "documents": ("documents",),
    "transport": ("transport",),
    "social": ("social",),
    "telegram": ("telegram",),
    "online_traces": ("online_traces",),
    "real_estate": ("real_estate",),
    "legal_entity": ("legal_entity",),
    "face": ("face",),
}
PD_TYPES: tuple[str, ...] = tuple(PD_SELECTOR_RESOLVERS)


def select_pd(
    selector_type: str, sources: list[str] | None = None
) -> list[PDResolver]:
    if selector_type not in PD_SELECTOR_RESOLVERS:
        raise ValueError(
            f"unknown selector_type: {selector_type}; available: {', '.join(PD_TYPES)}"
        )
    available = PD_SELECTOR_RESOLVERS[selector_type]
    if sources:
        unknown = [s for s in sources if s not in PD_ALL]
        if unknown:
            raise ValueError(
                f"unknown PD sources: {', '.join(unknown)}; "
                f"available: {', '.join(available)}"
            )
        selected = tuple(s for s in available if s in sources)
        if not selected:
            raise ValueError(
                f"no sources selected for {selector_type}; "
                f"available: {', '.join(available)}"
            )
        return [PD_ALL[name] for name in selected]
    return [PD_ALL[name] for name in available]


def detect_selector(raw_input: str):
    """Lazy re-export to avoid a package import cycle with app.detect."""
    from ...detect import detect_selector as _detect_selector

    return _detect_selector(raw_input)


__all__ = [
    "PD_ALL",
    "PD_SELECTOR_RESOLVERS",
    "PD_TYPES",
    "detect_selector",
    "select_pd",
    "inn_checksum_valid",
    "snils_checksum_valid",
]