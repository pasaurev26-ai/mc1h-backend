"""Telegram: публичная страница t.me и опциональный поиск по ID.

A public t.me page is parsed for OG/tgme metadata.  A numeric Telegram ID is
not resolvable through public t.me pages without a legal data provider; that
check is an explicit gap unless MC1H_TELEGRAM_DB_URL + KEY are configured.
"""

from __future__ import annotations

import html as html_lib
import re
from urllib.parse import urlencode

from ...opsec import HttpFetcher
from ...schemas import ResolverResult
from ..base import edge, prov
from .base import PDResolver, ResolveContext
from .common import (
    gap_note,
    hash_json,
    pd_entity,
    short_hash,
)

HANDLE_RE = re.compile(r"^[A-Za-z0-9_]{4,32}$")
NUMERIC_ID_RE = re.compile(r"^\d{5,15}$")


def normalize_telegram(raw: str) -> tuple[str, str] | None:
    """Return (``handle``|``id``, normalized) or None."""
    value = raw.strip()
    if not value:
        return None
    value = re.sub(r"^https?://t\.me/", "", value, flags=re.I).strip("/")
    value = value.lstrip("@")
    if value.lower().startswith("tg") and NUMERIC_ID_RE.fullmatch(value[2:]):
        return "id", value[2:]
    if NUMERIC_ID_RE.fullmatch(value):
        return "id", value
    if HANDLE_RE.fullmatch(value):
        return "handle", value
    return None


def _attr(tag: str, name: str) -> str | None:
    match = re.search(
        rf"\b{re.escape(name)}\s*=\s*(?:\"([^\"]*)\"|'([^']*)'|([^\s>]+))",
        tag,
        flags=re.I,
    )
    if not match:
        return None
    return next((v for v in match.groups() if v is not None), None)


def _meta(html_text: str) -> dict[str, str]:
    result: dict[str, str] = {}
    for match in re.finditer(r"<meta\b[^>]*>", html_text, flags=re.I):
        tag = match.group(0)
        key = _attr(tag, "property") or _attr(tag, "name")
        content = _attr(tag, "content")
        if key and content:
            result.setdefault(key.lower(), html_lib.unescape(content).strip())
    for cls in ("tgme_page_title", "tgme_page_description", "tgme_page_extra"):
        match = re.search(
            rf"<div[^>]+class=\"[^\"]*\b{cls}\b[^\"]*\"[^>]*>(.*?)</div>",
            html_text,
            flags=re.I | re.S,
        )
        if match:
            result.setdefault(
                f"tgme:{cls}",
                html_lib.unescape(re.sub(r"<[^>]+>", " ", match.group(1))).strip(),
            )
    image = re.search(
        r"<img[^>]+class=\"[^\"]*tgme_page_photo_image[^\"]*\"[^>]+src=\"([^\"]+)\"",
        html_text,
        flags=re.I,
    )
    if image:
        result.setdefault("tgme:photo", html_lib.unescape(image.group(1)))
    return result


def _clean(value: str | None) -> str | None:
    if not value:
        return None
    text = html_lib.unescape(re.sub(r"<[^>]+>", " ", value))
    text = re.sub(r"\s+", " ", text).strip()
    return text or None


def _items(payload: object) -> list[dict]:
    if isinstance(payload, list):
        return [x for x in payload if isinstance(x, dict)]
    if isinstance(payload, dict):
        for key in ("items", "data", "results", "users", "profiles"):
            value = payload.get(key)
            if isinstance(value, list):
                return [x for x in value if isinstance(x, dict)]
    return []


class TelegramResolver(PDResolver):
    name = "telegram"
    selector_type = "telegram"

    async def resolve(
        self, ctx: ResolveContext, fetcher: HttpFetcher
    ) -> ResolverResult:
        parsed = normalize_telegram(ctx.raw)
        if parsed is None:
            return self.result(
                "invalid",
                error="Telegram: нужен @username, t.me/username или tg123456789",
            )
        kind, value = parsed
        if kind == "id":
            return await self._resolve_id(ctx, fetcher, value)
        return await self._resolve_handle(ctx, fetcher, value)

    async def _resolve_id(
        self, ctx: ResolveContext, fetcher: HttpFetcher, telegram_id: str
    ) -> ResolverResult:
        safe = f"tg{telegram_id}"
        p = prov(
            "telegram-id-format",
            "local://validation",
            query=safe,
            confidence=0.60,
            note="numeric Telegram ID format only",
        )
        identifier = pd_entity(
            "identifier",
            f"telegram:id:{telegram_id}",
            safe,
            p,
            0.60,
            selector=safe,
            platform="telegram",
            data={"telegram_id": telegram_id, "format_valid": True},
            raw_hash=hash_json({"telegram_id": telegram_id}),
        )
        entities = [identifier]
        provenance = [p]
        edges = [
            edge(
                ctx.root_id,
                identifier.id,
                "same_as",
                1.0,
                p,
                note="numeric ID normalized from the input",
            )
        ]
        gaps: list[str] = []

        if not ctx.settings.telegram_db_url or not ctx.settings.telegram_db_key:
            gaps.append(
                gap_note(
                    "Telegram ID",
                    "поиск по числовому ID не выполнен: нужны "
                    "MC1H_TELEGRAM_DB_URL и MC1H_TELEGRAM_DB_KEY; публичный t.me "
                    "не раскрывает владельца ID",
                )
            )
        else:
            base = ctx.settings.telegram_db_url
            sep = "&" if "?" in base else "?"
            res = await fetcher.get_json(
                base
                + sep
                + urlencode({"id": telegram_id, "key": ctx.settings.telegram_db_key})
            )
            if not res.ok:
                provenance.append(
                    prov(
                        "telegram-db",
                        base,
                        query=safe,
                        http_status=res.status,
                        outcome=res.outcome,
                        latency_ms=res.elapsed_ms,
                        note=res.error,
                    )
                )
                gaps.append(gap_note("Telegram ID", f"запрос не выполнен: {res.error}"))
            else:
                items = _items(res.payload)
                if not items:
                    gaps.append(
                        gap_note("Telegram ID", "провайдер ответил без записей")
                    )
                for item in items[:10]:
                    p_db = prov(
                        "telegram-db",
                        base,
                        query=safe,
                        http_status=res.status,
                        confidence=0.70,
                        latency_ms=res.elapsed_ms,
                        note="user-supplied legal data provider",
                    )
                    provenance.append(p_db)
                    name = (
                        item.get("username")
                        or item.get("handle")
                        or item.get("name")
                        or item.get("phone")
                    )
                    if not name:
                        continue
                    account = pd_entity(
                        "account",
                        f"telegram:{short_hash(str(name))}",
                        str(name),
                        p_db,
                        0.70,
                        selector=safe,
                        platform="telegram",
                        data={
                            "username": item.get("username"),
                            "display_name": item.get("name"),
                            "phone": item.get("phone"),
                            "telegram_id": telegram_id,
                        },
                        raw_hash=hash_json(item),
                    )
                    entities.append(account)
                    edges.append(
                        edge(
                            identifier.id,
                            account.id,
                            "observed_in",
                            0.70,
                            p_db,
                            note="optional legal provider response",
                        )
                    )
        return self.result(
            "ok",
            entities=entities,
            edges=edges,
            provenance=provenance,
            gaps=gaps,
        )

    async def _resolve_handle(
        self, ctx: ResolveContext, fetcher: HttpFetcher, handle: str
    ) -> ResolverResult:
        url = f"https://t.me/{handle}"
        safe = f"@{handle}"
        res = await fetcher.get_text(
            url,
            headers={"Accept": "text/html", "Accept-Language": "ru,en;q=0.8"},
        )
        if not res.ok:
            p = prov(
                "telegram-public-page",
                url,
                query=safe,
                http_status=res.status,
                outcome=res.outcome,
                latency_ms=res.elapsed_ms,
                note=res.error,
            )
            return self.result(
                res.outcome if res.outcome in ("blocked", "not_found", "timeout") else "error",
                provenance=[p],
                error=res.error,
                gaps=[
                    gap_note(
                        "telegram",
                        f"t.me/{handle}: страница недоступна ({res.outcome}); "
                        "боты/капча не обходятся",
                    )
                ],
            )

        meta = _meta(res.text or "")
        title = _clean(
            meta.get("tgme:tgme_page_title")
            or meta.get("og:title")
            or meta.get("twitter:title")
        )
        description = _clean(
            meta.get("tgme:tgme_page_description")
            or meta.get("og:description")
            or meta.get("description")
        )
        extra = _clean(meta.get("tgme:tgme_page_extra"))
        image = meta.get("tgme:photo") or meta.get("og:image")
        contact_only = bool(title and "contact @" in title.lower() and not description)
        if contact_only:
            gaps = [
                gap_note(
                    "telegram",
                    "страница 200, но t.me отдал только контактную ссылку без "
                    "display_name/описания профиля",
                )
            ]
            p = prov(
                "telegram-public-page",
                url,
                query=safe,
                http_status=res.status,
                outcome="blocked",
                confidence=0.0,
                latency_ms=res.elapsed_ms,
                note="contact-only page",
            )
            return self.result("blocked", provenance=[p], gaps=gaps)

        confidence = 0.65 if title and description else (0.55 if title else 0.40)
        p = prov(
            "telegram-public-page",
            url,
            query=safe,
            http_status=res.status,
            confidence=confidence,
            latency_ms=res.elapsed_ms,
            note="public t.me metadata only",
        )
        account = pd_entity(
            "account",
            f"telegram:{short_hash(handle)}",
            title or safe,
            p,
            confidence,
            selector=safe,
            platform="telegram",
            profile_url=url,
            data={
                "username": handle,
                "display_name": title,
                "bio": description,
                "extra": extra,
                "avatar_url": image,
                "http_status": res.status,
            },
            raw_hash=hash_json({"handle": handle, "meta": meta}),
        )
        gaps: list[str] = []
        if not title:
            gaps.append(
                gap_note(
                    "telegram",
                    "публичное имя не найдено; возможно, профиль скрыт или "
                    "разметка t.me изменилась",
                )
            )
        gaps.append(
            gap_note(
                "telegram",
                "телефон/ID владельца не раскрываются публичной страницей; "
                "совпадение username не является доказательством личности",
            )
        )
        return self.result(
            "ok",
            entities=[account],
            edges=[
                edge(
                    ctx.root_id,
                    account.id,
                    "observed_in",
                    confidence,
                    p,
                    note="public t.me profile observed",
                )
            ],
            provenance=[p],
            gaps=gaps,
        )