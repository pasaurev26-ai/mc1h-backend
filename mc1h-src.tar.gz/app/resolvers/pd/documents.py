"""Документы: водительское удостоверение и общие проверки формата.

Passport/СНИЛС/ИНН keep their dedicated resolvers.  This module provides the
``vu`` selector and a generic ``documents`` dispatcher used when a client sends
the whole Documents group without a command.  Registry lookups are performed
only through a legal user-supplied endpoint; otherwise the gap is explicit.
"""

from __future__ import annotations

import re
from urllib.parse import urlencode

from ...opsec import HttpFetcher
from ...schemas import ResolverResult
from ..base import edge, prov
from .base import PDResolver, ResolveContext
from .common import (
    gap_note,
    hash_json,
    local_prov,
    mask_digits,
    pd_entity,
    short_hash,
)
from .inn import inn_checksum_valid
from .snils import snils_checksum_valid

VU_RE = re.compile(r"^\d{10}$")


def normalize_document(raw: str) -> tuple[str, str] | None:
    """Return (``vu``|``passport``|``snils``|``inn``, digits) for a bare value."""
    digits = re.sub(r"\D", "", raw)
    if len(digits) == 11 and snils_checksum_valid(digits):
        return "snils", digits
    if len(digits) == 12 and inn_checksum_valid(digits):
        return "inn", digits
    if len(digits) == 10:
        # A bare 10-digit value is ambiguous.  A valid INN is treated as an INN;
        # otherwise the conservative choice is a passport, while /vu is explicit.
        return ("inn" if inn_checksum_valid(digits) else "passport"), digits
    return None


def mask_vu(digits: str) -> str:
    return f"ВУ **{digits[-2:]}" if len(digits) >= 2 else "ВУ"


def _items(payload: object) -> list[dict]:
    if isinstance(payload, list):
        return [x for x in payload if isinstance(x, dict)]
    if isinstance(payload, dict):
        for key in ("items", "data", "results", "records", "licenses"):
            value = payload.get(key)
            if isinstance(value, list):
                return [x for x in value if isinstance(x, dict)]
    return []


def _pick(item: dict, *keys: str) -> str | None:
    for key in keys:
        value = item.get(key)
        if value not in (None, "", [], {}):
            return str(value)
    return None


class DocumentsResolver(PDResolver):
    """Handles ``vu`` and gives a useful error for a generic documents payload."""

    name = "documents"
    selector_type = "documents"

    async def resolve(
        self, ctx: ResolveContext, fetcher: HttpFetcher
    ) -> ResolverResult:
        digits = re.sub(r"\D", "", ctx.raw)
        if ctx.selector_type == "documents":
            parsed = normalize_document(ctx.raw)
            if parsed is None:
                return self.result(
                    "invalid",
                    error="Документ не распознан. Для ВУ используйте /vu 1234567890; "
                    "для паспорта/СНИЛС/ИНН — соответствующую команду.",
                )
            document_type, digits = parsed
        else:
            document_type = "vu"

        if document_type != "vu":
            return self.result(
                "invalid",
                error=f"Тип {document_type} обрабатывается отдельным резолвером; "
                "для него нужна команда /passport, /snils или /inn.",
            )
        if not VU_RE.fullmatch(digits):
            return self.result("invalid", error="ВУ должно содержать 10 цифр")

        safe = mask_vu(digits)
        p = local_prov(
            "document-format",
            safe,
            0.90,
            "format validation only; it does not prove that the document exists",
        )
        identifier = pd_entity(
            "identifier",
            f"document:vu:{short_hash(digits)}",
            safe,
            p,
            0.90,
            selector=safe,
            platform="vu",
            data={
                "document_type": "vu",
                "masked": safe,
                "digits": len(digits),
                "format_valid": True,
            },
            raw_hash=hash_json({"document_type": "vu", "digits": digits}),
        )
        entities = [identifier]
        provenance = [p]
        edges = [
            edge(
                ctx.root_id,
                identifier.id,
                "same_as",
                1.0,
                p,
                note="checksum/format-validated input document",
            )
        ]
        gaps: list[str] = [
            gap_note(
                "ГИБДД/ЕАИСТО",
                "проверка ВУ не выполнена: публичного API без ключа нет; "
                "используется только валидация формата",
            )
        ]

        if ctx.settings.driver_api_url and ctx.settings.driver_api_key:
            base = ctx.settings.driver_api_url
            sep = "&" if "?" in base else "?"
            res = await fetcher.get_json(
                base
                + sep
                + urlencode({"vu": digits, "key": ctx.settings.driver_api_key})
            )
            if not res.ok:
                provenance.append(
                    prov(
                        "driver-registry",
                        base,
                        query=safe,
                        http_status=res.status,
                        outcome=res.outcome,
                        latency_ms=res.elapsed_ms,
                        note=res.error,
                    )
                )
                gaps.append(
                    gap_note("ГИБДД/ЕАИСТО", f"запрос ВУ не выполнен: {res.error}")
                )
            else:
                items = _items(res.payload)
                if not items:
                    provenance.append(
                        prov(
                            "driver-registry",
                            base,
                            query=safe,
                            http_status=res.status,
                            outcome="not_found",
                            latency_ms=res.elapsed_ms,
                            note="no record",
                        )
                    )
                for item in items[:10]:
                    p_reg = prov(
                        "driver-registry",
                        base,
                        query=safe,
                        http_status=res.status,
                        confidence=0.90,
                        latency_ms=res.elapsed_ms,
                        note="user-supplied legal registry endpoint",
                    )
                    provenance.append(p_reg)
                    record = pd_entity(
                        "record",
                        f"driver:{short_hash(hash_json(item))}",
                        _pick(item, "title", "name", "fio") or safe,
                        p_reg,
                        0.90,
                        selector=safe,
                        platform="gibdd",
                        data={
                            "document_type": "vu",
                            "name": _pick(item, "name", "fio", "full_name"),
                            "birth_date": _pick(item, "birth_date", "dob"),
                            "categories": _pick(item, "categories", "category"),
                            "status": _pick(item, "status"),
                            "region": _pick(item, "region"),
                        },
                        raw_hash=hash_json(item),
                    )
                    entities.append(record)
                    edges.append(
                        edge(
                            identifier.id,
                            record.id,
                            "observed_in",
                            0.90,
                            p_reg,
                            note="record from the user-supplied legal endpoint",
                        )
                    )

        return self.result(
            "ok",
            entities=entities,
            edges=edges,
            provenance=provenance,
            gaps=gaps,
        )