"""Публичный поиск по телефону: t.me + объявления Avito/Youla.

Что делает модуль:
- открывает публичную страницу ``t.me/+<phone>`` и извлекает ``tgme_page_title``
  и описание, если Telegram их отдаёт;
- пытается прочитать публичную выдачу Avito/Youla через httpx (браузерные
  заголовки) или Playwright, если он включён через ``MC1H_PLAYWRIGHT=1``;
- при 401/403/407/429/439/451 или капче возвращает gap ``captcha/blocked`` и
  НЕ пытается обходить защиту;
- не авторизуется, не подставляет cookies чужих сессий и не решает капчу.

Важно: найденная страница/объявление — это наблюдение, а не доказательство
владения номером. Поэтому связи имеют confidence 0.45–0.60 и тип
``observed_in``, а не ``verified_link``.
"""

from __future__ import annotations

import asyncio
import html
import json
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any
from urllib.parse import quote, unquote, urljoin, urlsplit

from ...opsec import HttpFetcher
from ...schemas import Edge, Entity, ResolverResult
from ..base import edge, prov
from .base import PDResolver, ResolveContext
from .common import gap_note, hash_json, mask_phone, pd_entity, sha256_hex

BROWSER_HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/124.0.0.0 Safari/537.36"
    ),
    "Accept": (
        "text/html,application/xhtml+xml,application/xml;q=0.9,"
        "image/avif,image/webp,*/*;q=0.8"
    ),
    "Accept-Language": "ru-RU,ru;q=0.9,en;q=0.6",
    "Cache-Control": "no-cache",
    "Pragma": "no-cache",
    "Upgrade-Insecure-Requests": "1",
}

BLOCKED_STATUSES = {401, 403, 407, 429, 439, 451}

BLOCK_MARKERS = (
    "подтвердите, что вы не робот",
    "доступ ограничен",
    "access denied",
    "captcha",
    "qrator",
    "cf-chl-",
    "checking your browser",
)

NAV_WORDS = {
    "войти", "помощь", "ещё", "еще", "все категории", "избранное",
    "сообщения", "разместить объявление", "мои объявления", "на главную",
}


@dataclass
class PageResult:
    url: str
    status: int | None
    text: str | None
    error: str | None = None
    via: str = "httpx"


class PhoneSearchResolver(PDResolver):
    name = "phone_search"
    selector_type = "phone"

    async def resolve(
        self, ctx: ResolveContext, fetcher: HttpFetcher
    ) -> ResolverResult:
        e164 = ctx.normalized.strip()
        if not e164.startswith("+"):
            return self.result(
                "invalid", error="phone_search требует нормализованный E.164"
            )

        digits = re.sub(r"\D", "", e164)
        masked = mask_phone(e164)
        provenance = []
        entities = []
        edges = []
        gaps: list[str] = []
        blocked = False
        failed = False

        # 1. t.me: публичная страница контакта/профиля.
        tme_url = f"https://t.me/+{digits}"
        tme = await self._safe_get(fetcher, tme_url, headers=BROWSER_HEADERS)
        provenance.append(
            self._provenance(
                "t.me", tme_url, tme, 0.0, query=masked,
                note="public Telegram page",
            )
        )
        if tme.status in BLOCKED_STATUSES:
            blocked = True
            gaps.append(gap_note("t.me", f"captcha/blocked (HTTP {tme.status})"))
        elif tme.status == 200 and tme.text:
            parsed = _parse_tme(tme.text)
            if parsed["page_title"]:
                contact_only = parsed["contact_only"]
                confidence = 0.60 if contact_only else 0.85
                p = prov(
                    "t.me",
                    tme_url,
                    query=masked,
                    http_status=200,
                    outcome="ok",
                    confidence=confidence,
                    note=(
                        "public Telegram contact page; display_name not exposed"
                        if contact_only
                        else "public Telegram page with tgme_page_title"
                    ),
                )
                entity = pd_entity(
                    "account",
                    f"telegram:{sha256_hex(digits)[:16]}",
                    parsed["display_name"] or f"Telegram: {masked}",
                    p,
                    confidence,
                    selector=masked,
                    platform="telegram",
                    profile_url=tme_url,
                    data={
                        "phone_masked": masked,
                        "phone_sha256": sha256_hex(digits),
                        "display_name": parsed["display_name"],
                        "page_title": parsed["page_title"],
                        "description": parsed["description"],
                        "contact_only": contact_only,
                        "url": tme_url,
                    },
                    raw_hash=hash_json(
                        {
                            "phone": digits,
                            "url": tme_url,
                            "title": parsed["page_title"],
                            "description": parsed["description"],
                        }
                    ),
                )
                entities.append(entity)
                edges.append(
                    edge(
                        ctx.root_id,
                        entity.id,
                        "observed_in",
                        confidence,
                        p,
                        note=(
                            "public t.me contact page for this number; "
                            "ownership is not proven"
                        ),
                    )
                )
                provenance.append(p)
                if contact_only:
                    gaps.append(
                        gap_note(
                            "t.me",
                            "страница 200, но Telegram отдал только контактную "
                            "ссылку без display_name/описания профиля",
                        )
                    )
            else:
                gaps.append(
                    gap_note(
                        "t.me",
                        "страница 200, но tgme_page_title не найден "
                        "(закрытый профиль или другая разметка)",
                    )
                )
        elif tme.status in (404, 410):
            gaps.append(gap_note("t.me", f"публичная страница не найдена (HTTP {tme.status})"))
        else:
            failed = True
            gaps.append(gap_note("t.me", f"запрос не выполнен: {tme.error or tme.status}"))

        # 2. Avito/Youla: сначала локальный HTML-экспорт, затем HTTP.
        #    Локальный файл — это данные, которые пользователь сохранил сам;
        #    сетевой обход защиты не выполняется.
        for site, url, marker in (
            (
                "avito.ru",
                f"https://www.avito.ru/rossiya?q={quote('+' + digits)}",
                "avito",
            ),
            (
                "youla.ru",
                f"https://youla.ru/search?q={quote('+' + digits)}",
                "youla",
            ),
        ):
            local_path = Path(ctx.settings.local_data_dir) / f"{marker}_{digits}.html"

            if local_path.exists():
                provenance.append(
                    prov(
                        f"{marker}.local_html",
                        str(local_path),
                        query=masked,
                        outcome="ok",
                        confidence=0.45,
                        note="manual HTML export; no network request",
                    )
                )
                try:
                    local_entities, local_edges, listings = self._parse_local_html(
                        str(local_path), site, ctx=ctx
                    )
                except OSError as exc:
                    failed = True
                    gaps.append(
                        gap_note(site, f"manual_export_error: {local_path}: {exc}")
                    )
                    continue
                entities.extend(local_entities)
                edges.extend(local_edges)
                if not listings:
                    gaps.append(
                        gap_note(site, f"manual_export_empty: {local_path}")
                    )
                continue

            page = await self._marketplace_get(ctx, fetcher, url)
            provenance.append(
                self._provenance(
                    site, url, page, 0.0, query=masked,
                    note="public search",
                )
            )
            missing_hint = f"manual_export_missing: ожидается {local_path}"
            if page.status in BLOCKED_STATUSES:
                blocked = True
                gaps.append(
                    gap_note(
                        site,
                        f"captcha/blocked (HTTP {page.status}); {missing_hint}",
                    )
                )
                continue
            if page.status != 200 or not page.text:
                failed = True
                gaps.append(
                    gap_note(
                        site,
                        f"запрос не выполнен: "
                        f"{page.error or ('HTTP ' + str(page.status))}; {missing_hint}",
                    )
                )
                continue
            if _looks_blocked(page.text):
                blocked = True
                gaps.append(
                    gap_note(
                        site,
                        f"captcha/blocked (маркеры защиты в HTML); {missing_hint}",
                    )
                )
                continue

            listings = _parse_listings(page.text, url, marker)
            if not listings:
                gaps.append(
                    gap_note(
                        site,
                        "объявления не найдены или разметка выдачи не распознана; "
                        f"{missing_hint}",
                    )
                )
                continue

            for title, link in listings[:5]:
                p = prov(
                    site,
                    url,
                    query=masked,
                    http_status=200,
                    outcome="ok",
                    confidence=0.45,
                    note="public search result; listing may be unrelated",
                )
                entity = pd_entity(
                    "record",
                    f"{marker}:{sha256_hex(link)[:16]}",
                    title,
                    p,
                    0.45,
                    selector=masked,
                    platform=marker,
                    profile_url=link,
                    data={
                        "title": title,
                        "url": link,
                        "query_phone_masked": masked,
                        "source": site,
                    },
                    raw_hash=hash_json({"url": link, "title": title}),
                )
                entities.append(entity)
                edges.append(
                    edge(
                        ctx.root_id,
                        entity.id,
                        "observed_in",
                        0.45,
                        p,
                        note="public listing found by phone query; not proof of ownership",
                    )
                )
                provenance.append(p)

        if entities:
            status = "ok"
        elif blocked:
            status = "blocked"
        elif failed:
            status = "error"
        else:
            status = "not_found"

        return self.result(
            status,
            entities=entities,
            edges=edges,
            provenance=provenance,
            gaps=gaps,
        )

    async def _safe_get(
        self,
        fetcher: HttpFetcher,
        url: str,
        *,
        headers: dict[str, str],
    ) -> PageResult:
        try:
            res = await fetcher.get_text(url, headers=headers)
        except Exception as exc:  # defensive: resolver must never kill the run
            return PageResult(url, None, None, f"{exc.__class__.__name__}: {exc}")
        return PageResult(url, res.status, res.text, res.error, "httpx")

    async def _marketplace_get(
        self, ctx: ResolveContext, fetcher: HttpFetcher, url: str
    ) -> PageResult:
        if ctx.settings.playwright_enabled:
            page = await asyncio.to_thread(
                _playwright_get, url, ctx.settings, BROWSER_HEADERS
            )
            if page.status is not None and page.text:
                return page
            # Playwright мог быть не установлен/упасть — пробуем httpx.
        return await self._safe_get(fetcher, url, headers=BROWSER_HEADERS)

    def _parse_local_html(
        self,
        file_path: str,
        source: str,
        ctx: ResolveContext | None = None,
    ) -> tuple[list[Entity], list[Edge], list[tuple[str, str]]]:
        """Parse a user-saved Avito/Youla HTML page.

        The file is read locally; no network request and no anti-bot bypass.
        Returns entities, edges and the raw (title, url) listings.
        """
        path = Path(file_path)
        page = path.read_text(encoding="utf-8", errors="replace")

        low = source.lower()
        if "avito" in low:
            marker = "avito"
            base_url = "https://www.avito.ru"
        elif "youla" in low:
            marker = "youla"
            base_url = "https://youla.ru"
        else:
            marker = "local"
            base_url = "https://local.invalid"

        listings = _parse_listings(page, base_url, marker)
        selector = ctx.safe_label if ctx is not None else None
        root_id = ctx.root_id if ctx is not None else "root:selector"
        entities: list[Entity] = []
        edges: list[Edge] = []

        for title, link in listings[:5]:
            p = prov(
                f"{marker}.local_html",
                str(path),
                query=selector or "",
                outcome="ok",
                confidence=0.45,
                note="manual HTML export; no network request",
            )
            entity = pd_entity(
                "record",
                f"{marker}:{sha256_hex(link)[:16]}",
                title,
                p,
                0.45,
                selector=selector,
                platform=marker,
                profile_url=link,
                data={
                    "title": title,
                    "url": link,
                    "source": source,
                    "manual_export": True,
                    "file": str(path),
                },
                raw_hash=hash_json(
                    {"url": link, "title": title, "file": str(path)}
                ),
            )
            entities.append(entity)
            edges.append(
                edge(
                    root_id,
                    entity.id,
                    "observed_in",
                    0.45,
                    p,
                    note="manual HTML export; not proof of ownership",
                )
            )

        return entities, edges, listings

    @staticmethod
    def _provenance(
        source: str,
        endpoint: str,
        page: PageResult,
        confidence: float,
        *,
        query: str,
        note: str,
    ):
        outcome = "ok" if page.status == 200 else (
            "blocked" if page.status in BLOCKED_STATUSES else "error"
        )
        if page.status in (404, 410):
            outcome = "not_found"
        return prov(
            source,
            endpoint,
            query=query,
            outcome=outcome,
            http_status=page.status,
            confidence=confidence,
            note=f"{note}; via {page.via}" + (f"; {page.error}" if page.error else ""),
        )


# ---------------------------------------------------------------------------
# t.me parser


def _parse_tme(page: str) -> dict[str, Any]:
    title = _class_text(page, "tgme_page_title")
    description = _class_text(page, "tgme_page_description")
    if not description:
        description = _class_text(page, "tgme_page_additional")

    display_name: str | None = None
    contact_only = False
    if title:
        low = title.lower()
        if low.startswith("chat with") or low.startswith("чат с"):
            contact_only = True
        elif not _mostly_phone(title):
            display_name = title

    return {
        "page_title": title,
        "display_name": display_name,
        "description": description,
        "contact_only": contact_only,
    }


def _class_text(page: str, class_name: str) -> str | None:
    pattern = re.compile(
        r'<div[^>]*class="[^"]*\b' + re.escape(class_name) + r'\b[^"]*"[^>]*>'
        r"(.*?)</div>",
        re.S | re.I,
    )
    match = pattern.search(page)
    if not match:
        return None
    return _clean(match.group(1))


def _clean(fragment: str) -> str:
    text = re.sub(r"<br\s*/?>", "\n", fragment, flags=re.I)
    text = re.sub(r"<[^>]+>", " ", text)
    text = html.unescape(text)
    return re.sub(r"\s+", " ", text).strip()


def _mostly_phone(value: str) -> bool:
    digits = re.sub(r"\D", "", value)
    return len(digits) >= 10 and len(digits) >= len(value.replace(" ", "")) - 4


# ---------------------------------------------------------------------------
# Marketplace parser


def _looks_blocked(page: str) -> bool:
    # Only visible text: JS bundles often contain the word "captcha" even on
    # a normal page, which would create a false blocked gap.
    sample = re.sub(r"<script.*?</script>", " ", page, flags=re.S | re.I)
    sample = re.sub(r"<style.*?</style>", " ", sample, flags=re.S | re.I)
    sample = _clean(sample).lower()
    return any(marker in sample for marker in BLOCK_MARKERS)


def _parse_listings(page: str, base_url: str, marker: str) -> list[tuple[str, str]]:
    found: dict[str, str] = {}

    # 1) JSON-LD ItemList/Product — самый устойчивый вариант.
    for raw in re.findall(
        r'<script[^>]+type="application/ld\+json"[^>]*>(.*?)</script>',
        page,
        re.S | re.I,
    ):
        try:
            payload = json.loads(raw)
        except (json.JSONDecodeError, ValueError):
            continue
        for item in _walk_json_ld(payload):
            name = item.get("name") or item.get("headline")
            link = item.get("url")
            if isinstance(name, str) and isinstance(link, str):
                found.setdefault(_absolute(link, base_url), _clean(name))

    # 2) Простые ссылки на карточки.  Для Avito — ссылки с числовым ID,
    #    для Youla — /product/.
    for href, inner in re.findall(
        r'<a[^>]+href="([^"]+)"[^>]*>(.*?)</a>', page, re.S | re.I
    ):
        text = _clean(inner)
        if not text or len(text) < 8 or text.lower() in NAV_WORDS:
            continue
        link = _absolute(href, base_url)
        path = urlsplit(link).path
        if marker == "youla" and "/product/" not in path:
            continue
        if marker == "avito" and not re.search(r"_\d{6,}", path):
            continue
        found.setdefault(link, text)

    return [(title, link) for link, title in found.items()][:10]


LD_ITEM_TYPES = {
    "Product",
    "Offer",
    "ListItem",
    "Apartment",
    "House",
    "Vehicle",
    "RealEstateListing",
}


def _walk_json_ld(value: Any):
    if isinstance(value, dict):
        kind = value.get("@type")
        if (
            kind in LD_ITEM_TYPES
            and value.get("url")
            and (value.get("name") or value.get("headline"))
        ):
            yield value
        for child in value.values():
            yield from _walk_json_ld(child)
    elif isinstance(value, list):
        for child in value:
            yield from _walk_json_ld(child)


def _absolute(link: str, base_url: str) -> str:
    link = html.unescape(link.strip())
    if link.startswith("//"):
        return "https:" + link
    return urljoin(base_url, link)


# ---------------------------------------------------------------------------
# Optional Playwright renderer (no captcha solving, no auth)


def _playwright_get(
    url: str, settings: Any, headers: dict[str, str]
) -> PageResult:
    try:
        from playwright.sync_api import sync_playwright
    except Exception as exc:
        return PageResult(
            url, None, None, f"playwright not installed: {exc}", "playwright"
        )

    proxy = _playwright_proxy(settings.proxies[0]) if settings.proxies else None
    try:
        with sync_playwright() as p:
            browser = p.chromium.launch(headless=True, proxy=proxy)
            page = browser.new_page(
                locale="ru-RU",
                user_agent=headers["User-Agent"],
                extra_http_headers={
                    k: v for k, v in headers.items() if k.lower() != "user-agent"
                },
            )
            response = page.goto(
                url,
                wait_until="domcontentloaded",
                timeout=int(settings.timeout_s * 1000),
            )
            page.wait_for_timeout(2000)
            body = page.content()
            status = response.status if response is not None else None
            browser.close()
            return PageResult(url, status, body, None, "playwright")
    except Exception as exc:
        return PageResult(
            url, None, None, f"{exc.__class__.__name__}: {exc}", "playwright"
        )


def _playwright_proxy(raw: str) -> dict[str, str] | None:
    raw = raw.strip()
    if not raw:
        return None
    parsed = urlsplit(raw if "://" in raw else f"http://{raw}")
    if not parsed.hostname:
        return {"server": raw}
    server = f"{parsed.scheme}://{parsed.hostname}"
    if parsed.port:
        server += f":{parsed.port}"
    result = {"server": server}
    if parsed.username:
        result["username"] = unquote(parsed.username)
    if parsed.password:
        result["password"] = unquote(parsed.password)
    return result