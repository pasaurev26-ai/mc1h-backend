"""Паспорт РФ: формат серии/номера и код региона.

There is no public API for passport verification and no checksum in the
document.  Validation is therefore limited to structure and region code.
Any lookup against breach corpora is refused and reported as a gap.
"""

from __future__ import annotations

import re

from ...opsec import HttpFetcher
from ...schemas import ResolverResult
from ..base import edge
from .base import PDResolver, ResolveContext
from .common import (
    gap_note,
    local_prov,
    mask_passport,
    pd_entity,
    sha256_hex,
)

PASSPORT_RE = re.compile(r"^(\d{4})\s*(\d{6})$")


class PassportResolver(PDResolver):
    name = "passport"
    selector_type = "passport"

    async def resolve(
        self, ctx: ResolveContext, fetcher: HttpFetcher
    ) -> ResolverResult:
        cleaned = re.sub(r"[\s-]+", "", ctx.raw)
        match = PASSPORT_RE.fullmatch(cleaned)
        if not match:
            return self.result(
                "invalid", error="паспорт должен быть в формате 4 цифры серии + 6 цифр номера"
            )

        series, number = match.group(1), match.group(2)
        region = series[:2]
        if not (1 <= int(region) <= 99):
            return self.result("invalid", error=f"код региона {region} вне диапазона 01–99")

        masked = mask_passport(series, number)
        p = local_prov(
            "passport-format",
            masked,
            1.0,
            "structure and region code only; РФ passport has no public checksum",
        )
        entity = pd_entity(
            "identifier",
            f"passport:{sha256_hex(series + number)[:16]}",
            masked,
            p,
            0.90,
            selector=masked,
            platform="passport",
            data={
                "series_masked": series[:2] + "**",
                "number_masked": "****" + number[-2:],
                "region_code": region,
                "format_valid": True,
                "authenticity_checked": False,
            },
            raw_hash=sha256_hex(series + number),
        )

        gaps = [
            gap_note(
                "МВД/Госуслуги",
                "проверка подлинности паспорта требует авторизованного доступа и "
                "законного основания; публичного API нет",
            ),
            gap_note(
                "leak databases",
                "поиск паспортных данных в утечках не реализован: это обработка "
                "украденных ПД, а не OSINT по открытым источникам",
            ),
            gap_note(
                "passport",
                "номер не имеет контрольного числа — проверен только формат и регион",
            ),
        ]

        return self.result(
            "ok",
            entities=[entity],
            edges=[
                edge(
                    ctx.root_id,
                    entity.id,
                    "same_as",
                    1.0,
                    p,
                    note="format-validated input; full series/number are not stored in the graph",
                )
            ],
            provenance=[p],
            gaps=gaps,
        )