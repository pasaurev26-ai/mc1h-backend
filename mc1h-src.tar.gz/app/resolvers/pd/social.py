"""Социальные сети: публичные страницы vk.com, TikTok, Instagram, OK.ru.

Only public OpenGraph/meta data is read.  Login walls, 403/429 and captcha are
reported as gaps; no private data, session cookies or bypass are used.
"""

from __future__ import annotations

import html as html_lib
import re
from urllib.parse import urlsplit

from ...opsec import HttpFetcher
from ...schemas import ResolverResult
from ..base import edge, prov
from .base import PDResolver, ResolveContext
from .common import (
    gap_note,
    hash_json,
    pd_entity,
    short_hash,
)

SOCIAL_HOSTS = {
    "vk.com": "vk",
    "m.vk.com": "vk",
    "tiktok.com": "tiktok",
    "www.tiktok.com": "tiktok",
    "instagram.com": "instagram",
    "www.instagram.com": "instagram",
    "ok.ru": "ok",
    "m.ok.ru": "ok",
}


def normalize_social(raw: str) -> tuple[str, str, str] | None:
    """Return (platform, handle, canonical URL) or None."""
    value = raw.strip()
    if not value:
        return None
    if "://" not in value:
        value = "https://" + value
    parts = urlsplit(value)
    host = parts.netloc.lower().removeprefix("www.")
    platform = SOCIAL_HOSTS.get(host)
    if platform is None:
        return None
    handle = parts.path.strip("/")
    if not handle:
        return None
    canonical = f"https://{host}/{handle}"
    return platform, handle, canonical


def _attr(tag: str, name: str) -> str | None:
    match = re.search(
        rf"\b{re.escape(name)}\s*=\s*(?:\"([^\"]*)\"|'([^']*)'|([^\s>]+))",
        tag,
        flags=re.I,
    )
    if not match:
        return None
    return next((v for v in match.groups() if v is not None), None)


def _meta(html_text: str) -> dict[str, str]:
    result: dict[str, str] = {}
    for match in re.finditer(r"<meta\b[^>]*>", html_text, flags=re.I):
        tag = match.group(0)
        key = _attr(tag, "property") or _attr(tag, "name")
        content = _attr(tag, "content")
        if key and content:
            result.setdefault(key.lower(), html_lib.unescape(content).strip())
    title = re.search(r"<title[^>]*>(.*?)</title>", html_text, flags=re.I | re.S)
    if title:
        result.setdefault("html:title", html_lib.unescape(re.sub(r"<[^>]+>", "", title.group(1))).strip())
    return result


def _clean(value: str | None) -> str | None:
    if not value:
        return None
    text = html_lib.unescape(re.sub(r"<[^>]+>", " ", value))
    text = re.sub(r"\s+", " ", text).strip()
    return text or None


class SocialResolver(PDResolver):
    name = "social"
    selector_type = "social"

    async def resolve(
        self, ctx: ResolveContext, fetcher: HttpFetcher
    ) -> ResolverResult:
        parsed = normalize_social(ctx.raw)
        if parsed is None:
            return self.result(
                "invalid",
                error="Поддерживаются публичные URL vk.com, tiktok.com, "
                "instagram.com и ok.ru (например, vk.com/username)",
            )
        platform, handle, url = parsed
        safe = f"{platform}:{handle}"
        res = await fetcher.get_text(
            url,
            headers={
                "Accept": "text/html,application/xhtml+xml",
                "Accept-Language": "ru,en;q=0.8",
            },
        )
        if not res.ok:
            p = prov(
                "social-public-page",
                url,
                query=safe,
                http_status=res.status,
                outcome=res.outcome,
                confidence=0.0,
                latency_ms=res.elapsed_ms,
                note=res.error,
            )
            gaps = [
                gap_note(
                    "social",
                    f"{platform}: публичная страница недоступна "
                    f"({res.outcome}); логин/captcha не обходятся",
                )
            ]
            return self.result(
                res.outcome if res.outcome in ("blocked", "not_found", "timeout") else "error",
                provenance=[p],
                error=res.error,
                gaps=gaps,
            )

        meta = _meta(res.text or "")
        title = _clean(
            meta.get("og:title")
            or meta.get("twitter:title")
            or meta.get("html:title")
        )
        description = _clean(
            meta.get("og:description") or meta.get("description")
        )
        image = meta.get("og:image") or meta.get("twitter:image")
        site_name = _clean(meta.get("og:site_name"))

        confidence = 0.55 if title and description else (0.45 if title else 0.35)
        p = prov(
            "social-public-page",
            url,
            query=safe,
            http_status=res.status,
            confidence=confidence,
            latency_ms=res.elapsed_ms,
            note="public OpenGraph/meta only; page visibility may change",
        )
        account = pd_entity(
            "account",
            f"{platform}:{short_hash(handle)}",
            title or handle,
            p,
            confidence,
            selector=safe,
            platform=platform,
            profile_url=url,
            data={
                "platform": platform,
                "handle": handle,
                "display_name": title,
                "bio": description,
                "avatar_url": image,
                "site_name": site_name,
                "http_status": res.status,
            },
            raw_hash=hash_json({"platform": platform, "handle": handle, "meta": meta}),
        )
        gaps: list[str] = []
        if not title:
            gaps.append(
                gap_note(
                    "social",
                    f"{platform}: страница открылась, но публичное имя/bio не найдены "
                    "(возможен login wall или смена разметки)",
                )
            )
        gaps.append(
            gap_note(
                "social",
                "приватные поля, подписчики и контакты не запрашиваются; "
                "это наблюдение публичной страницы, а не доказательство личности",
            )
        )
        return self.result(
            "ok",
            entities=[account],
            edges=[
                edge(
                    ctx.root_id,
                    account.id,
                    "observed_in",
                    confidence,
                    p,
                    note="public profile page observed",
                )
            ],
            provenance=[p],
            gaps=gaps,
        )