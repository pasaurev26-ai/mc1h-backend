"""ФИО (+ дата рождения): нормализация, Wikidata, опционально ЕГРЮЛ по ФИО.

Sources
-------
* Wikidata SPARQL — open, no key, exact rdfs:label match (+ birth year filter).
* ЕГРЮЛ/ЕГРИП — only through a user-supplied legal endpoint
  (MC1H_FNS_API_URL + MC1H_FNS_API_KEY); no public name-search API exists.
* kad.arbitr.ru / sudrf.ru — captcha and anti-bot; NOT automated here.

Name equality is a hypothesis, not identity.  Wikidata matches get
``handle_match``, never ``verified_link``.
"""

from __future__ import annotations

from urllib.parse import urlencode

from ...opsec import HttpFetcher
from ...schemas import ResolverResult
from ..base import edge, prov
from .base import PDResolver, ResolveContext
from .common import (
    gap_note,
    hash_json,
    local_prov,
    mask_name,
    normalize_name,
    pd_entity,
    short_hash,
    valid_name_parts,
)

WIKIDATA = "https://query.wikidata.org/sparql"


class FioResolver(PDResolver):
    name = "fio"
    selector_type = "fio"

    async def resolve(
        self, ctx: ResolveContext, fetcher: HttpFetcher
    ) -> ResolverResult:
        full, parts = normalize_name(ctx.raw)
        if not valid_name_parts(parts):
            return self.result(
                "invalid",
                error="ФИО должно состоять из 2–3 слов кириллицей/латиницей (дефис разрешён)",
            )

        provenance = []
        entities = []
        edges = []
        gaps: list[str] = []

        p_norm = local_prov(
            "fio-normalize",
            mask_name(full),
            1.0,
            "whitespace/case normalization; отчество может отсутствовать",
        )
        person = pd_entity(
            "person",
            short_hash(full + "|" + (ctx.birth_date.isoformat() if ctx.birth_date else "")),
            full,
            p_norm,
            0.90,
            selector=mask_name(full),
            data={
                "full_name": full,
                "parts": parts,
                "birth_date": ctx.birth_date.isoformat() if ctx.birth_date else None,
            },
            raw_hash=ctx.selector_sha,
        )
        entities.append(person)
        provenance.append(p_norm)
        edges.append(
            edge(
                ctx.root_id,
                person.id,
                "same_as",
                1.0,
                p_norm,
                note="person node derived from the input selector",
            )
        )

        if ctx.birth_date is None:
            gaps.append(
                gap_note(
                    "fio",
                    "дата рождения не передана — Wikidata-фильтр по году и судебные реестры ограничены",
                )
            )

        # --- Wikidata: open, keyless, exact label match -------------------
        label = full.replace("\\", "\\\\").replace('"', '\\"')
        year_filter = ""
        if ctx.birth_date is not None:
            year_filter = f"FILTER(YEAR(?dob) = {ctx.birth_date.year})"
        query = f"""
SELECT ?item ?itemLabel ?dob WHERE {{
  ?item wdt:P31 wd:Q5 .
  ?item rdfs:label "{label}"@ru .
  OPTIONAL {{ ?item wdt:P569 ?dob . }}
  {year_filter}
  SERVICE wikibase:label {{ bd:serviceParam wikibase:language "ru,en". }}
}}
LIMIT 5
""".strip()
        url = WIKIDATA + "?" + urlencode({"query": query, "format": "json"})
        res = await fetcher.get_json(
            url, headers={"Accept": "application/sparql-results+json"}
        )
        if res.ok and isinstance(res.payload, dict):
            bindings = (
                res.payload.get("results", {}).get("bindings", [])
                if isinstance(res.payload.get("results"), dict)
                else []
            )
            if bindings:
                for row in bindings:
                    item = row.get("item", {}).get("value", "")
                    qid = item.rsplit("/", 1)[-1] if item else ""
                    if not qid:
                        continue
                    item_label = row.get("itemLabel", {}).get("value") or full
                    dob = row.get("dob", {}).get("value")
                    confidence = 0.50 if ctx.birth_date else 0.35
                    p_wd = prov(
                        "wikidata",
                        "https://www.wikidata.org/wiki/Special:EntityData",
                        query=mask_name(full),
                        http_status=res.status,
                        confidence=confidence,
                        latency_ms=res.elapsed_ms,
                        note="exact rdfs:label match"
                        + (" + birth year" if ctx.birth_date else " (no DOB filter)")
                        + "; homonyms possible",
                    )
                    ent = pd_entity(
                        "person",
                        f"wikidata:{qid}",
                        item_label,
                        p_wd,
                        confidence,
                        selector=mask_name(full),
                        platform="wikidata",
                        profile_url=f"https://www.wikidata.org/wiki/{qid}",
                        data={
                            "wikidata_id": qid,
                            "label": item_label,
                            "birth_date": dob,
                            "match": "exact_label"
                            + ("_and_year" if ctx.birth_date else ""),
                        },
                        raw_hash=hash_json(row),
                    )
                    entities.append(ent)
                    provenance.append(p_wd)
                    edges.append(
                        edge(
                            ctx.root_id,
                            ent.id,
                            "handle_match",
                            confidence,
                            p_wd,
                            note="same full name"
                            + (" and birth year" if ctx.birth_date else "")
                            + "; not identity proof",
                        )
                    )
            else:
                provenance.append(
                    prov(
                        "wikidata",
                        "https://query.wikidata.org/sparql",
                        query=mask_name(full),
                        http_status=res.status,
                        outcome="not_found",
                        latency_ms=res.elapsed_ms,
                        note="no exact label match",
                    )
                )
        elif not res.ok:
            provenance.append(
                prov(
                    "wikidata",
                    "https://query.wikidata.org/sparql",
                    query=mask_name(full),
                    http_status=res.status,
                    outcome=res.outcome,
                    latency_ms=res.elapsed_ms,
                    note=res.error,
                )
            )
            gaps.append(gap_note("wikidata", f"SPARQL недоступен: {res.error}"))

        # --- ЕГРЮЛ/ЕГРИП by director name: keyed legal endpoint ------------
        if not ctx.settings.fns_api_key or not ctx.settings.fns_api_url:
            gaps.append(
                gap_note(
                    "ЕГРЮЛ/ЕГРИП",
                    "поиск по ФИО руководителя не выполнен: нужны MC1H_FNS_API_URL и "
                    "MC1H_FNS_API_KEY (публичного name-search API у ФНС нет)",
                )
            )
        else:
            base = ctx.settings.fns_api_url
            sep = "&" if "?" in base else "?"
            fns_url = base + sep + urlencode(
                {"query": full, "key": ctx.settings.fns_api_key}
            )
            fns = await fetcher.get_json(fns_url)
            if not fns.ok:
                provenance.append(
                    prov(
                        "egrul",
                        base,
                        query=mask_name(full),
                        http_status=fns.status,
                        outcome=fns.outcome,
                        latency_ms=fns.elapsed_ms,
                        note=fns.error,
                    )
                )
                gaps.append(gap_note("ЕГРЮЛ/ЕГРИП", f"запрос не выполнен: {fns.error}"))
            else:
                items = _items(fns.payload)
                if not items:
                    provenance.append(
                        prov(
                            "egrul",
                            base,
                            query=mask_name(full),
                            http_status=fns.status,
                            outcome="not_found",
                            latency_ms=fns.elapsed_ms,
                            note="no organization records",
                        )
                    )
                for item in items[:20]:
                    name = _pick(item, "НаимПолн", "name", "Наименование", "short_name")
                    inn = _pick(item, "ИНН", "inn")
                    ogrn = _pick(item, "ОГРН", "ogrn")
                    if not name:
                        continue
                    p_org = prov(
                        "egrul",
                        base,
                        query=mask_name(full),
                        http_status=fns.status,
                        confidence=0.80,
                        latency_ms=fns.elapsed_ms,
                        note="registry record matched by person name; homonyms possible",
                    )
                    org = pd_entity(
                        "organization",
                        f"egrul:{ogrn or inn or short_hash(hash_json(item))}",
                        str(name),
                        p_org,
                        0.80,
                        selector=mask_name(full),
                        platform="egrul",
                        data={
                            "name": name,
                            "inn": inn,
                            "ogrn": ogrn,
                            "kpp": _pick(item, "КПП", "kpp"),
                            "status": _pick(item, "Статус", "status"),
                            "address": _pick(item, "АдресПолн", "address"),
                            "okved": _pick(item, "ОКВЭД", "okved"),
                        },
                        raw_hash=hash_json(item),
                    )
                    entities.append(org)
                    provenance.append(p_org)
                    edges.append(
                        edge(
                            person.id,
                            org.id,
                            "director_of",
                            0.70,
                            p_org,
                            note="registry name match; verify ОГРН and director identity manually",
                        )
                    )

        gaps.extend(
            [
                gap_note(
                    "kad.arbitr.ru",
                    "арбитраж: captcha/anti-bot — автоматический запрос не выполняется",
                ),
                gap_note(
                    "sudrf.ru",
                    "суды общей юрисдикции: captcha/anti-bot — автоматический запрос не выполняется",
                ),
            ]
        )

        return self.result(
            "ok",
            entities=entities,
            edges=edges,
            provenance=provenance,
            gaps=gaps,
        )


def _items(payload: object) -> list[dict]:
    if isinstance(payload, list):
        return [x for x in payload if isinstance(x, dict)]
    if isinstance(payload, dict):
        for key in ("items", "data", "results", "organizations"):
            value = payload.get(key)
            if isinstance(value, list):
                return [x for x in value if isinstance(x, dict)]
    return []


def _pick(item: dict, *keys: str) -> str | None:
    for key in keys:
        value = item.get(key)
        if value not in (None, "", [], {}):
            return str(value)
    return None