"""ИНН: контрольное число, тип, регион; опционально ЕГРЮЛ/ЕГРИП.

The checksum is deterministic and offline.  Registry data is fetched only
through a user-supplied legal endpoint (MC1H_FNS_API_URL + MC1H_FNS_API_KEY);
without it the lookup is reported as a gap, never invented.
"""

from __future__ import annotations

from urllib.parse import urlencode

from ...opsec import HttpFetcher
from ...schemas import ResolverResult
from ..base import edge, prov
from .base import PDResolver, ResolveContext
from .common import (
    gap_note,
    hash_json,
    local_prov,
    pd_entity,
    short_hash,
)

W10 = [2, 4, 10, 3, 5, 9, 4, 6, 8]
W11 = [7, 2, 4, 10, 3, 5, 9, 4, 6, 8]
W12 = [3, 7, 2, 4, 10, 3, 5, 9, 4, 6, 8]


def inn_checksum_valid(inn: str) -> bool:
    if not inn.isdigit() or len(inn) not in (10, 12):
        return False
    digits = [int(c) for c in inn]
    if len(inn) == 10:
        control = sum(a * b for a, b in zip(digits, W10)) % 11 % 10
        return control == digits[9]
    c11 = sum(a * b for a, b in zip(digits, W11)) % 11 % 10
    c12 = sum(a * b for a, b in zip(digits, W12)) % 11 % 10
    return c11 == digits[10] and c12 == digits[11]


class InnResolver(PDResolver):
    name = "inn"
    selector_type = "inn"

    async def resolve(
        self, ctx: ResolveContext, fetcher: HttpFetcher
    ) -> ResolverResult:
        inn = "".join(c for c in ctx.raw if c.isdigit())
        if len(inn) not in (10, 12):
            return self.result("invalid", error="ИНН должен содержать 10 или 12 цифр")
        if not inn_checksum_valid(inn):
            return self.result("invalid", error="ИНН не проходит проверку контрольного числа")

        kind = "legal_entity" if len(inn) == 10 else "individual"
        region = inn[:2]
        p = local_prov(
            "inn-checksum",
            inn,
            1.0,
            "official 10/12-digit checksum; format does not prove the entity exists",
        )
        entity = pd_entity(
            "identifier",
            f"inn:{inn}",
            inn,
            p,
            1.0,
            selector=inn,
            platform="inn",
            data={
                "inn": inn,
                "kind": kind,
                "region_code": region,
                "tax_office_code": inn[2:4],
                "checksum_valid": True,
                "digits": len(inn),
            },
            raw_hash=hash_json({"inn": inn, "kind": kind}),
        )
        entities = [entity]
        provenance = [p]
        edges = [
            edge(
                ctx.root_id,
                entity.id,
                "same_as",
                1.0,
                p,
                note="checksum-validated input identifier",
            )
        ]
        gaps: list[str] = []

        if not ctx.settings.fns_api_key or not ctx.settings.fns_api_url:
            gaps.append(
                gap_note(
                    "ЕГРЮЛ/ЕГРИП",
                    "поиск по ИНН не выполнен: нужны MC1H_FNS_API_URL и "
                    "MC1H_FNS_API_KEY (легальный API ФНС/партнёра)",
                )
            )
        else:
            base = ctx.settings.fns_api_url
            sep = "&" if "?" in base else "?"
            url = base + sep + urlencode(
                {"req": inn, "key": ctx.settings.fns_api_key}
            )
            res = await fetcher.get_json(url)
            if not res.ok:
                provenance.append(
                    prov(
                        "egrul",
                        base,
                        query=inn,
                        http_status=res.status,
                        outcome=res.outcome,
                        latency_ms=res.elapsed_ms,
                        note=res.error,
                    )
                )
                gaps.append(gap_note("ЕГРЮЛ/ЕГРИП", f"запрос не выполнен: {res.error}"))
            else:
                items = _items(res.payload)
                if not items:
                    provenance.append(
                        prov(
                            "egrul",
                            base,
                            query=inn,
                            http_status=res.status,
                            outcome="not_found",
                            latency_ms=res.elapsed_ms,
                            note="no registry record",
                        )
                    )
                    gaps.append(
                        gap_note(
                            "ЕГРЮЛ/ЕГРИП",
                            "API ответил без записей — ИНН может быть недействующим "
                            "или отсутствовать в доступном контуре",
                        )
                    )
                for item in items[:10]:
                    p_reg = prov(
                        "egrul",
                        base,
                        query=inn,
                        http_status=res.status,
                        confidence=0.95,
                        latency_ms=res.elapsed_ms,
                        note="official/partner registry response",
                    )
                    provenance.append(p_reg)
                    name = _pick(item, "НаимПолн", "name", "Наименование", "ФИО")
                    ogrn = _pick(item, "ОГРН", "ogrn", "ОГРНИП")
                    common = {
                        "name": name,
                        "inn": inn,
                        "ogrn": ogrn,
                        "kpp": _pick(item, "КПП", "kpp"),
                        "status": _pick(item, "Статус", "status"),
                        "address": _pick(item, "АдресПолн", "address"),
                        "okved": _pick(item, "ОКВЭД", "okved"),
                        "registration_date": _pick(item, "ДатаРег", "registration_date"),
                    }
                    if kind == "legal_entity" and name:
                        org = pd_entity(
                            "organization",
                            f"egrul:{ogrn or inn}",
                            str(name),
                            p_reg,
                            0.95,
                            selector=inn,
                            platform="egrul",
                            data=common,
                            raw_hash=hash_json(item),
                        )
                        entities.append(org)
                        edges.append(
                            edge(
                                entity.id,
                                org.id,
                                "registered_as",
                                0.95,
                                p_reg,
                                note="ИНН found in the registry response",
                            )
                        )
                    elif name:
                        person = pd_entity(
                            "person",
                            f"fns:{short_hash(inn + '|' + str(name))}",
                            str(name),
                            p_reg,
                            0.85,
                            selector=inn,
                            platform="fns",
                            data=common,
                            raw_hash=hash_json(item),
                        )
                        entities.append(person)
                        edges.append(
                            edge(
                                entity.id,
                                person.id,
                                "identified_as",
                                0.85,
                                p_reg,
                                note="registry returns a name for this ИНН; verify manually",
                            )
                        )
                    else:
                        rec = pd_entity(
                            "record",
                            f"fns:{short_hash(hash_json(item))}",
                            f"ФНС запись {inn}",
                            p_reg,
                            0.90,
                            selector=inn,
                            platform="fns",
                            data=common,
                            raw_hash=hash_json(item),
                        )
                        entities.append(rec)
                        edges.append(
                            edge(
                                entity.id,
                                rec.id,
                                "observed_in",
                                0.90,
                                p_reg,
                            )
                        )

        return self.result(
            "ok",
            entities=entities,
            edges=edges,
            provenance=provenance,
            gaps=gaps,
        )


def _items(payload: object) -> list[dict]:
    if isinstance(payload, list):
        return [x for x in payload if isinstance(x, dict)]
    if isinstance(payload, dict):
        for key in ("items", "data", "results", "organizations"):
            value = payload.get(key)
            if isinstance(value, list):
                return [x for x in value if isinstance(x, dict)]
    return []


def _pick(item: dict, *keys: str) -> str | None:
    for key in keys:
        value = item.get(key)
        if value not in (None, "", [], {}):
            return str(value)
    return None