"""Онлайн-следы: домен/IP (DNS + RDAP) и /tag (публичный поиск).

The resolver is deliberately transparent: DNS/RDAP are deterministic public
protocols; /tag uses a public search page or a user-supplied search API and
marks every hit as a hypothesis, not identity proof.  Phone books and
classifieds have no universal public API, so that limitation is a gap.
"""

from __future__ import annotations

import asyncio
import html as html_lib
import ipaddress
import re
from urllib.parse import quote, urlencode

from ...opsec import HttpFetcher
from ...schemas import ResolverResult
from ..base import edge, prov
from .base import PDResolver, ResolveContext
from .common import (
    gap_note,
    hash_json,
    local_prov,
    pd_entity,
    short_hash,
)

DOMAIN_RE = re.compile(
    r"^(?=.{4,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$",
    re.I,
)


def normalize_online(raw: str) -> tuple[str, str] | None:
    """Return (``domain``|``ip``|``tag``, normalized) or None."""
    value = " ".join(raw.strip().split())
    if not value:
        return None
    candidate = value
    if "://" in candidate:
        from urllib.parse import urlsplit

        candidate = urlsplit(candidate).netloc or candidate
    candidate = candidate.strip("[]").strip(".")
    try:
        ip = ipaddress.ip_address(candidate)
        return "ip", str(ip)
    except ValueError:
        pass
    if DOMAIN_RE.fullmatch(candidate.lower()):
        return "domain", candidate.lower()
    return "tag", value


def _clean(value: object) -> str | None:
    if value is None:
        return None
    text = html_lib.unescape(re.sub(r"<[^>]+>", " ", str(value)))
    text = re.sub(r"\s+", " ", text).strip()
    return text or None


def _items(payload: object) -> list[dict]:
    if isinstance(payload, list):
        return [x for x in payload if isinstance(x, dict)]
    if isinstance(payload, dict):
        for key in ("items", "results", "data", "organic_results"):
            value = payload.get(key)
            if isinstance(value, list):
                return [x for x in value if isinstance(x, dict)]
    return []


def _pick(item: dict, *keys: str) -> str | None:
    for key in keys:
        value = item.get(key)
        if value not in (None, "", [], {}):
            return _clean(value)
    return None


class OnlineTracesResolver(PDResolver):
    name = "online_traces"
    selector_type = "online_traces"

    async def resolve(
        self, ctx: ResolveContext, fetcher: HttpFetcher
    ) -> ResolverResult:
        parsed = normalize_online(ctx.raw)
        if parsed is None:
            return self.result("invalid", error="Пустой селектор онлайн-следов")
        kind, value = parsed
        if kind in ("domain", "ip"):
            return await self._network(ctx, fetcher, kind, value)
        return await self._tag(ctx, fetcher, value)

    async def _dns(self, fetcher: HttpFetcher, name: str, rtype: str) -> tuple[list[str], object]:
        url = (
            "https://cloudflare-dns.com/dns-query?"
            + urlencode({"name": name, "type": rtype})
        )
        res = await fetcher.get_json(url, headers={"Accept": "application/dns-json"})
        answers: list[str] = []
        if res.ok and isinstance(res.payload, dict):
            for row in res.payload.get("Answer", []) or []:
                if isinstance(row, dict) and row.get("data"):
                    answers.append(str(row["data"]))
        return answers, res

    async def _network(
        self, ctx: ResolveContext, fetcher: HttpFetcher, kind: str, value: str
    ) -> ResolverResult:
        safe = value
        p = local_prov(
            "network-normalize",
            safe,
            0.90,
            "validated domain/IP literal; not a search result",
        )
        identifier = pd_entity(
            "identifier",
            f"online:{kind}:{value}",
            safe,
            p,
            0.95,
            selector=safe,
            platform=kind,
            data={"kind": kind, kind: value},
            raw_hash=hash_json({"kind": kind, "value": value}),
        )
        entities = [identifier]
        provenance = [p]
        edges = [
            edge(
                ctx.root_id,
                identifier.id,
                "same_as",
                1.0,
                p,
                note="normalized public network selector",
            )
        ]
        gaps: list[str] = []

        if kind == "domain":
            (a_records, a_res), (mx_records, mx_res) = await asyncio.gather(
                self._dns(fetcher, value, "A"),
                self._dns(fetcher, value, "MX"),
            )
            for label, records, res in (
                ("DNS A", a_records, a_res),
                ("DNS MX", mx_records, mx_res),
            ):
                if res.ok:
                    provenance.append(
                        prov(
                            "dns-doh",
                            "https://cloudflare-dns.com/dns-query",
                            query=f"{value} {label}",
                            http_status=res.status,
                            confidence=0.90,
                            latency_ms=res.elapsed_ms,
                            note=", ".join(records[:10]) or "no records",
                        )
                    )
                else:
                    gaps.append(gap_note(label, f"запрос не выполнен: {res.error}"))
            identifier.data["dns_a"] = a_records
            identifier.data["dns_mx"] = mx_records

        rdap_url = (
            f"https://rdap.org/{'domain' if kind == 'domain' else 'ip'}/"
            f"{quote(value, safe='')}"
        )
        rdap = await fetcher.get_json(rdap_url)
        if not rdap.ok:
            provenance.append(
                prov(
                    "rdap",
                    rdap_url,
                    query=safe,
                    http_status=rdap.status,
                    outcome=rdap.outcome,
                    latency_ms=rdap.elapsed_ms,
                    note=rdap.error,
                )
            )
            gaps.append(
                gap_note(
                    "RDAP",
                    f"регистрационные данные не получены ({rdap.outcome}): "
                    f"{rdap.error or 'no record'}",
                )
            )
        elif isinstance(rdap.payload, dict):
            data = rdap.payload
            status = data.get("status") or []
            events = {
                str(e.get("eventAction")): e.get("eventDate")
                for e in data.get("events", [])
                if isinstance(e, dict) and e.get("eventAction")
            }
            registrar = None
            for entity in data.get("entities", []) or []:
                if not isinstance(entity, dict):
                    continue
                roles = [str(x).lower() for x in entity.get("roles", []) or []]
                if "registrar" in roles:
                    vcard = entity.get("vcardArray")
                    if isinstance(vcard, list) and len(vcard) > 1:
                        for row in vcard[1]:
                            if isinstance(row, list) and len(row) >= 4 and row[0] == "fn":
                                registrar = _clean(row[3])
                                break
                    registrar = registrar or entity.get("handle")
            p_rdap = prov(
                "rdap",
                rdap_url,
                query=safe,
                http_status=rdap.status,
                confidence=0.90,
                latency_ms=rdap.elapsed_ms,
                note="public RDAP registration data",
            )
            provenance.append(p_rdap)
            record = pd_entity(
                "record",
                f"rdap:{short_hash(hash_json(data))}",
                f"RDAP {value}",
                p_rdap,
                0.90,
                selector=safe,
                platform="rdap",
                profile_url=rdap_url,
                data={
                    "kind": kind,
                    "name": data.get("ldhName") or data.get("handle") or value,
                    "status": status,
                    "events": events,
                    "registrar": registrar,
                    "start_address": data.get("startAddress"),
                    "end_address": data.get("endAddress"),
                    "country": data.get("country"),
                },
                raw_hash=hash_json(data),
            )
            entities.append(record)
            edges.append(
                edge(
                    identifier.id,
                    record.id,
                    "observed_in",
                    0.90,
                    p_rdap,
                    note="public RDAP record",
                )
            )
        else:
            gaps.append(gap_note("RDAP", "ответ не является JSON-объектом"))

        gaps.append(
            gap_note(
                "онлайн-следы",
                "DNS/RDAP показывают инфраструктуру, но не владельца; "
                "персональные данные не выводятся",
            )
        )
        return self.result(
            "ok",
            entities=entities,
            edges=edges,
            provenance=provenance,
            gaps=gaps,
        )

    async def _tag(
        self, ctx: ResolveContext, fetcher: HttpFetcher, query: str
    ) -> ResolverResult:
        if not query:
            return self.result("invalid", error="Пустой /tag-запрос")
        safe = query
        p_norm = local_prov(
            "tag-normalize",
            safe,
            0.35,
            "free-text hypothesis; no direct phone-book/classifieds API",
        )
        root_identifier = pd_entity(
            "identifier",
            f"tag:{short_hash(query)}",
            safe,
            p_norm,
            0.35,
            selector=safe,
            platform="tag",
            data={"query": query, "kind": "tag"},
            raw_hash=hash_json({"tag": query}),
        )
        entities = [root_identifier]
        edges = [
            edge(
                ctx.root_id,
                root_identifier.id,
                "same_as",
                1.0,
                p_norm,
                note="free-text tag query",
            )
        ]
        provenance = [p_norm]
        gaps: list[str] = []

        items: list[dict] = []
        if ctx.settings.search_api_url and ctx.settings.search_api_key:
            base = ctx.settings.search_api_url
            sep = "&" if "?" in base else "?"
            url = base + sep + urlencode(
                {"q": query, "key": ctx.settings.search_api_key, "limit": 10}
            )
            res = await fetcher.get_json(url)
            if not res.ok:
                provenance.append(
                    prov(
                        "search-api",
                        base,
                        query=safe,
                        http_status=res.status,
                        outcome=res.outcome,
                        latency_ms=res.elapsed_ms,
                        note=res.error,
                    )
                )
                gaps.append(gap_note("search-api", f"запрос не выполнен: {res.error}"))
            else:
                items = _items(res.payload)
        else:
            url = "https://html.duckduckgo.com/html/?" + urlencode(
                {"q": f'{query} (телефон OR объявление OR резюме)'}
            )
            res = await fetcher.get_text(
                url,
                headers={
                    "Accept": "text/html",
                    "Accept-Language": "ru,en;q=0.8",
                },
            )
            if not res.ok:
                provenance.append(
                    prov(
                        "duckduckgo-html",
                        "https://html.duckduckgo.com/html/",
                        query=safe,
                        http_status=res.status,
                        outcome=res.outcome,
                        latency_ms=res.elapsed_ms,
                        note=res.error,
                    )
                )
                gaps.append(
                    gap_note(
                        "публичный поиск",
                        f"поиск не выполнен ({res.outcome}); API ключ "
                        "MC1H_SEARCH_API_URL/KEY не задан",
                    )
                )
            else:
                html_text = res.text or ""
                for match in re.finditer(
                    r'<a[^>]+class="[^"]*result__a[^"]*"[^>]*href="([^"]+)"[^>]*>(.*?)</a>',
                    html_text,
                    flags=re.I | re.S,
                ):
                    href = html_lib.unescape(match.group(1))
                    title = _clean(match.group(2))
                    if href and title:
                        items.append({"url": href, "title": title})
                if not items:
                    gaps.append(
                        gap_note(
                            "публичный поиск",
                            "результаты не распознаны (возможна captcha/смена разметки)",
                        )
                    )
                else:
                    provenance.append(
                        prov(
                            "duckduckgo-html",
                            "https://html.duckduckgo.com/html/",
                            query=safe,
                            http_status=res.status,
                            confidence=0.35,
                            latency_ms=res.elapsed_ms,
                            note=f"{len(items)} public search results",
                        )
                    )

        for item in items[:10]:
            title = _pick(item, "title", "name", "snippet")
            url = _pick(item, "url", "link", "href")
            snippet = _pick(item, "snippet", "description", "text")
            if not title and not url:
                continue
            p = prov(
                "public-search",
                url or "https://html.duckduckgo.com/html/",
                query=safe,
                confidence=0.35,
                note="public search hit; hypothesis only",
            )
            provenance.append(p)
            record = pd_entity(
                "record",
                f"web:{short_hash((url or '') + (title or '') + (snippet or ''))}",
                title or url or "web result",
                p,
                0.35,
                selector=safe,
                platform="web",
                profile_url=url,
                data={
                    "title": title,
                    "url": url,
                    "snippet": snippet,
                    "query": query,
                    "match": "public_search",
                },
                raw_hash=hash_json(item),
            )
            entities.append(record)
            edges.append(
                edge(
                    root_identifier.id,
                    record.id,
                    "observed_in",
                    0.35,
                    p,
                    note="search hit; verify manually, not identity proof",
                )
            )

        gaps.append(
            gap_note(
                "телефонные книги/объявления",
                "универсального публичного API нет; /tag использует публичный "
                "поиск и может быть неполным или заблокированным",
            )
        )
        return self.result(
            "ok",
            entities=entities,
            edges=edges,
            provenance=provenance,
            gaps=gaps,
        )