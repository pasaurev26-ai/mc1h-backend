"""Docker Hub public user profile.

API: https://hub.docker.com/v2/users/<username>/  (undocumented but stable, no auth)
"""

from __future__ import annotations

from urllib.parse import quote

from ..opsec import HttpFetcher
from ..schemas import ResolverResult
from .base import Resolver, account, clean, edge, iso, prov


class DockerHubResolver(Resolver):
    name = "dockerhub"
    platform = "dockerhub"

    async def resolve(self, handle: str, fetcher: HttpFetcher) -> ResolverResult:
        url = f"https://hub.docker.com/v2/users/{quote(handle)}/"
        res = await fetcher.get_json(url)
        if not res.ok:
            return self.result(
                res.outcome,
                provenance=[prov("dockerhub", url, query=f"user={handle}", outcome=res.outcome,
                                 http_status=res.status, latency_ms=res.elapsed_ms)],
                error=res.error,
            )
        data = res.payload if isinstance(res.payload, dict) else {}
        username = data.get("username")
        if not username:
            return self.result("error", error="unexpected Docker Hub payload")

        confidence = 0.7 if str(username).lower() == handle.lower() else 0.5
        p = prov("dockerhub", url, query=f"user={username}", http_status=res.status,
                 latency_ms=res.elapsed_ms, confidence=confidence)
        entity = account(
            "dockerhub", str(username), data.get("full_name") or str(username), p, confidence,
            **clean({
                "user_id": data.get("id"),
                "location": data.get("location"),
                "company": data.get("company"),
                "profile_url": data.get("profile_url") or f"https://hub.docker.com/u/{username}",
                "date_joined": iso(data.get("date_joined")),
                "type": data.get("type"),
                "gravatar_url": data.get("gravatar_url"),
            }),
        )
        e = edge("root:selector", entity.id, "handle_match", confidence, p,
                 note="exact Docker Hub username match")
        return self.result("ok", entities=[entity], edges=[e], provenance=[p])