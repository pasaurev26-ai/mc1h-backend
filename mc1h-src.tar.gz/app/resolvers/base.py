"""Resolver contract and shared builders."""

from __future__ import annotations

from abc import ABC, abstractmethod
from datetime import datetime, timezone
from typing import Any

from ..opsec import HttpFetcher
from ..schemas import Edge, Entity, Outcome, Provenance, ResolverResult


class Resolver(ABC):
    """One platform per module. Must never raise: return an error result instead."""

    name: str
    platform: str

    @abstractmethod
    async def resolve(self, handle: str, fetcher: HttpFetcher) -> ResolverResult:
        raise NotImplementedError

    def result(self, status: Outcome, **kwargs: Any) -> ResolverResult:
        return ResolverResult(source=self.name, status=status, **kwargs)


def prov(
    source: str,
    endpoint: str,
    *,
    query: str = "",
    outcome: Outcome = "ok",
    http_status: int | None = None,
    confidence: float = 0.0,
    latency_ms: int | None = None,
    note: str | None = None,
) -> Provenance:
    return Provenance(
        source=source,
        endpoint=endpoint,
        query=query,
        outcome=outcome,
        http_status=http_status,
        confidence=confidence,
        latency_ms=latency_ms,
        note=note,
    )


def account(
    platform: str,
    handle: str,
    label: str | None,
    p: Provenance,
    confidence: float,
    **attributes: Any,
) -> Entity:
    key = f"{platform}:{handle.lower()}"
    return Entity.make(
        "account",
        key,
        label or handle,
        attributes={"platform": platform, "handle": handle, **attributes},
        provenance=[p],
        confidence=confidence,
    )


def artifact(
    namespace: str,
    key: str,
    label: str,
    p: Provenance,
    confidence: float,
    **attributes: Any,
) -> Entity:
    return Entity.make(
        "artifact",
        f"{namespace}:{key}",
        label,
        attributes={"namespace": namespace, **attributes},
        provenance=[p],
        confidence=confidence,
    )


def edge(
    src: str,
    dst: str,
    relation: str,
    confidence: float,
    p: Provenance,
    note: str | None = None,
) -> Edge:
    return Edge(src=src, dst=dst, relation=relation, confidence=confidence, provenance=p, note=note)


def iso(value: Any) -> str | None:
    """Accept unix seconds or ISO string; return ISO-8601 UTC or None."""
    if value is None:
        return None
    if isinstance(value, (int, float)):
        try:
            return datetime.fromtimestamp(float(value), tz=timezone.utc).isoformat()
        except (OverflowError, OSError, ValueError):
            return None
    if isinstance(value, str):
        raw = value.strip()
        if not raw:
            return None
        if raw.endswith("Z"):
            return raw
        try:
            dt = datetime.fromisoformat(raw)
        except ValueError:
            return None
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(timezone.utc).isoformat()
    return None


def as_int(value: Any) -> int | None:
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def clean(data: dict[str, Any]) -> dict[str, Any]:
    """Drop None/empty fields so entities stay readable."""
    out: dict[str, Any] = {}
    for k, v in data.items():
        if v is None or v == "" or v == [] or v == {}:
            continue
        out[k] = v
    return out