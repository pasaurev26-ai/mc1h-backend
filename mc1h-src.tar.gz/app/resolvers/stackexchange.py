"""Stack Exchange network users (default site: stackoverflow).

API: https://api.stackexchange.com/docs/users (no auth for low volume)
`inname` is a fuzzy search, so the profile slug must equal the handle exactly.
"""

from __future__ import annotations

from urllib.parse import quote

from ..opsec import HttpFetcher
from ..schemas import ResolverResult
from .base import Resolver, account, as_int, clean, edge, iso, prov


class StackExchangeResolver(Resolver):
    name = "stackexchange"
    platform = "stackoverflow"

    async def resolve(self, handle: str, fetcher: HttpFetcher) -> ResolverResult:
        url = (
            "https://api.stackexchange.com/2.3/users"
            f"?inname={quote(handle)}&site=stackoverflow&pagesize=20&order=desc&sort=reputation"
        )
        res = await fetcher.get_json(url, headers={"Accept-Encoding": "gzip"})
        if not res.ok:
            return self.result(
                res.outcome,
                provenance=[prov("stackexchange", url, query=f"inname={handle}", outcome=res.outcome,
                                 http_status=res.status, latency_ms=res.elapsed_ms)],
                error=res.error,
            )
        payload = res.payload if isinstance(res.payload, dict) else {}
        items = [i for i in (payload.get("items") or []) if isinstance(i, dict)]

        match = None
        for item in items:
            link = str(item.get("link") or "")
            slug = link.rstrip("/").rsplit("/", 1)[-1] if "/users/" in link else ""
            if slug.lower() == handle.lower():
                match = item
                break

        p = prov("stackexchange", url, query=f"inname={handle}", http_status=res.status,
                 outcome="ok" if match else "not_found",
                 latency_ms=res.elapsed_ms, confidence=0.6 if match else 0.0,
                 note=f"{len(items)} fuzzy candidates; exact slug required"
                      + (f"; quota_remaining={payload.get('quota_remaining')}" if payload else ""))
        if match is None:
            return self.result("not_found", provenance=[p])

        link = str(match.get("link") or "")
        entity = account(
            "stackoverflow", handle, match.get("display_name") or handle, p, 0.6,
            **clean({
                "user_id": match.get("user_id"),
                "display_name": match.get("display_name"),
                "reputation": as_int(match.get("reputation")),
                "profile_url": link,
                "created_at": iso(match.get("creation_date")),
                "last_access": iso(match.get("last_access_date")),
                "badges": match.get("badge_counts"),
                "location": match.get("location"),
                "website_url": match.get("website_url"),
                "account_id": match.get("account_id"),
            }),
        )
        e = edge("root:selector", entity.id, "handle_match", 0.6, p,
                 note="exact profile slug match on stackoverflow.com")
        return self.result("ok", entities=[entity], edges=[e], provenance=[p])