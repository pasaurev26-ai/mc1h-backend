"""GitHub: profile + owned repositories.

API: https://docs.github.com/en/rest/users/users#get-a-user
Auth: optional GITHUB_TOKEN (60 req/h unauth, 5000 with token)
"""

from __future__ import annotations

import os

from ..opsec import HttpFetcher
from ..schemas import ResolverResult
from .base import Resolver, account, artifact, as_int, clean, edge, iso, prov

API = "https://api.github.com"


class GitHubResolver(Resolver):
    name = "github"
    platform = "github"

    async def resolve(self, handle: str, fetcher: HttpFetcher) -> ResolverResult:
        headers = {"Accept": "application/vnd.github+json", "X-GitHub-Api-Version": "2022-11-28"}
        token = os.getenv("GITHUB_TOKEN")
        if token:
            headers["Authorization"] = f"Bearer {token}"

        user_url = f"{API}/users/{handle}"
        res = await fetcher.get_json(user_url, headers=headers)
        if not res.ok:
            return self.result(
                res.outcome,
                provenance=[prov("github", user_url, query=f"user={handle}", outcome=res.outcome,
                                 http_status=res.status, latency_ms=res.elapsed_ms)],
                error=res.error,
            )

        data = res.payload if isinstance(res.payload, dict) else {}
        login = data.get("login")
        if not login:
            return self.result("error", error="unexpected GitHub payload (no login field)")

        confidence = 0.75 if str(login).lower() == handle.lower() else 0.55
        p_user = prov(
            "github", user_url, query=f"user={handle}", http_status=res.status,
            latency_ms=res.elapsed_ms, confidence=confidence,
            note=f"rate-limit remaining={res.headers.get('x-ratelimit-remaining')}/"
                 f"{res.headers.get('x-ratelimit-limit')}" if res.headers else None,
        )
        entity = account(
            "github", str(login), data.get("name") or str(login), p_user, confidence,
            **clean({
                "user_id": data.get("id"),
                "html_url": data.get("html_url"),
                "company": data.get("company"),
                "blog": data.get("blog"),
                "location": data.get("location"),
                "bio": data.get("bio"),
                "email_public": data.get("email"),
                "twitter_username": data.get("twitter_username"),
                "public_repos": data.get("public_repos"),
                "public_gists": data.get("public_gists"),
                "followers": data.get("followers"),
                "following": data.get("following"),
                "created_at": iso(data.get("created_at")),
                "updated_at": iso(data.get("updated_at")),
                "hireable": data.get("hireable"),
                "avatar_url": data.get("avatar_url"),
            }),
        )

        entities = [entity]
        edges = [
            edge("root:selector", entity.id, "handle_match", confidence, p_user,
                 note="exact GitHub login match; handle equality is not identity proof")
        ]
        provenance = [p_user]

        repos_url = f"{API}/users/{login}/repos?per_page=100&type=owner&sort=updated"
        repos = await fetcher.get_json(repos_url, headers=headers)
        if repos.ok and isinstance(repos.payload, list):
            p_repos = prov(
                "github", repos_url, query=f"user={login}", http_status=repos.status,
                latency_ms=repos.elapsed_ms, confidence=0.95,
                note=f"{len(repos.payload)} repos in first page",
            )
            provenance.append(p_repos)
            owned = [r for r in repos.payload if isinstance(r, dict) and r.get("name")]
            owned.sort(key=lambda r: as_int(r.get("stargazers_count")) or 0, reverse=True)
            for repo in owned[:15]:
                full = repo.get("full_name") or f"{login}/{repo['name']}"
                art = artifact(
                    "github", str(full), str(full), p_repos, 0.95,
                    **clean({
                        "description": repo.get("description"),
                        "language": repo.get("language"),
                        "stars": repo.get("stargazers_count"),
                        "forks": repo.get("forks_count"),
                        "open_issues": repo.get("open_issues_count"),
                        "fork": repo.get("fork"),
                        "archived": repo.get("archived"),
                        "html_url": repo.get("html_url"),
                        "created_at": iso(repo.get("created_at")),
                        "updated_at": iso(repo.get("updated_at")),
                        "pushed_at": iso(repo.get("pushed_at")),
                    }),
                )
                entities.append(art)
                edges.append(edge(entity.id, art.id, "owns", 0.95, p_repos))
            entity.attributes["repos_sampled"] = len(owned[:15])
            entity.attributes["repos_total_page"] = len(owned)
        elif not repos.ok:
            provenance.append(prov(
                "github", repos_url, outcome=repos.outcome, http_status=repos.status,
                latency_ms=repos.elapsed_ms, note=f"repos unavailable: {repos.error}",
            ))

        return self.result("ok", entities=entities, edges=edges, provenance=provenance)