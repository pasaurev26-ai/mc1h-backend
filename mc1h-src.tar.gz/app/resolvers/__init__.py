"""Resolver registry. Add a platform by importing it here."""

from __future__ import annotations

from .base import Resolver
from .codeforces import CodeforcesResolver
from .devto import DevToResolver
from .dockerhub import DockerHubResolver
from .github import GitHubResolver
from .gitlab import GitLabResolver
from .hackernews import HackerNewsResolver
from .keybase import KeybaseResolver
from .npm import NpmResolver
from .reddit import RedditResolver
from .stackexchange import StackExchangeResolver
from .telegram import TelegramResolver

ALL: dict[str, Resolver] = {
    r.name: r
    for r in (
        GitHubResolver(),
        GitLabResolver(),
        HackerNewsResolver(),
        RedditResolver(),
        NpmResolver(),
        DockerHubResolver(),
        DevToResolver(),
        CodeforcesResolver(),
        KeybaseResolver(),
        TelegramResolver(),
        StackExchangeResolver(),
    )
}

# platform -> resolver name, used for the depth-1 pass over verified cross-references
PLATFORM_TO_SOURCE: dict[str, str] = {
    "github": "github",
    "gitlab": "gitlab",
    "hackernews": "hackernews",
    "reddit": "reddit",
}

DEFAULT_SOURCES: tuple[str, ...] = tuple(ALL.keys())


def select(sources: list[str] | None) -> list[Resolver]:
    if not sources:
        return [ALL[name] for name in DEFAULT_SOURCES]
    unknown = [s for s in sources if s not in ALL]
    if unknown:
        raise ValueError(f"unknown sources: {', '.join(unknown)}; available: {', '.join(ALL)}")
    return [ALL[s] for s in sources]