"""Reddit public profile (about.json).

Docs: https://www.reddit.com/dev/api/#GET_user_{username}_about
Auth: anonymous JSON is frequently 403 from datacenter IPs; OAuth or residential
proxy is required in that case. The resolver reports `blocked` instead of guessing.
"""

from __future__ import annotations

from urllib.parse import quote

from ..opsec import HttpFetcher
from ..schemas import ResolverResult
from .base import Resolver, account, as_int, clean, edge, iso, prov


class RedditResolver(Resolver):
    name = "reddit"
    platform = "reddit"

    async def resolve(self, handle: str, fetcher: HttpFetcher) -> ResolverResult:
        endpoints = [
            f"https://www.reddit.com/user/{quote(handle)}/about.json",
            f"https://old.reddit.com/user/{quote(handle)}/about.json",
        ]
        headers = {"Accept": "application/json"}
        provenance = []
        last_error = None
        for url in endpoints:
            res = await fetcher.get_json(url, headers=headers)
            p = prov("reddit", url, query=f"user={handle}", outcome=res.outcome,
                     http_status=res.status, latency_ms=res.elapsed_ms)
            provenance.append(p)
            if res.outcome == "not_found":
                return self.result("not_found", provenance=provenance)
            if not res.ok:
                last_error = res.error
                continue

            payload = res.payload if isinstance(res.payload, dict) else {}
            data = payload.get("data") if isinstance(payload.get("data"), dict) else {}
            name = data.get("name")
            if not name:
                last_error = "unexpected Reddit payload"
                continue

            p.confidence = 0.75
            entity = account(
                "reddit", str(name), str(data.get("subreddit", {}).get("title") or name)
                if isinstance(data.get("subreddit"), dict) else str(name),
                p, 0.75,
                **clean({
                    "user_id": data.get("id"),
                    "link_karma": as_int(data.get("link_karma")),
                    "comment_karma": as_int(data.get("comment_karma")),
                    "total_karma": as_int(data.get("total_karma")),
                    "created_at": iso(data.get("created_utc")),
                    "is_mod": data.get("is_mod"),
                    "is_gold": data.get("is_gold"),
                    "verified": data.get("verified"),
                    "profile_url": f"https://www.reddit.com/user/{name}",
                    "icon_img": data.get("icon_img"),
                    "description": (data.get("subreddit", {}) or {}).get("public_description")
                    if isinstance(data.get("subreddit"), dict) else None,
                }),
            )
            e = edge("root:selector", entity.id, "handle_match", 0.75, p,
                     note="exact Reddit username match")
            return self.result("ok", entities=[entity], edges=[e], provenance=provenance)

        outcome = "blocked" if any(p.outcome == "blocked" for p in provenance) else "error"
        hint = ("Reddit blocks anonymous JSON from this network; "
                "configure MC1H_PROXIES (residential) or Reddit OAuth")
        return self.result(outcome, provenance=provenance, error=hint if outcome == "blocked" else last_error)