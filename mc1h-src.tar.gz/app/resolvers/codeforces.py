"""Codeforces public user info.

API: https://codeforces.com/apiHelp/methods#user.info (no auth, 1 req / 2 s guideline)
Response wraps results in {"status": "OK" | "FAILED", "result" | "comment"}.
"""

from __future__ import annotations

from urllib.parse import quote

from ..opsec import HttpFetcher
from ..schemas import ResolverResult
from .base import Resolver, account, as_int, clean, edge, iso, prov


class CodeforcesResolver(Resolver):
    name = "codeforces"
    platform = "codeforces"

    async def resolve(self, handle: str, fetcher: HttpFetcher) -> ResolverResult:
        url = f"https://codeforces.com/api/user.info?handles={quote(handle)}"
        res = await fetcher.get_json(url)
        # Codeforces answers unknown handles with HTTP 400 + {"status":"FAILED"}
        if (res.status == 400 and isinstance(res.payload, dict)
                and str(res.payload.get("status")) == "FAILED"):
            p = prov("codeforces", url, query=f"handles={handle}", http_status=res.status,
                     outcome="not_found", latency_ms=res.elapsed_ms, confidence=0.0,
                     note=str(res.payload.get("comment") or "user not found"))
            return self.result("not_found", provenance=[p])
        if not res.ok:
            return self.result(
                res.outcome,
                provenance=[prov("codeforces", url, query=f"handles={handle}", outcome=res.outcome,
                                 http_status=res.status, latency_ms=res.elapsed_ms)],
                error=res.error,
            )
        payload = res.payload if isinstance(res.payload, dict) else {}
        status = str(payload.get("status"))
        if status != "OK":
            p = prov("codeforces", url, query=f"handles={handle}", http_status=res.status,
                     latency_ms=res.elapsed_ms, confidence=0.0,
                     note=str(payload.get("comment") or "status != OK"))
            return self.result("not_found", provenance=[p])

        rows = payload.get("result") or []
        data = rows[0] if rows and isinstance(rows[0], dict) else {}
        found = str(data.get("handle") or "")
        confidence = 0.75 if found.lower() == handle.lower() else 0.5
        p = prov("codeforces", url, query=f"handles={handle}", http_status=res.status,
                 latency_ms=res.elapsed_ms, confidence=confidence)
        entity = account(
            "codeforces", found or handle, found or handle, p, confidence,
            **clean({
                "rating": as_int(data.get("rating")),
                "max_rating": as_int(data.get("maxRating")),
                "rank": data.get("rank"),
                "max_rank": data.get("maxRank"),
                "country": data.get("country"),
                "city": data.get("city"),
                "organization": data.get("organization"),
                "contribution": as_int(data.get("contribution")),
                "friends": as_int(data.get("friendOfCount")),
                "registered_at": iso(data.get("registrationTimeSeconds")),
                "last_online": iso(data.get("lastOnlineTimeSeconds")),
                "profile_url": f"https://codeforces.com/profile/{found or handle}",
                "avatar_url": data.get("titlePhoto") or data.get("avatar"),
            }),
        )
        e = edge("root:selector", entity.id, "handle_match", confidence, p)
        return self.result("ok", entities=[entity], edges=[e], provenance=[p])