"""Keybase lookup — the strongest cross-platform signal available without auth.

API: https://keybase.io/docs/api/1.0/call/user/lookup (no auth)
Proofs with state == 1 are cryptographically verified claims published by the
account owner, so they are emitted as `verified_link` edges.
"""

from __future__ import annotations

from urllib.parse import quote

from ..opsec import HttpFetcher
from ..schemas import ResolverResult
from .base import Resolver, account, clean, edge, iso, prov

# proof_type -> our platform namespace
PROOF_PLATFORMS = {
    "github": "github",
    "twitter": "twitter",
    "reddit": "reddit",
    "hackernews": "hackernews",
    "gitlab": "gitlab",
    "dns": "domain",
    "generic_web_site": "website",
}


class KeybaseResolver(Resolver):
    name = "keybase"
    platform = "keybase"

    async def resolve(self, handle: str, fetcher: HttpFetcher) -> ResolverResult:
        url = f"https://keybase.io/_/api/1.0/user/lookup.json?username={quote(handle)}&fields=basics,profile,proofs_summary"
        res = await fetcher.get_json(url)
        if not res.ok:
            return self.result(
                res.outcome,
                provenance=[prov("keybase", url, query=f"username={handle}", outcome=res.outcome,
                                 http_status=res.status, latency_ms=res.elapsed_ms)],
                error=res.error,
            )
        payload = res.payload if isinstance(res.payload, dict) else {}
        them = payload.get("them")
        if them is None or them == []:
            p = prov("keybase", url, query=f"username={handle}", http_status=res.status,
                     outcome="not_found", latency_ms=res.elapsed_ms, confidence=0.0,
                     note="no keybase account for this handle")
            return self.result("not_found", provenance=[p])
        if isinstance(them, list):
            them = them[0] if them else None
        if not isinstance(them, dict):
            return self.result("error", error="unexpected Keybase payload")

        basics = them.get("basics") or {}
        profile = them.get("profile") or {}
        username = str(basics.get("username") or handle)
        confidence = 0.85 if username.lower() == handle.lower() else 0.6
        p = prov("keybase", url, query=f"username={handle}", http_status=res.status,
                 latency_ms=res.elapsed_ms, confidence=confidence,
                 note="Keybase identity record")
        entity = account(
            "keybase", username, profile.get("full_name") or username, p, confidence,
            **clean({
                "full_name": profile.get("full_name"),
                "location": profile.get("location"),
                "bio": profile.get("bio"),
                "registered_at": iso(basics.get("ctime")),
                "profile_url": f"https://keybase.io/{username}",
            }),
        )
        entities = [entity]
        provenance = [p]
        edges = [edge("root:selector", entity.id, "handle_match", confidence, p)]

        proofs = ((them.get("proofs_summary") or {}).get("all") or [])
        verified: list[dict] = []
        for proof in proofs:
            if not isinstance(proof, dict):
                continue
            ptype = str(proof.get("proof_type") or "")
            nametag = proof.get("nametag")
            state = proof.get("state")
            if not ptype or not nametag:
                continue
            record = clean({
                "proof_type": ptype,
                "nametag": nametag,
                "state": state,
                "service_url": proof.get("service_url"),
            })
            verified.append(record)
            if state != 1:
                continue
            platform = PROOF_PLATFORMS.get(ptype)
            if platform in (None, "domain", "website"):
                continue
            p_link = prov("keybase", url, query=f"proof {ptype}={nametag}", http_status=res.status,
                          latency_ms=res.elapsed_ms, confidence=0.9,
                          note=f"keybase proof state={state}, {proof.get('proof_url')}")
            target = f"account:{platform}:{str(nametag).lower()}"
            edges.append(edge("root:selector", target, "verified_link", 0.9, p_link,
                              note=f"Keybase-verified {ptype} proof"))
            provenance.append(p_link)

        if verified:
            entity.attributes["proofs"] = verified
        entity.attributes["proof_count"] = len(verified)
        return self.result("ok", entities=entities, edges=edges, provenance=provenance)