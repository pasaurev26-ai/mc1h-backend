"""npm registry: packages maintained by the handle.

Search API: https://registry.npmjs.org/-/v1/search?text=maintainer:<name>
Auth: none. The search endpoint is fuzzy, so results are verified against
package.maintainers[].username before the account is reported as confirmed.
"""

from __future__ import annotations

from urllib.parse import quote

from ..opsec import HttpFetcher
from ..schemas import ResolverResult
from .base import Resolver, account, artifact, as_int, clean, edge, iso, prov

SEARCH = "https://registry.npmjs.org/-/v1/search"


class NpmResolver(Resolver):
    name = "npm"
    platform = "npm"

    async def resolve(self, handle: str, fetcher: HttpFetcher) -> ResolverResult:
        url = f"{SEARCH}?text={quote(f'maintainer:{handle}')}&size=25"
        res = await fetcher.get_json(url)
        if not res.ok:
            return self.result(
                res.outcome,
                provenance=[prov("npm", url, query=f"maintainer={handle}", outcome=res.outcome,
                                 http_status=res.status, latency_ms=res.elapsed_ms)],
                error=res.error,
            )
        payload = res.payload if isinstance(res.payload, dict) else {}
        objects = [o for o in (payload.get("objects") or []) if isinstance(o, dict)]
        total = as_int(payload.get("total")) or 0

        verified = []
        for obj in objects:
            pkg = obj.get("package") if isinstance(obj.get("package"), dict) else {}
            maintainers = pkg.get("maintainers") or []
            if any(str(m.get("username", "")).lower() == handle.lower()
                   for m in maintainers if isinstance(m, dict)):
                verified.append(pkg)

        p = prov("npm", url, query=f"maintainer={handle}", http_status=res.status,
                 outcome="ok" if verified else "not_found",
                 latency_ms=res.elapsed_ms, confidence=0.8 if verified else 0.0,
                 note=f"total={total}, verified_maintainer_matches={len(verified)}")
        if not verified:
            return self.result("not_found", provenance=[p],
                               error=None if total == 0 else "search hits without exact maintainer match")

        entity = account(
            "npm", handle, handle, p, 0.8,
            **clean({
                "packages_matched": len(verified),
                "packages_sampled": min(10, len(verified)),
                "packages_total_reported": total,
                "profile_url": f"https://www.npmjs.com/~{handle}",
            }),
        )
        entities = [entity]
        edges = [edge("root:selector", entity.id, "handle_match", 0.8, p,
                      note="username appears in package.maintainers[]")]
        for pkg in verified[:10]:
            name = str(pkg.get("name"))
            art = artifact(
                "npm", name, name, p, 0.9,
                **clean({
                    "version": pkg.get("version"),
                    "description": pkg.get("description"),
                    "date": iso(pkg.get("date")),
                    "links": pkg.get("links"),
                    "publisher": (pkg.get("publisher") or {}).get("username")
                    if isinstance(pkg.get("publisher"), dict) else None,
                }),
            )
            entities.append(art)
            edges.append(edge(entity.id, art.id, "owns", 0.9, p, note="maintainer entry"))
        return self.result("ok", entities=entities, edges=edges, provenance=[p])