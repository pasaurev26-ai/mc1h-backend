"""Telegram public preview (t.me/<handle>).

No API: the public HTML page carries og:title / og:description for existing
accounts and a noindex "Contact @..." stub for missing ones.
"""

from __future__ import annotations

import html
import re
from urllib.parse import quote

from ..opsec import HttpFetcher
from ..schemas import ResolverResult
from .base import Resolver, account, clean, edge, prov

TITLE_RE = re.compile(r'<meta property="og:title" content="([^"]*)"')
DESC_RE = re.compile(r'<meta property="og:description" content="([^"]*)"')
IMAGE_RE = re.compile(r'<meta property="og:image" content="([^"]*)"')


class TelegramResolver(Resolver):
    name = "telegram"
    platform = "telegram"

    async def resolve(self, handle: str, fetcher: HttpFetcher) -> ResolverResult:
        url = f"https://t.me/{quote(handle)}"
        res = await fetcher.get_text(url, headers={"Accept": "text/html"})
        if not res.ok:
            return self.result(
                res.outcome,
                provenance=[prov("telegram", url, query=f"handle={handle}", outcome=res.outcome,
                                 http_status=res.status, latency_ms=res.elapsed_ms)],
                error=res.error,
            )
        body = res.text or ""
        title = html.unescape(TITLE_RE.search(body).group(1)) if TITLE_RE.search(body) else None
        desc = html.unescape(DESC_RE.search(body).group(1)) if DESC_RE.search(body) else None
        image = html.unescape(IMAGE_RE.search(body).group(1)) if IMAGE_RE.search(body) else None

        missing = (
            "noindex" in body
            or title is None
            or title.startswith("Telegram: Contact @")
            or title == "Telegram: View"
        )
        p = prov("telegram", url, query=f"handle={handle}", http_status=res.status,
                 outcome="not_found" if missing else "ok",
                 latency_ms=res.elapsed_ms, confidence=0.0 if missing else 0.65,
                 note="public preview page; existence is not identity proof")
        if missing:
            return self.result("not_found", provenance=[p])

        display = title if title and not title.startswith("Telegram:") else handle
        if not display.strip(" .-_"):  # channel named "." or similar placeholder
            display = handle
        entity = account(
            "telegram", handle, display, p, 0.65,
            **clean({
                "display_name": display,
                "description": desc,
                "profile_url": f"https://t.me/{handle}",
                "image": image,
            }),
        )
        e = edge("root:selector", entity.id, "handle_match", 0.65, p,
                 note="public t.me handle exists (case-insensitive)")
        return self.result("ok", entities=[entity], edges=[e], provenance=[p])