"""Hacker News: authoritative Firebase user record + Algolia activity sample.

Docs: https://github.com/HackerNews/API  (no auth, no documented hard rate limit)
Algolia: https://hn.algolia.com/api (no auth)
"""

from __future__ import annotations

import html
import re
from urllib.parse import quote

TAG_RE = re.compile(r"<[^>]+>")


def _plain(value: str | None) -> str | None:
    if not value:
        return None
    text = html.unescape(TAG_RE.sub(" ", value))
    return " ".join(text.split())[:500] or None

from ..opsec import HttpFetcher
from ..schemas import ResolverResult
from .base import Resolver, account, as_int, clean, edge, iso, prov

FIREBASE = "https://hacker-news.firebaseio.com/v0"
ALGOLIA = "https://hn.algolia.com/api/v1"


class HackerNewsResolver(Resolver):
    name = "hackernews"
    platform = "hackernews"

    async def resolve(self, handle: str, fetcher: HttpFetcher) -> ResolverResult:
        url = f"{FIREBASE}/user/{quote(handle)}.json"
        res = await fetcher.get_json(url)
        if not res.ok:
            return self.result(
                res.outcome,
                provenance=[prov("hackernews", url, query=f"user={handle}", outcome=res.outcome,
                                 http_status=res.status, latency_ms=res.elapsed_ms)],
                error=res.error,
            )
        if res.payload is None:
            p = prov("hackernews", url, query=f"user={handle}", http_status=res.status,
                     outcome="not_found", latency_ms=res.elapsed_ms, confidence=0.0,
                     note="Firebase returned null: user does not exist")
            return self.result("not_found", provenance=[p])

        data = res.payload if isinstance(res.payload, dict) else {}
        uid = str(data.get("id") or handle)
        p = prov("hackernews", url, query=f"user={uid}", http_status=res.status,
                 latency_ms=res.elapsed_ms, confidence=0.85,
                 note="authoritative user record" if uid.lower() == handle.lower() else "resolved handle differs")
        entity = account(
            "hackernews", uid, uid, p, 0.85,
            **clean({
                "about": _plain(data.get("about")),
                "created_at": iso(data.get("created")),
                "karma": as_int(data.get("karma")),
                "submitted_items": len(data.get("submitted") or []),
                "profile_url": f"https://news.ycombinator.com/user?id={uid}",
            }),
        )
        entities = [entity]
        provenance = [p]
        edges = [edge("root:selector", entity.id, "handle_match", 0.85 if uid.lower() == handle.lower() else 0.55,
                      p, note="HN user id is unique; equality to selector is exact" if uid.lower() == handle.lower() else None)]

        sample_url = f"{ALGOLIA}/search?tags=author_{quote(uid)}&hitsPerPage=5"
        sample = await fetcher.get_json(sample_url)
        if sample.ok and isinstance(sample.payload, dict):
            hits = sample.payload.get("hits") or []
            p_sample = prov("hackernews", sample_url, query=f"author={uid}", http_status=sample.status,
                            latency_ms=sample.elapsed_ms, confidence=0.7,
                            note=f"nbHits={sample.payload.get('nbHits')} (Algolia index, may lag)")
            provenance.append(p_sample)
            entity.attributes["algolia_hits"] = as_int(sample.payload.get("nbHits"))
            entity.attributes["recent_items"] = [
                clean({
                    "title": h.get("title") or h.get("story_title"),
                    "url": h.get("url") or h.get("story_url"),
                    "created_at": iso(h.get("created_at")),
                    "points": h.get("points"),
                })
                for h in hits[:5] if isinstance(h, dict)
            ]
        elif not sample.ok:
            provenance.append(prov("hackernews", sample_url, outcome=sample.outcome, http_status=sample.status,
                                   latency_ms=sample.elapsed_ms, note=f"activity sample unavailable: {sample.error}"))

        return self.result("ok", entities=entities, edges=edges, provenance=provenance)