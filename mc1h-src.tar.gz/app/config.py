"""Runtime configuration. All values can be overridden with MC1H_* env vars."""

from __future__ import annotations

import os
from dataclasses import dataclass, field


def _env_float(name: str, default: float) -> float:
    raw = os.getenv(name)
    if raw is None or raw == "":
        return default
    try:
        return float(raw)
    except ValueError:
        return default


def _env_int(name: str, default: int) -> int:
    raw = os.getenv(name)
    if raw is None or raw == "":
        return default
    try:
        return int(raw)
    except ValueError:
        return default


def _env_bool(name: str, default: bool) -> bool:
    raw = os.getenv(name)
    if raw is None or raw == "":
        return default
    return raw.strip().lower() in ("1", "true", "yes", "on")


@dataclass(frozen=True)
class Settings:
    """Immutable run settings.

    proxies: comma-separated list, e.g. MC1H_PROXIES=http://u:p@host:port,socks5://host:port
    """

    user_agent: str = os.getenv(
        "MC1H_UA",
        "mc1h/1.0 (data-fusion research; +https://example.invalid/mc1h)",
    )
    timeout_s: float = _env_float("MC1H_TIMEOUT", 12.0)
    attempts: int = _env_int("MC1H_ATTEMPTS", 3)
    backoff_base_s: float = _env_float("MC1H_BACKOFF", 0.7)
    db_path: str = os.getenv("MC1H_DB", "data/mc1h.db")
    out_dir: str = os.getenv("MC1H_OUT", "out")
    # User-supplied HTML/JSON exports for manual-source resolvers.
    local_data_dir: str = os.getenv("MC1H_LOCAL_DATA", "data")
    global_concurrency: int = _env_int("MC1H_CONCURRENCY", 6)
    per_source_concurrency: int = _env_int("MC1H_PER_SOURCE_CONCURRENCY", 2)
    per_host_interval_s: float = _env_float("MC1H_HOST_INTERVAL", 0.8)
    resolver_timeout_s: float = _env_float("MC1H_RESOLVER_TIMEOUT", 45.0)
    max_secondary_handles: int = _env_int("MC1H_MAX_SECONDARY", 5)

    # Response cache (SQLite, JSON responses only). 0 disables it.
    cache_path: str = os.getenv("MC1H_CACHE_DB", "data/mc1h_cache.db")
    cache_ttl_s: float = _env_float("MC1H_CACHE_TTL", 3600.0)

    # Sherlock sources.  All are optional: absent key -> honest gap, not a fake result.
    fns_api_url: str = os.getenv("MC1H_FNS_API_URL", "")
    fns_api_key: str = os.getenv("MC1H_FNS_API_KEY", "")
    hibp_api_key: str = os.getenv("MC1H_HIBP_API_KEY", "")
    github_token: str = os.getenv("GITHUB_TOKEN", "")

    # New selector families.  Every endpoint is user-supplied; no captcha
    # solving, session theft, or scraping behind a login wall is performed.
    gibdd_api_url: str = os.getenv("MC1H_GIBDD_API_URL", "")
    gibdd_api_key: str = os.getenv("MC1H_GIBDD_API_KEY", "")
    driver_api_url: str = os.getenv("MC1H_DRIVER_API_URL", "")
    driver_api_key: str = os.getenv("MC1H_DRIVER_API_KEY", "")
    telegram_db_url: str = os.getenv("MC1H_TELEGRAM_DB_URL", "")
    telegram_db_key: str = os.getenv("MC1H_TELEGRAM_DB_KEY", "")
    rosreestr_api_url: str = os.getenv("MC1H_ROSREESTR_API_URL", "")
    rosreestr_api_key: str = os.getenv("MC1H_ROSREESTR_API_KEY", "")
    nominatim_url: str = os.getenv("MC1H_NOMINATIM_URL", "")
    search_api_url: str = os.getenv("MC1H_SEARCH_API_URL", "")
    search_api_key: str = os.getenv("MC1H_SEARCH_API_KEY", "")
    face_api_url: str = os.getenv("MC1H_FACE_API_URL", "")
    face_api_key: str = os.getenv("MC1H_FACE_API_KEY", "")

    pd_enabled: bool = _env_bool("MC1H_PD_ENABLED", True)

    # Public phone search (t.me + classifieds).  On by default; can be disabled.
    phone_search_enabled: bool = _env_bool("MC1H_PHONE_SEARCH", True)
    # Optional browser renderer for JS-heavy classifieds.  Captcha is never solved.
    playwright_enabled: bool = _env_bool("MC1H_PLAYWRIGHT", False)

    proxies: tuple[str, ...] = field(
        default_factory=lambda: tuple(
            p.strip() for p in os.getenv("MC1H_PROXIES", "").split(",") if p.strip()
        )
    )


SETTINGS = Settings()