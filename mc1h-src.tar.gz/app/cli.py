"""CLI: username or Sherlock PD selector.

Examples
--------
python -m app.cli torvalds
python -m app.cli +79990000001 --type phone
python -m app.cli 771234567859 --type inn
python -m app.cli "Тестов Тест Тестович" --type fio --birth-date 1990-01-01
"""

from __future__ import annotations

import argparse
import asyncio
import json
import sys

from .config import SETTINGS
from .db import Store
from .pipeline import PDPipeline
from .report import summarize, write_artifacts
from .resolvers.pd import PD_TYPES, detect_selector
from .service import UsernamePipeline


async def _run(args: argparse.Namespace) -> int:
    selector = args.selector
    kind = args.selector_type
    pd_mode = False
    if kind and kind != "username":
        pd_mode = True
    elif not kind:
        try:
            detected, _ = detect_selector(selector)
            pd_mode = detected != "username"
        except ValueError:
            pd_mode = False

    store = Store(args.db)
    pipeline = PDPipeline(store=store) if pd_mode else UsernamePipeline(store=store)
    try:
        if pd_mode:
            run = await pipeline.run(
                selector, args.selector_type, args.birth_date, args.sources
            )
        else:
            run = await pipeline.run(selector, args.sources)
    except ValueError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2
    finally:
        await pipeline.aclose()
        store.close()

    artifacts = write_artifacts(run, args.out)
    summary = summarize(run)
    print(
        json.dumps(
            {
                "run_id": run.run_id,
                "selector": run.selector,
                "selector_kind": run.selector_kind,
                "status": run.status,
                "summary": summary,
                "artifacts": artifacts,
            },
            ensure_ascii=False,
            indent=2,
        )
    )
    if args.print:
        from pathlib import Path

        print(Path(artifacts["report"]).read_text(encoding="utf-8"))
    return 0


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="mc1h", description="Username resolution + Sherlock PD pipeline"
    )
    parser.add_argument("selector", help="username, ФИО, phone, email, ИНН, СНИЛС, паспорт")
    parser.add_argument(
        "--type",
        dest="selector_type",
        choices=("username",) + PD_TYPES,
        default=None,
        help="force selector type (otherwise auto-detected)",
    )
    parser.add_argument(
        "--birth-date",
        dest="birth_date",
        default=None,
        help="ФИО only: 1990-01-01 or 01.01.1990",
    )
    parser.add_argument(
        "--sources",
        default=None,
        help="comma-separated subset (username resolvers or one PD source)",
    )
    parser.add_argument("--out", default=SETTINGS.out_dir, help="artifact directory")
    parser.add_argument("--db", default=SETTINGS.db_path, help="SQLite path")
    parser.add_argument("--print", action="store_true", help="print the markdown report")
    args = parser.parse_args()
    if args.sources:
        args.sources = [s.strip() for s in args.sources.split(",") if s.strip()]
    raise SystemExit(asyncio.run(_run(args)))


if __name__ == "__main__":
    main()