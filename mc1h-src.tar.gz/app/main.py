"""FastAPI application entrypoint: uvicorn app.main:app --reload"""

from __future__ import annotations

from fastapi import FastAPI

from .api import router

app = FastAPI(
    title="mc1h entity-resolution pipeline",
    version="2.0.0",
    description="Username resolution + Sherlock PD selectors: normalize -> resolve -> "
    "graph -> dossier. Handle/name equality is a hypothesis; verified links require "
    "external proof. Missing keys and unlawful sources are reported as gaps.",
)
app.include_router(router)


@app.get("/health")
async def health() -> dict:
    return {"status": "ok"}


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("app.main:app", host="127.0.0.1", port=8000, reload=False)