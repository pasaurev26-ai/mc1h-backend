"""NetworkX graph assembly and serialization."""

from __future__ import annotations

from typing import Any

import networkx as nx

from .schemas import Edge, Entity

KIND_COLORS = {
    "root": "#c0392b",
    "account": "#2471a3",
    "artifact": "#1e8449",
    "person": "#8e44ad",
    "identifier": "#d35400",
    "organization": "#16a085",
    "record": "#2c3e50",
    "breach": "#c0392b",
    "unknown": "#7f8c8d",
}


def build_graph(entities: list[Entity], edges: list[Edge]) -> nx.MultiDiGraph:
    g = nx.MultiDiGraph()
    for entity in entities:
        g.add_node(
            entity.id,
            kind=entity.kind,
            label=entity.label,
            key=entity.key,
            confidence=entity.confidence,
            selector=entity.selector,
            platform=entity.platform,
            profile_url=entity.profile_url,
            raw_hash=entity.raw_hash,
            placeholder=False,
        )
    for edge in edges:
        for node_id in (edge.src, edge.dst):
            if node_id not in g:
                kind, _, rest = node_id.partition(":")
                g.add_node(
                    node_id,
                    kind=kind if kind in KIND_COLORS else "unknown",
                    label=rest or node_id,
                    key=rest,
                    confidence=0.5,
                    placeholder=True,
                )
        g.add_edge(
            edge.src,
            edge.dst,
            key=edge.relation,
            relation=edge.relation,
            confidence=edge.confidence,
            note=edge.note,
        )
    return g


def stats(g: nx.MultiDiGraph) -> dict[str, int]:
    by_relation: dict[str, int] = {}
    for _, _, data in g.edges(data=True):
        rel = str(data.get("relation"))
        by_relation[rel] = by_relation.get(rel, 0) + 1
    kinds = {
        kind: sum(1 for _, d in g.nodes(data=True) if d.get("kind") == kind)
        for kind in KIND_COLORS
        if kind != "unknown"
    }
    return {
        "nodes": g.number_of_nodes(),
        "edges": g.number_of_edges(),
        "accounts": kinds.get("account", 0),
        "artifacts": kinds.get("artifact", 0),
        "persons": kinds.get("person", 0),
        "identifiers": kinds.get("identifier", 0),
        "organizations": kinds.get("organization", 0),
        "records": kinds.get("record", 0) + kinds.get("breach", 0),
        "placeholders": sum(1 for _, d in g.nodes(data=True) if d.get("placeholder")),
        **{f"rel_{k}": v for k, v in sorted(by_relation.items())},
    }


def to_dot(g: nx.MultiDiGraph) -> str:
    def esc(value: Any) -> str:
        text = str(value).replace("\\", "\\\\").replace('"', '\\"').replace("\n", " ")
        return text if len(text) <= 42 else text[:39] + "..."

    def esc_id(value: Any) -> str:
        # identifiers must stay unique: never truncate them
        return str(value).replace("\\", "\\\\").replace('"', '\\"').replace("\n", " ")

    lines = ["digraph mc1h {", '  rankdir="LR";', '  node [shape="box", style="rounded,filled", fontname="Helvetica", fontsize=10];']
    for node_id, data in g.nodes(data=True):
        color = KIND_COLORS.get(str(data.get("kind")), KIND_COLORS["unknown"])
        style = '"dashed"' if data.get("placeholder") else '"rounded,filled"'
        lines.append(
            f'  "{esc_id(node_id)}" [label="{esc(data.get("label"))}", '
            f'fillcolor="{color}", fontcolor="white", style={style}];'
        )
    for src, dst, data in g.edges(data=True):
        rel = str(data.get("relation"))
        attrs = [f'label="{esc(rel)}"']
        if rel == "handle_match":
            attrs += ['style="dashed"', 'color="#7f8c8d"']
        elif rel == "verified_link":
            attrs += ['style="bold"', 'color="#c0392b"', 'penwidth="2.2"']
        elif rel == "same_as":
            attrs += ['style="bold"', 'color="#d35400"', 'penwidth="2.0"']
        elif rel == "observed_in":
            attrs += ['style="dotted"', 'color="#2471a3"']
        elif rel in ("registered_as", "registered_at", "identified_as"):
            attrs += ['style="solid"', 'color="#16a085"']
        else:
            attrs += ['color="#34495e"']
        lines.append(f'  "{esc_id(src)}" -> "{esc_id(dst)}" [{", ".join(attrs)}];')
    lines.append("}")
    return "\n".join(lines)


def to_json(g: nx.MultiDiGraph) -> dict[str, Any]:
    return {
        "nodes": [
            {"id": n, **{k: v for k, v in d.items()}}
            for n, d in g.nodes(data=True)
        ],
        "edges": [
            {
                "source": u,
                "target": v,
                "relation": d.get("relation"),
                "confidence": d.get("confidence"),
                "note": d.get("note"),
            }
            for u, v, d in g.edges(data=True)
        ],
        "stats": stats(g),
    }


def adjacency_lines(g: nx.MultiDiGraph, limit: int = 40) -> list[str]:
    lines = []
    for node_id, data in sorted(g.nodes(data=True), key=lambda kv: (str(kv[1].get("kind")), str(kv[0]))):
        if data.get("kind") == "root":
            continue
        outgoing = list(g.out_edges(node_id, data=True))
        incoming = list(g.in_edges(node_id, data=True))
        if not outgoing and not incoming:
            continue
        rel_in = ",".join(sorted({str(d.get("relation")) for _, _, d in incoming}))
        rel_out = f" → {len(outgoing)} out" if outgoing else ""
        marker = ", placeholder" if data.get("placeholder") else ""
        lines.append(f"- `{node_id}` ({data.get('kind')}, conf {data.get('confidence'):.2f}{marker}) "
                     f"← {rel_in}{rel_out}")
        if len(lines) >= limit:
            lines.append("- ...")
            break
    return lines